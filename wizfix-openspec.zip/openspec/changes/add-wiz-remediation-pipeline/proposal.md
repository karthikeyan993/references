# Proposal: Wiz-driven dependency remediation pipeline (`wizfix`)

## Why

Our team gets a daily Wiz report in a GCS bucket listing security issues on our
Cloud Run services and Cloud Run functions across many GCP projects. Today a
person reads the report, works out which repository owns each service, bumps the
vulnerable Python package by hand and opens a pull request. That is slow, easy
to forget, and the same work repeats every day.

We want a scheduled job that does the mechanical part: read the report, map each
finding to its repository, bump only the packages needed to clear the Wiz
finding, and open a pull request. Anything that needs code changes is handed to
a person running a coding agent (Pi) on a laptop.

Constraints that shaped this change:

- **No LLM or coding agent may run in CircleCI or any cloud runner.** Company
  policy. Everything in CI must be deterministic, rule-based code. LLM work
  happens only on a developer laptop.
- **No Wiz API access.** The only input is the CSV report in the bucket.
- **Only fix what Wiz flags.** This is not a general "keep dependencies fresh"
  bot. Repositories with no in-scope Wiz finding are never touched.
- **Python only.** All in-scope services use pip (`requirements.txt`), Poetry or
  uv.

## What Changes

A new Python command-line tool, `wizfix`, in a new central repository
(`wiz-remediation`), run daily by CircleCI:

- Downloads the newest Wiz **Issues** CSV from GCS, and the newest Wiz
  **Vulnerability findings** CSV if one is configured.
- Filters to open, vulnerability-type issues at or above a severity threshold.
- Maps each affected resource to a repository and sub-directory using a
  hand-maintained `mapping.yaml`.
- Works out which Python packages need bumping in each mapped repository:
  - from the Vulnerability findings CSV when it is configured, or
  - by running `pip-audit` on the repository when it is not (the Wiz Issues CSV
    has no package columns, so it can only say *which service* is at risk).
- Applies rule-based version bumps for direct and transitive dependencies in
  `requirements.txt`, Poetry and uv projects.
- Opens or updates **one pull request per repository path**, with one commit per
  bumped package.
- Opens GitHub issues for anything it cannot fix by rule (`needs-agent`) or that
  has no fixed version (`no-fix`).
- On the next run, checks the CI status of its open pull requests and labels
  failing ones `needs-agent`.
- Posts a daily summary to a Google Chat space.
- Provides laptop-side commands that list `needs-agent` work and prepare a task
  file for the Pi coding agent. The tool itself never calls an LLM.

Nothing existing is modified or removed; this is a new system.

## Capabilities

### New Capabilities

- `finding-ingestion`: Download and parse the Wiz reports, filter to in-scope
  findings, map resources to repository targets, and produce a validated list of
  package bumps per target.
- `python-remediation`: Detect a repository's Python dependency layout and apply
  a single package bump by rule, for direct and transitive dependencies, with
  verification and clean failure.
- `github-delivery`: Authenticate as a GitHub App, push bump commits, manage the
  lifecycle of one pull request per target, open and close escalation issues,
  and label pull requests by CI status.
- `run-operations`: The command-line interface, configuration, dry-run mode,
  run summary, Google Chat notification, exit codes, and the safety rules for
  subprocesses, secrets and untrusted input.
- `agent-handoff`: Laptop-side commands that list work needing a coding agent
  and prepare a task file for it, without ever running an LLM in CI.

### Modified Capabilities

None. This is a new repository with no existing specs.

## Impact

- **New repository** `wiz-remediation` containing the `wizfix` package, its
  tests, `config.yaml`, `mapping.yaml` and `.circleci/config.yml`.
- **GitHub**: a GitHub App installed on the team's repositories with
  permissions Contents (read/write), Pull requests (read/write), Issues
  (read/write), Checks (read), Commit statuses (read), Metadata (read). The tool
  creates branches named `wizfix/*`, pull requests, issues, labels and comments
  in those repositories.
- **GCP**: read-only access to the report bucket for the CircleCI job, through
  Workload Identity Federation.
- **CircleCI**: one scheduled pipeline per day, plus a test workflow on every
  push to the `wiz-remediation` repository.
- **Google Chat**: one incoming webhook for the team space.
- **Team repositories**: receive pull requests and issues. Their own CI runs on
  those pull requests exactly as for any other pull request. No change to their
  code or configuration is required.
- **Out of scope** (see `design.md` Non-Goals): non-Python ecosystems, OS and
  base-image packages, hashed or compiled requirements files, auto-merge, the
  Wiz API, and running any LLM outside a laptop.
