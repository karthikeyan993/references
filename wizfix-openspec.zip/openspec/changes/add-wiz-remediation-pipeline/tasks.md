# Tasks

## How to work through this file

Read this section before starting any task. It applies to every task below.

1. **Read first.** Before the first task of a session, read `proposal.md`, then
   the sections of `design.md` named in the task, then the spec requirements
   named in the task. `design.md` section numbers are written as `D§12.3`.
   Spec requirements are written as `spec <capability> / <requirement name>`.
2. **One task at a time, in order.** Do not start a task until the one before
   it is checked off. Do not batch several tasks into one change.
3. **A task is done only when its "Verify" command passes.** Run it. If it
   fails, fix the code, not the test and not the check. Then tick the box.
4. **Do not invent.** Every command line, flag, endpoint, column name, label,
   file name and outcome code is given in `design.md`. Use exactly those. If
   something does not work as written, follow `D§22` (Deviations): run
   `--help`, make the smallest fix, and log it at the end of `design.md`.
5. **Stop and ask when the behaviour is unclear.** Do not choose between two
   plausible behaviours yourself. A wrong guess here opens bad pull requests in
   many repositories.
6. **Dependencies are fixed.** Only the packages in `D§5.2`. No LLM or agent
   libraries, ever. No schema or CLI frameworks.
7. **Tests.** Each task lands its own tests in the same change.
   - Unit tests live in `tests/unit`, use `FakeRunner` and `FakeGitHub`, and
     must not touch the network or start external tools. The only exception is
     `tests/unit/test_runner.py`, which may start `sys.executable`.
   - Every test that covers a spec scenario has the scenario's exact name in
     its docstring, as `Scenario: <name>`.
   - Fixtures are synthetic. Never add a real Wiz report, real resource names
     or real project IDs.
8. **Safety rules that are never relaxed:** no `shell=True`; no `subprocess`
   outside `runner.py`; no secret in any log, file or message; no CSV text in a
   command line unless it passed `D§13.1` validation; a blocked bump restores
   the working tree.
9. **Style.** Python 3.12, type hints everywhere, frozen dataclasses for data,
   small pure functions for rules (decision tables are pure functions with
   table-driven tests), no global mutable state.
10. **Commands used for verification** are run from the repository root:
    - `uv run pytest -m "not integration" <path>` for unit tests
    - `uv run ruff check . && uv run ruff format --check .` for lint

## 1. Project scaffold

- [ ] 1.1 Create `pyproject.toml` per `D§5.1` and `D§5.2`: hatchling build, `src/` layout, Python `>=3.12`, the six runtime dependencies, an optional-dependency group `dev` with `pytest`, `ruff`, `responses`, console script `wizfix = "wizfix.cli:main"`, pytest marker `integration` registered, ruff line length 100. Verify: `uv sync --extra dev` exits 0 and creates `uv.lock`.
- [ ] 1.2 Create every module file listed in `D§5` under `src/wizfix/` and `tests/` (empty modules with a one-line docstring), and a `cli.py` whose `main()` builds the `argparse` parser from `D§6.5` with all subcommands and options, each handler returning 2 with the message `not implemented`. Verify: `uv run wizfix --help` lists `run`, `validate`, `pending`, `handoff`; `uv run wizfix run` (no options) exits 2.
- [ ] 1.3 Implement `reasons.py` with one string constant per code in `D§21.1`, grouped into frozensets (`FATAL`, `TARGET_OUTCOMES`, `BLOCKED_REASONS`, `SKIPPED_STATUSES`, `CHECK_STATES`, `LAYOUT_DETAILS`). Verify: `uv run pytest -m "not integration" tests/unit/test_reasons.py` passes; the test compares each frozenset with the literal list from `D§21.1`.
- [ ] 1.4 Add `.circleci/config.yml` exactly as in `D§23`. Do not try to run it. Verify: `uv run python -c "import yaml; yaml.safe_load(open('.circleci/config.yml'))"` exits 0 and `uv run ruff check . && uv run ruff format --check .` exits 0.

## 2. Configuration, mapping and models

- [ ] 2.1 Implement `models.py` per `D§6.4`, including `Target.slug` and `Target.branch` per `D§15.1`. Verify: `tests/unit/test_models.py` passes, covering spec `github-delivery / Branch and commit conventions` scenarios "Root path" and "Nested path".
- [ ] 2.2 Implement `config.py` loading of `config.yaml` per `D§6.1`: defaults, strict loading (unknown key, wrong type, missing required key), the scope rule and the package source rule, raising `ConfigError` (fatal code `invalid-config`). Verify: `tests/unit/test_config.py` passes, covering spec `run-operations / Configuration validation` scenario "Unknown key" and spec `finding-ingestion / Scope and package source follow the configuration` (all four scenarios).
- [ ] 2.3 Implement loading and validation of `mapping.yaml` per `D§6.3` (required fields, `repo` and `path` patterns, path normalisation, unique `(repo, path)`, exactly one name form per rule, defaults resolved from the config). Verify: `tests/unit/test_mapping_load.py` passes, covering spec `run-operations / Configuration validation` scenarios "Duplicate target", "Match rule with both name forms" and "Path escapes the repository".
- [ ] 2.4 Implement row-to-target matching in `mapping.py` per `D§6.3`. Verify: `tests/unit/test_mapping_match.py` passes, covering every scenario of spec `finding-ingestion / Resource-to-target mapping`.
- [ ] 2.5 Add `config.example.yaml` and `mapping.example.yaml` with the content of `D§6.1` and `D§6.3`. Verify: `tests/unit/test_examples.py` loads both files through `config.py` without error.

## 3. Report ingestion

- [ ] 3.1 Add synthetic fixtures `tests/fixtures/issues_sample.csv` (the 32 columns of `D§7.1`, at least 8 rows covering each filter rule) and `tests/fixtures/vulns_sample.csv` (the 41 columns of `D§7.2`, at least 8 rows). Verify: `uv run python -c "import csv; r=csv.DictReader(open('tests/fixtures/issues_sample.csv', encoding='utf-8-sig')); assert len(r.fieldnames)==32"` exits 0, and the same check with 41 for the other file.
- [ ] 3.2 Implement in `wiz_csv.py` the header check and Issue row parsing and filtering per `D§9`. Verify: `tests/unit/test_wiz_issues.py` passes, covering spec `finding-ingestion / Configured columns must exist` and `finding-ingestion / Issue row scope filter` (all scenarios).
- [ ] 3.3 Implement Vulnerability row parsing and filtering in `wiz_csv.py` per `D§9`. Verify: `tests/unit/test_wiz_vulns.py` passes, covering spec `finding-ingestion / Vulnerability row scope filter`.
- [ ] 3.4 Implement `gcs.py` per `D§8` as a pure function `pick_newest(objects, now, max_age_hours)` over `(name, updated)` pairs plus a thin `download_report()` that uses `google-cloud-storage`; support `.csv.gz`. Verify: `tests/unit/test_gcs.py` passes with fake blob objects, covering spec `finding-ingestion / Newest report selection` (all scenarios).
- [ ] 3.5 Implement scope building per `D§10`: in-scope targets in mapping order, rows kept per target, unmapped grouping, and the `--only` filter. Verify: `tests/unit/test_scope.py` passes, covering spec `finding-ingestion / Only in-scope targets are touched` scenario "Restricting a run" and "No target matches" of the mapping requirement.

## 4. Text safety, runner, versions and findings

- [ ] 4.1 Implement `textsafe.py` per `D§21.2` (`md_inline`, `clean_tool_output`, `redact` with a module-level secret registry that has `register_secret()` and `clear_secrets()`). Verify: `tests/unit/test_textsafe.py` passes, covering spec `run-operations / Untrusted text handling` scenarios "Issue title with a mention" and "Tool output with a code fence" and spec `run-operations / Secrets are never written` scenario "Tool output containing a secret".
- [ ] 4.2 Implement `runner.py` per `D§13.4` and `FakeRunner` in `tests/conftest.py` per `D§25`. Verify: `tests/unit/test_runner.py` passes, covering spec `run-operations / Safe subprocess execution` scenarios "Resolver environment", "Private index credentials" and "Timeout" (the test starts `sys.executable -c` to print its environment) and spec `run-operations / Secrets are never written` scenario "Command logging".
- [ ] 4.3 Implement validation in `versions.py` per `D§13.1` (package name, version, fixed-version text, vulnerability id). Verify: `tests/unit/test_validation.py` passes, covering every scenario of spec `finding-ingestion / Validation of package names, versions and vulnerability ids`.
- [ ] 4.4 Implement `decide()` and per-package planning in `versions.py` per `D§14`. Verify: `tests/unit/test_decide.py` passes with the full tables of `D§14.1`, covering spec `finding-ingestion / Target version decision` and `finding-ingestion / One bump per package`.
- [ ] 4.5 Implement the `wiz-vulnerabilities` source in `findings.py` per `D§13.2`. Verify: `tests/unit/test_findings_wiz.py` passes, covering spec `finding-ingestion / Findings from Vulnerability rows`.
- [ ] 4.6 Implement the `pip-audit` source in `findings.py` per `D§13.3`, with fixture `tests/fixtures/pip_audit_flask.json` (the JSON shown in `D§13.3`). Verify: `tests/unit/test_findings_pip_audit.py` passes using `FakeRunner`, covering every scenario of spec `finding-ingestion / Findings from pip-audit`, and asserting the exact argument list of the `pip-audit` command.

## 5. Handlers

- [ ] 5.1 Implement `handlers/base.py` per `D§12.1`: `HandlerContext`, `Handler` protocol, `ResolveError`, and `snapshot()` / `restore()`. Verify: `tests/unit/test_handler_base.py` passes, including a case where a file created during the attempt is deleted by `restore()`.
- [ ] 5.2 Implement `detect_layout()` and `get_handler()` in `handlers/__init__.py` per `D§11`. Verify: `tests/unit/test_layout.py` passes, covering every scenario of spec `python-remediation / Layout detection`.
- [ ] 5.3 Implement `raise_requirement()` in `handlers/reqspec.py` per `D§12.2`. Verify: `tests/unit/test_reqspec.py` passes with every row of the `D§12.2` table, covering spec `python-remediation / Requirement rewriting rule`.
- [ ] 5.4 Implement `resolve()` of the `requirements` handler per `D§12.3`. Verify: `tests/unit/test_requirements_resolve.py` passes with `FakeRunner`, asserting the exact `uv pip compile` argument list with and without `--no-build`, and covering spec `python-remediation / Resolved map` scenario "Requirements layout" and spec `python-remediation / Source builds are off by default`.
- [ ] 5.5 Implement `apply()` of the `requirements` handler per `D§12.3`. Verify: `tests/unit/test_requirements_apply.py` passes, covering every scenario of spec `python-remediation / Bumps in a requirements file`, including a byte-for-byte comparison of untouched lines.
- [ ] 5.6 Implement `resolve()` and the declared-dependency lookup of the `uv` handler per `D§12.4`, with small fixture files under `tests/fixtures/uv_project/`. Verify: `tests/unit/test_uv_resolve.py` passes, covering spec `python-remediation / Resolved map` scenario "uv layout ignores the project itself" and one lookup test per row of the lookup table.
- [ ] 5.7 Implement `apply()` of the `uv` handler, steps A to D, per `D§12.4`. Verify: `tests/unit/test_uv_apply.py` passes with `FakeRunner` side effects that rewrite the lock fixture, covering every scenario of spec `python-remediation / Bumps in a uv project`, asserting restore on every blocked path, and asserting that `--no-build` is present on `uv lock` and `uv add` by default and absent with the target override (spec `python-remediation / Source builds are off by default`).
- [ ] 5.8 Implement `resolve()`, the version guard and the declared-dependency lookup of the `poetry` handler per `D§12.5`, with fixtures under `tests/fixtures/poetry_project/`. Verify: `tests/unit/test_poetry_resolve.py` passes, covering spec `python-remediation / Resolved map` scenario "Poetry layout" and "simple" / "exact pin" classification for each declaration form.
- [ ] 5.9 Implement `apply()` of the `poetry` handler, steps A to C, per `D§12.5`. Verify: `tests/unit/test_poetry_apply.py` passes, covering every scenario of spec `python-remediation / Bumps in a Poetry project`.
- [ ] 5.10 Add cross-handler tests for spec `python-remediation / Atomic bumps` and `python-remediation / Applied bumps are verified`. Verify: `tests/unit/test_handlers_contract.py` passes, running the same contract checks against all three handlers.
- [ ] 5.11 Add integration tests `tests/integration/test_handlers_real.py` (marker `integration`) that build the reference projects of `D§25` in `tmp_path` and run the real `uv`, `poetry` and `pip-audit`. Verify: `uv run pytest -m integration tests/integration/test_handlers_real.py` passes on a machine with network access; if no network is available in your environment, leave the tests in place and add a `D§22` deviation entry saying they were not run.

## 6. Git and GitHub clients

- [ ] 6.1 Implement `gitops.py` per `D§15` (clone, branch, commit, push, the `<auth>` arguments, registering the token and its base64 form with `textsafe`). Verify: `tests/unit/test_gitops.py` passes with `FakeRunner`, asserting the exact argument list of every command in `D§15.2`, and covering spec `github-delivery / Git credentials are never persisted` and scenario "Unrelated file changed by a tool".
- [ ] 6.2 Implement authentication in `github.py` per `D§16.1` and `D§6.2`: App JWT, installation token, renewal, `WIZFIX_GITHUB_TOKEN` override, fatal code `github-auth-failed`. Verify: `tests/unit/test_github_auth.py` passes using `responses`, covering every scenario of spec `github-delivery / GitHub authentication` (generate a throw-away RSA key inside the test).
- [ ] 6.3 Implement the REST methods of `github.py` for every row of the endpoint table in `D§16.1`, with pagination, retry, and the `dry_run` guard of `D§21.3` on every mutating method. Verify: `tests/unit/test_github_api.py` passes using `responses`, with one test per endpoint row, one pagination test, one retry test, and one test that no mutating HTTP call is made when `dry_run` is true.
- [ ] 6.4 Implement `FakeGitHub` in `tests/conftest.py` per `D§25`, recording every mutation in a list. Verify: `tests/unit/test_fake_github.py` passes, including a test that `FakeGitHub` and `GitHubClient` have the same public method names and parameters.
- [ ] 6.5 Implement `templates.py` per `D§15.2`, `D§16.2`, `D§16.4`, `D§17` and `D§18`: commit message, PR title and body, state marker write and parse, comments, issue titles and bodies, key marker write and parse. Verify: `tests/unit/test_templates.py` passes, covering spec `github-delivery / Pull request content and recorded state` scenarios "State marker round trip" and "Major version change" and spec `run-operations / Untrusted text handling` scenario "Unexpected URL".

## 7. Delivery logic

- [ ] 7.1 Implement the check-state function in `delivery.py` per `D§18` as a pure function. Verify: `tests/unit/test_check_state.py` passes with a table of inputs for `passed`, `failed`, `pending`, `none` and an ignored check.
- [ ] 7.2 Implement the reconciliation decision in `delivery.py` per `D§16.3` as a pure function from (PR state, `bot_only`, recorded set, `D`, `mergeable`) to an action enum. Verify: `tests/unit/test_reconcile_table.py` passes with one test case per row 1 to 12 of the table.
- [ ] 7.3 Implement "build", push and pull-request create/update per `D§16.3` (Build steps 1 to 4). Verify: `tests/unit/test_delivery_build.py` passes with `FakeGitHub`, `FakeRunner` and a stub handler, covering spec `github-delivery / One pull request per target` scenarios "First findings for a target", "A new finding appears", "Pull request conflicts with its base", "Every bump is blocked", spec `github-delivery / Protected force push`, spec `github-delivery / Branch and commit conventions` scenario "Two bumps applied", and spec `github-delivery / Pull request content and recorded state` scenarios "Marker removed by a person" and "Labels".
- [ ] 7.4 Implement the no-build paths of `D§16.3` (rows 1, 3, 4, 5, 6, 8, 9, 11), including the "new findings" comment added once. Verify: `tests/unit/test_delivery_paths.py` passes, covering the remaining scenarios of spec `github-delivery / One pull request per target` and every scenario of spec `github-delivery / Human commits are never overwritten`.
- [ ] 7.5 Implement escalation issue synchronisation per `D§17`. Verify: `tests/unit/test_escalations.py` passes, covering every scenario of spec `github-delivery / Escalation issues`.
- [ ] 7.6 Implement check follow-up actions per `D§18`. Verify: `tests/unit/test_followup.py` passes, covering every scenario of spec `github-delivery / Check follow-up`.

## 8. Pipeline, summary and notification

- [ ] 8.1 Implement `RunReport` and `TargetReport` in `report.py` and their conversion to the summary JSON of `D§19.1`. Verify: `tests/unit/test_summary.py` passes, covering spec `run-operations / Run summary`.
- [ ] 8.2 Implement the Google Chat text rendering in `report.py` per `D§19.2` as a pure function. Verify: `tests/unit/test_chat_text.py` passes, comparing against an expected text for a mixed run and covering spec `run-operations / Google Chat notification` scenarios "Mixed results", "Nothing to report", "Fatal error message" and "Long message".
- [ ] 8.3 Implement `chat.py` per `D§19.2`. Verify: `tests/unit/test_chat_send.py` passes using `responses`, covering scenarios "Webhook failure" and "Chat disabled" and asserting the webhook URL never appears in captured logs.
- [ ] 8.4 Implement per-target processing in `pipeline.py` (steps 6a to 6j of `D§4`). Verify: `tests/unit/test_pipeline_target.py` passes with fakes for: a requirements target with the `pip-audit` source ending `pr-created`; `unsupported-layout`; `resolve-failed` (spec `python-remediation / Resolved map` scenario "Base branch does not resolve"); a `FindingsError` ending `error` (spec `finding-ingestion / Findings from pip-audit` scenario "Output missing"); and an exception inside a target ending `error`.
- [ ] 8.5 Implement the whole run in `pipeline.py` (steps 1 to 8 of `D§4`): fatal handling, tool check, target loop, clone cleanup, summary, Chat, exit code. Verify: `tests/unit/test_pipeline_run.py` passes, covering spec `run-operations / Target isolation`, spec `run-operations / Exit codes`, the scenario "Summary after a fatal error", spec `finding-ingestion / Local report files`, and spec `finding-ingestion / Only in-scope targets are touched` scenario "Mapped repository without findings".
- [ ] 8.6 Enforce dry run end to end per `D§21.3`. Verify: `tests/unit/test_dry_run.py` passes, covering spec `run-operations / Dry run` and asserting zero recorded mutations in `FakeGitHub`, zero push commands in `FakeRunner` and zero Chat calls.
- [ ] 8.7 Wire `wizfix run` and `wizfix validate` in `cli.py` per `D§6.5`, replacing the stubs. Verify: `tests/unit/test_cli.py` passes by calling `cli.main([...])`, covering spec `run-operations / Command-line interface` and the `Configuration validation` scenarios "Validate with a sample report", "Tool check" and "Valid files".
- [ ] 8.8 Add an idempotency test that runs the pipeline twice against the same `FakeGitHub` state. Verify: `tests/unit/test_idempotent.py` passes, covering spec `run-operations / Idempotent runs` and `run-operations / Deterministic, model-free execution` scenario "Same inputs, same plan".

## 9. Laptop handoff

- [ ] 9.1 Implement `wizfix pending` in `handoff.py` per `D§24.1`, including the `gh auth token` fallback of `D§6.2`. Verify: `tests/unit/test_pending.py` passes, covering every scenario of spec `agent-handoff / Pending work list`.
- [ ] 9.2 Implement `TASK.md` rendering per `D§24.4`. Verify: `tests/unit/test_task_file.py` passes, covering every scenario of spec `agent-handoff / Task file content`.
- [ ] 9.3 Implement `wizfix handoff prepare` per `D§24.2`. Verify: `tests/unit/test_handoff_prepare.py` passes with `FakeRunner`, covering every scenario of spec `agent-handoff / Prepare a work item`, including an assertion that no command starting with `pi` is run.
- [ ] 9.4 Implement `wizfix handoff finish` per `D§24.3`. Verify: `tests/unit/test_handoff_finish.py` passes, covering every scenario of spec `agent-handoff / Finish a work item` except "Daily job respects the human commit", which is covered by task 7.4.

## 10. Documentation

- [ ] 10.1 Write `README.md` sections "What wizfix does", "How a run works" (the diagram of `D§4`), "Configuration" (`D§6.1`, `D§6.2`), "Mapping services to repositories" (`D§6.3`), "Where package findings come from" (the three combinations and the `pip-audit` caveat of `D§13.3`) and "Outcome and reason codes" (a table of every code in `D§21.1` with a one-line meaning). Verify: `tests/unit/test_readme.py` passes; it asserts that every code in `reasons.py` appears in `README.md`.
- [ ] 10.2 Write README sections "Setup" (GitHub App permissions from `proposal.md`, CircleCI context variables and scheduled pipeline from `D§23`, marked "to be verified by the operator") and "First run checklist" (validate with a real header, dry run with `--only` on one repository, real run on one repository, then enable the schedule). Verify: `tests/unit/test_readme.py` asserts both headings exist and every environment variable of `D§6.2` is mentioned.
- [ ] 10.3 Write README sections "Laptop workflow" (`pending`, `handoff prepare`, run the agent, `handoff finish`) and "Running Pi safely" with the required content of `D§24.5`. Verify: `tests/unit/test_readme.py` covers spec `agent-handoff / No language model outside the laptop` scenarios "CI configuration" and "Safe-use documentation".

## 11. Final verification

- [ ] 11.1 Add `scripts/check_scenarios.py` that reads every `#### Scenario:` name from `openspec/changes/add-wiz-remediation-pipeline/specs/**/spec.md` and fails if any name does not appear as `Scenario: <name>` in a docstring under `tests/`. Verify: `uv run python scripts/check_scenarios.py` exits 0.
- [ ] 11.2 Run the safety searches. Verify: `grep -rnE "shell=True|os\.system" src/` prints nothing; `grep -rn "subprocess" src/ | grep -v "src/wizfix/runner.py"` prints nothing; covering spec `run-operations / Safe subprocess execution` scenario "No shell" and spec `run-operations / Deterministic, model-free execution` scenario "Dependency audit" (compare `pyproject.toml` dependencies with `D§5.2`).
- [ ] 11.3 Run the full quality gate. Verify: `uv run ruff check . && uv run ruff format --check . && uv run pytest -m "not integration"` exits 0 with no skipped unit tests.
- [ ] 11.4 Run the integration suite. Verify: `uv run pytest -m integration` passes on a machine with network access and the tools of `D§5.2`, or a `D§22` deviation entry records why it could not be run.
- [ ] 11.5 Validate the specification. Verify: `openspec validate add-wiz-remediation-pipeline --strict` exits 0.

## Workflow follow-up

These steps need a person and real credentials. They are not tracked tasks.

- Fill in `config.yaml` and `mapping.yaml` with real values (`design.md` section 28) and run `wizfix validate --config config.yaml --mapping mapping.yaml --issues-file <a real report>` to confirm the column names.
- Create the GitHub App, install it on the team repositories, and add the CircleCI context `wizfix`.
- Verify the OIDC / Workload Identity Federation step of `.circleci/config.yml` against the organisation's CircleCI and GCP setup.
- Run `wizfix run --dry-run --only <one repo>` locally with `WIZFIX_GITHUB_TOKEN`, read the summary, then run once for real on that repository.
- Create the CircleCI scheduled pipeline with `run_remediation = true`.
- After a week of clean runs, archive this change with `/opsx:archive`.
