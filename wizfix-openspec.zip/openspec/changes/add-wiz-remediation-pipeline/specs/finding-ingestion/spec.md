# Spec Delta

## Purpose

Turn the daily Wiz CSV reports into a validated list of package bumps per
repository target: download the newest report, filter it to in-scope findings,
map each affected resource to a target, and decide which package versions are
needed. Design reference: `design.md` sections 6 to 10, 13 and 14.

## ADDED Requirements

### Requirement: Newest report selection

The system SHALL, for each configured report, select the object in the
configured bucket and prefix whose name ends with `.csv` or `.csv.gz`
(case-insensitive) and whose `updated` timestamp is the greatest, and SHALL
read `.csv.gz` objects through gzip decompression.

#### Scenario: Several reports exist

- **WHEN** the prefix contains `a.csv` updated yesterday, `b.csv` updated today and `notes.txt` updated one minute ago
- **THEN** `b.csv` is downloaded and parsed

#### Scenario: No report exists

- **WHEN** the prefix contains no object ending in `.csv` or `.csv.gz`
- **THEN** the run stops with fatal code `no-report-found` and exit code 2

#### Scenario: Report is stale

- **WHEN** `wiz.max_report_age_hours` is 36 and the newest report was updated 40 hours ago
- **THEN** the run stops with fatal code `report-stale` and exit code 2

#### Scenario: Staleness check disabled

- **WHEN** `wiz.max_report_age_hours` is 0 and the newest report was updated 400 hours ago
- **THEN** the report is used

#### Scenario: Compressed report

- **WHEN** the newest object is `report.csv.gz`
- **THEN** its decompressed content is parsed as CSV

### Requirement: Local report files

The system SHALL read a report from a local file, without contacting GCS for
that report, when `--issues-file` or `--vulns-file` is given.

#### Scenario: Local issues file

- **WHEN** `wizfix run` is started with `--issues-file ./issues.csv`
- **THEN** the Issues report is read from `./issues.csv` and no GCS call is made for the Issues report

### Requirement: Configured columns must exist

The system SHALL verify, before reading any data row, that every column name
configured for a report is present in that report's header, and SHALL NOT
guess, rename or fall back when one is missing.

#### Scenario: A configured column is missing

- **WHEN** `wiz.issues.columns.resource_name` is `Resource Name` and the header has no `Resource Name` column
- **THEN** the run stops with fatal code `missing-columns` and exit code 2
- **AND** the error message lists the missing column names and the actual header

#### Scenario: Header has a byte-order mark

- **WHEN** the file starts with a UTF-8 byte-order mark
- **THEN** the first column name is read without the mark

### Requirement: Issue row scope filter

The system SHALL treat an Issue row as in scope only when its status is in
`include_status`, its severity is at or above `min_severity`, its title matches
`title_include_regex` (or that setting is empty), its control ID is in
`control_ids_include` (or that list is empty), and its resource name is not
empty. Comparisons of status and severity SHALL be case-insensitive.

#### Scenario: Open high-severity vulnerability issue

- **WHEN** a row has status `Open`, severity `High` and title `Serverless with high severity vulnerabilities`, with default configuration
- **THEN** the row is in scope

#### Scenario: Resolved issue

- **WHEN** a row has status `RESOLVED`
- **THEN** the row is not in scope

#### Scenario: Severity below threshold

- **WHEN** `min_severity` is `HIGH` and a row has severity `MEDIUM`
- **THEN** the row is not in scope

#### Scenario: Title does not describe a vulnerability

- **WHEN** `title_include_regex` is `(?i)vulnerab|CVE-` and a row's title is `Public bucket allows anonymous read`
- **THEN** the row is not in scope

#### Scenario: Unknown severity text

- **WHEN** a row's severity is `Unrated`
- **THEN** the row is not in scope and is counted in `rows_bad_severity`

### Requirement: Vulnerability row scope filter

The system SHALL treat a Vulnerability row as in scope only when its status is
in `include_status`, its severity is at or above `min_severity`, its detection
method is in `detection_methods_include` (or that list is empty), and its
package and asset name are not empty.

#### Scenario: Open critical finding

- **WHEN** a row has status `OPEN`, severity `Critical`, package `flask` and asset name `orders-api`
- **THEN** the row is in scope

#### Scenario: Detection method filtered

- **WHEN** `detection_methods_include` is `["LIBRARY"]` and a row's detection method is `PACKAGE`
- **THEN** the row is not in scope

### Requirement: Scope and package source follow the configuration

The system SHALL take scope from Issue rows when `wiz.issues` is configured and
from Vulnerability rows otherwise, and SHALL take packages from Vulnerability
rows when `wiz.vulnerabilities` is configured and from `pip-audit` otherwise.

#### Scenario: Issues report only

- **WHEN** only `wiz.issues` is configured
- **THEN** in-scope targets are those with a mapped in-scope Issue row, and the package source is `pip-audit`

#### Scenario: Both reports

- **WHEN** both blocks are configured
- **THEN** in-scope targets are those with a mapped in-scope Issue row, and the package source is `wiz-vulnerabilities`

#### Scenario: Vulnerabilities report only

- **WHEN** only `wiz.vulnerabilities` is configured
- **THEN** in-scope targets are those with a mapped in-scope Vulnerability row, and the package source is `wiz-vulnerabilities`

#### Scenario: Neither report

- **WHEN** neither block is configured
- **THEN** configuration validation fails with fatal code `invalid-config` and exit code 2

### Requirement: Resource-to-target mapping

The system SHALL map each in-scope row to at most one target using the match
rules in `mapping.yaml`: `resource_name` is a case-insensitive exact match,
`resource_name_glob` is a case-insensitive `fnmatch` pattern, an optional
`subscription` must equal the row's subscription name or subscription ID
case-insensitively, and the first target in file order with a matching rule
wins.

#### Scenario: Exact name with subscription

- **WHEN** a rule is `resource_name: orders-api, subscription: prod-project-1` and a row has resource name `Orders-API` and subscription ID `prod-project-1`
- **THEN** the row maps to that rule's target

#### Scenario: Same name in another project

- **WHEN** the same rule is evaluated against a row with resource name `orders-api` and subscription name `dev-project-9`
- **THEN** the row does not match that rule

#### Scenario: Glob match

- **WHEN** a rule is `resource_name_glob: "*/orders-api@sha256:*"` and a row's name is `europe-docker.pkg.dev/p/r/orders-api@sha256:abc`
- **THEN** the row maps to that rule's target

#### Scenario: Two targets could match

- **WHEN** a row matches a rule of the second target and a rule of the fifth target in the file
- **THEN** the row maps to the second target only

#### Scenario: No target matches

- **WHEN** an in-scope scope-defining row matches no rule
- **THEN** it is recorded as `unmapped`, grouped by resource name and subscription name with a row count

### Requirement: Only in-scope targets are touched

The system SHALL NOT clone, modify, or open a pull request or issue in any
repository that is not an in-scope target of the current run.

#### Scenario: Mapped repository without findings

- **WHEN** `mapping.yaml` lists ten targets and in-scope rows map to two of them
- **THEN** exactly those two repositories are cloned and no GitHub write is made to the other eight

#### Scenario: Restricting a run

- **WHEN** `--only my-org/orders-service` is given and three targets are in scope
- **THEN** only in-scope targets in `my-org/orders-service` are processed

### Requirement: Validation of package names, versions and vulnerability ids

The system SHALL validate every package name, version and vulnerability id read
from a report or a tool before using it, and SHALL NOT pass a value that failed
validation to any command line, file path, branch name or URL.

#### Scenario: Malicious package name

- **WHEN** a Vulnerability row's package is `flask; rm -rf /`
- **THEN** the row yields outcome `invalid-input` and no command is run with that text

#### Scenario: Fixed version lists several versions

- **WHEN** a fixed-version field contains `2.2.5, 2.3.2`
- **THEN** it is parsed as the two versions 2.2.5 and 2.3.2

#### Scenario: Unparseable fixed version token

- **WHEN** a fixed-version field contains `2.2.5, see advisory`
- **THEN** only 2.2.5 is kept

#### Scenario: Pre-release fix

- **WHEN** a fixed-version field contains `3.0.0rc1, 3.0.0`
- **THEN** only 3.0.0 is kept

#### Scenario: Invalid vulnerability id

- **WHEN** a vulnerability id contains a newline or a space
- **THEN** it is replaced by the text `UNKNOWN`

### Requirement: Findings from Vulnerability rows

When the package source is `wiz-vulnerabilities`, the system SHALL create
findings only for packages that are present in the target's resolved map, and
SHALL record every other package as `not-in-repo`.

#### Scenario: Package installed by the repository

- **WHEN** an in-scope row names `flask` with fixed version `2.2.5` and the resolved map contains `flask`
- **THEN** a finding for `flask` with fixed version 2.2.5 is produced

#### Scenario: Operating-system package

- **WHEN** an in-scope row names `openssl` and the resolved map does not contain `openssl`
- **THEN** the row is recorded as `not-in-repo` and produces no bump and no issue

#### Scenario: Name written differently

- **WHEN** a row names `Flask_Login` and the resolved map contains `flask-login`
- **THEN** the row is treated as that package

### Requirement: Findings from pip-audit

When the package source is `pip-audit`, the system SHALL audit exactly the
target's resolved map, SHALL treat `pip-audit` exit codes 0 and 1 as success,
and SHALL build findings from the JSON output without using the description
field.

#### Scenario: Vulnerabilities found

- **WHEN** `pip-audit` exits with code 1 and writes JSON listing `flask 2.0.1` with a vuln whose `fix_versions` is `["2.2.5", "2.3.2"]` and whose aliases include `CVE-2023-30861`
- **THEN** one finding is produced for `flask` with fixed versions 2.2.5 and 2.3.2 and vulnerability id `CVE-2023-30861`

#### Scenario: No vulnerabilities

- **WHEN** `pip-audit` exits with code 0
- **THEN** no findings are produced and this is not an error

#### Scenario: Skipped dependency

- **WHEN** a dependency entry has `skip_reason` and no `vulns`
- **THEN** it is ignored

#### Scenario: Duplicate advisory

- **WHEN** the same advisory `id` appears twice for one package
- **THEN** one finding is produced for it

#### Scenario: Advisory without a CVE alias

- **WHEN** a vuln has id `GHSA-xxxx-yyyy-zzzz` and no alias starting with `CVE-`
- **THEN** the finding's vulnerability id is `GHSA-xxxx-yyyy-zzzz`

#### Scenario: Output missing

- **WHEN** `pip-audit` writes no output file or invalid JSON
- **THEN** the target's outcome is `error` and other targets continue

### Requirement: Target version decision

The system SHALL decide, for a package's current version and one finding's
fixed versions: `no-fix` when there are no fixed versions; `already-fixed` when
a fixed version in the same major.minor series is at or below the current
version, or when no fixed version is above the current version; otherwise a
bump to the lowest fixed version above the current version.

#### Scenario: Lowest fix above current

- **WHEN** current is 2.0.1 and fixed versions are 2.2.5 and 2.3.2
- **THEN** the decision is a bump to 2.2.5

#### Scenario: Current is in a later series that has its own fix

- **WHEN** current is 2.3.0 and fixed versions are 2.2.5 and 2.3.2
- **THEN** the decision is a bump to 2.3.2

#### Scenario: Current series already fixed

- **WHEN** current is 2.2.6 and fixed versions are 2.2.5 and 2.3.2
- **THEN** the decision is `already-fixed`

#### Scenario: Current above every fix

- **WHEN** current is 3.0.0 and fixed versions are 2.2.5 and 2.3.2
- **THEN** the decision is `already-fixed`

#### Scenario: No fixed version

- **WHEN** fixed versions are empty
- **THEN** the decision is `no-fix`

### Requirement: One bump per package

The system SHALL combine all findings of one package in one target into at most
one bump whose target version is the highest of the per-finding bump versions,
and SHALL keep every `no-fix` finding as a separate record.

#### Scenario: Two findings need different versions

- **WHEN** one finding needs `jinja2` 3.1.3 and another needs `jinja2` 3.1.4
- **THEN** one bump of `jinja2` to 3.1.4 is planned, listing both vulnerability ids

#### Scenario: A fixable and an unfixable finding

- **WHEN** a package has one finding needing 3.1.4 and one finding with no fixed version
- **THEN** one bump to 3.1.4 is planned and one `no-fix` record is kept

#### Scenario: Everything already fixed in the repository

- **WHEN** every finding of a package decides `already-fixed`
- **THEN** the package is recorded as `already-fixed` and is not part of the planned set
