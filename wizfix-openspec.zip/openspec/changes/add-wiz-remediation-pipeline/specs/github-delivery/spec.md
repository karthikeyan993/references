# Spec Delta

## Purpose

Deliver bumps to GitHub safely and repeatably: authenticate as a GitHub App,
keep exactly one pull request per target up to date without ever overwriting
human work, raise issues for what could not be fixed, and label pull requests
by their CI result. Design reference: `design.md` sections 15 to 18.

## ADDED Requirements

### Requirement: GitHub authentication

The system SHALL authenticate to the GitHub API with an installation token
obtained from the GitHub App credentials in the environment, SHALL renew that
token before it expires, and SHALL use `WIZFIX_GITHUB_TOKEN` instead when that
variable is set.

#### Scenario: App credentials

- **WHEN** the three `WIZFIX_GITHUB_APP_*` and installation variables are set and `WIZFIX_GITHUB_TOKEN` is not
- **THEN** an installation token is requested and used for API calls and git operations

#### Scenario: Token close to expiry

- **WHEN** the cached installation token expires in less than five minutes
- **THEN** a new token is requested before the next API call

#### Scenario: Token override

- **WHEN** `WIZFIX_GITHUB_TOKEN` is set
- **THEN** that token is used and no App token is requested

#### Scenario: No credentials

- **WHEN** `wizfix run` starts with none of these variables set
- **THEN** the run stops with fatal code `github-auth-failed` and exit code 2

### Requirement: Git credentials are never persisted

The system SHALL pass the token to git only through an `http.extraheader`
command-line configuration value, and SHALL NOT place it in a remote URL, in
`.git/config`, or in any file.

#### Scenario: Clone

- **WHEN** a repository is cloned
- **THEN** the clone URL is `https://github.com/<owner>/<name>.git` with no credentials in it, and `.git/config` of the clone contains no token

#### Scenario: Token in logs

- **WHEN** a git command is logged
- **THEN** the token and its base64 form appear as `***`

### Requirement: Branch and commit conventions

The system SHALL use the branch `wizfix/<slug>` for a target, where the slug is
`root` for path `.` and otherwise the path lower-cased with every run of
characters outside `a-z0-9` replaced by `-`; SHALL create one commit per
applied bump containing only the handler's tracked files; and SHALL author
every commit with the configured bot name and email.

#### Scenario: Root path

- **WHEN** the target path is `.`
- **THEN** the branch is `wizfix/root`

#### Scenario: Nested path

- **WHEN** the target path is `services/Orders_API`
- **THEN** the branch is `wizfix/services-orders-api`

#### Scenario: Two bumps applied

- **WHEN** bumps for `flask` and `werkzeug` are applied
- **THEN** the branch has two commits on top of the base branch, in package-name order, each with subject `fix(deps): bump <package> from <from> to <new version>`

#### Scenario: Unrelated file changed by a tool

- **WHEN** a resolver leaves a cache directory or other untracked file in the clone
- **THEN** it is not part of any commit

### Requirement: One pull request per target

The system SHALL keep at most one open pull request per target, from the
target's `wizfix/` branch to its base branch, and SHALL decide what to do with
it from the planned set of the current run and the planned set recorded in the
newest pull request for that branch.

#### Scenario: First findings for a target

- **WHEN** no pull request has ever existed for the branch and the planned set is not empty
- **THEN** the branch is pushed, a pull request is created, and the target outcome is `pr-created`

#### Scenario: Nothing changed since the last run

- **WHEN** an open pull request with only bot commits records the same planned set as this run and is not in conflict with its base
- **THEN** no git push and no pull request update happens, and the target outcome is `pr-unchanged`

#### Scenario: A new finding appears

- **WHEN** an open pull request with only bot commits records `[flask 2.2.5]` and this run plans `[flask 2.2.5, jinja2 3.1.4]`
- **THEN** the branch is rebuilt from the current base branch with both bumps, force-pushed, the pull request body is updated, and the target outcome is `pr-updated`

#### Scenario: Pull request conflicts with its base

- **WHEN** an open pull request with only bot commits has `mergeable` false and the planned set is unchanged
- **THEN** the branch is rebuilt from the current base branch and force-pushed

#### Scenario: Findings disappear

- **WHEN** an open pull request with only bot commits exists and this run's planned set is empty
- **THEN** the pull request is closed with the "obsolete" comment, its branch is deleted, and the target outcome is `pr-closed-obsolete`

#### Scenario: A person closed the pull request

- **WHEN** the newest pull request for the branch is closed without merge and records the same planned set as this run
- **THEN** nothing is pushed or created and the target outcome is `previously-closed`

#### Scenario: New finding after a person closed the pull request

- **WHEN** the newest pull request is closed without merge and this run's planned set is different and not empty
- **THEN** a new pull request is created

#### Scenario: Previous pull request was merged

- **WHEN** the newest pull request for the branch is merged and the repository already contains its bumps
- **THEN** those packages are `already-fixed`, the planned set is empty, and the target outcome is `nothing-to-fix`

#### Scenario: No finding and no pull request

- **WHEN** no pull request exists and the planned set is empty
- **THEN** nothing is pushed or created and the target outcome is `nothing-to-fix`

#### Scenario: Every bump is blocked

- **WHEN** a build applies no bump
- **THEN** nothing is pushed, no pull request is created, any open bot-only pull request for the branch is closed, and the target outcome is `all-blocked`

### Requirement: Human commits are never overwritten

The system SHALL NOT push to, rebuild, close or delete a `wizfix/` branch whose
open pull request contains at least one commit that is not a bot commit.

#### Scenario: Developer pushed a fix

- **WHEN** an open pull request has a commit whose author email differs from the configured bot email, and this run plans a different set
- **THEN** the branch is left untouched, one "new findings" comment is added, and the target outcome is `pr-has-human-commits`

#### Scenario: Comment is not repeated

- **WHEN** the same situation occurs on the next run with the same planned set
- **THEN** no second "new findings" comment is added

#### Scenario: Findings disappear on a human-edited branch

- **WHEN** an open pull request has a non-bot commit and this run's planned set is empty
- **THEN** the pull request is left open and untouched

### Requirement: Protected force push

The system SHALL replace an existing remote branch only with
`--force-with-lease` bound to the branch head SHA it read from the GitHub API
during the same run.

#### Scenario: Branch moved during the run

- **WHEN** someone pushes to the branch between the API read and the push
- **THEN** the push is rejected, nothing else is changed for that target, and the target outcome is `error` with detail `branch-moved`

#### Scenario: Stale branch without pull request

- **WHEN** the remote branch exists from an earlier merged pull request and a new pull request must be created
- **THEN** the branch is replaced using `--force-with-lease` with its current SHA

### Requirement: Pull request content and recorded state

The system SHALL write a pull request body containing a table of applied bumps
(package, from, to, direct or transitive, vulnerability ids), a table of
blocked bumps with their issue links when any exist, the related Wiz issues,
and, as its last line, a hidden `wizfix-state` marker holding the planned,
applied and blocked sets as JSON.

#### Scenario: State marker round trip

- **WHEN** a pull request body written by one run is read by the next run
- **THEN** the planned set parsed from the marker equals the set that was written

#### Scenario: Marker removed by a person

- **WHEN** the body of an open bot-only pull request has no parseable marker
- **THEN** the recorded set is treated as different and the pull request is rebuilt

#### Scenario: Major version change

- **WHEN** an applied bump moves a package from 2.0.1 to 3.1.9
- **THEN** its row in the table is flagged as a major change and the pull request has the label `major-bump`

#### Scenario: Labels

- **WHEN** a pull request is created or updated
- **THEN** it has the label `wiz-remediation`

### Requirement: Escalation issues

The system SHALL open one issue per escalation key in the target's repository
for every blocked bump (label `needs-agent`), every finding without a fixed
version (label `no-fix`), and every unsupported or unresolvable target (label
`needs-agent`); SHALL NOT create an issue whose key already exists on an open
or closed issue; and SHALL close open issues whose key is no longer needed.

#### Scenario: Blocked bump

- **WHEN** the bump of `jinja2` to 3.1.4 in path `.` is blocked with `resolver-conflict` and no issue has the key `bump|.|jinja2|3.1.4`
- **THEN** an issue is created with labels `wiz-remediation` and `needs-agent`, whose body ends with that key marker and contains the tool output inside a fenced block

#### Scenario: Same blocked bump the next day

- **WHEN** an open issue with that key already exists
- **THEN** no new issue is created

#### Scenario: A person closed the issue

- **WHEN** a closed issue with that key exists and the bump is blocked again
- **THEN** no new issue is created and the closed issue stays closed

#### Scenario: Finding without fix

- **WHEN** `cryptography` has a finding `CVE-2026-0001` with no fixed version
- **THEN** an issue with key `nofix|<path>|cryptography|CVE-2026-0001` and labels `wiz-remediation` and `no-fix` exists after the run

#### Scenario: Problem went away

- **WHEN** an open issue has key `bump|.|jinja2|3.1.4` and this run fully evaluated the target without needing that key
- **THEN** a closing comment is added and the issue is closed

#### Scenario: Target failed this run

- **WHEN** the target's outcome is `error`
- **THEN** no issue of that target is created or closed in this run

#### Scenario: Unsupported layout

- **WHEN** the target outcome is `unsupported-layout`
- **THEN** one issue with key `layout|<path>` and label `needs-agent` exists after the run

### Requirement: Check follow-up

The system SHALL, for every open `wizfix` pull request it did not rebuild in
the current run, compute a check state from the commit statuses and check runs
of the pull request head, ignoring names in `github.ignore_checks`, and SHALL
label and comment accordingly.

#### Scenario: A check failed

- **WHEN** one check run has conclusion `failure`
- **THEN** the pull request gets the label `needs-agent` and one comment naming the failed check with its URL

#### Scenario: Failure already reported

- **WHEN** the same head SHA is evaluated on a later run and still fails
- **THEN** no second comment is added

#### Scenario: Checks pass after a fix

- **WHEN** every status and check run is successful, neutral or skipped and the pull request has the label `needs-agent`
- **THEN** the label is removed

#### Scenario: Checks still running

- **WHEN** at least one check is queued or in progress and none failed
- **THEN** the check state is `pending` and labels are unchanged

#### Scenario: No checks configured

- **WHEN** the head SHA has no statuses and no check runs
- **THEN** the check state is `none` and labels are unchanged

#### Scenario: Ignored check

- **WHEN** the only failing check is named in `github.ignore_checks`
- **THEN** it does not make the check state `failed`

#### Scenario: Rebuilt pull request

- **WHEN** a pull request is rebuilt and force-pushed in this run
- **THEN** the label `needs-agent` is removed and no check state is evaluated for it in this run
