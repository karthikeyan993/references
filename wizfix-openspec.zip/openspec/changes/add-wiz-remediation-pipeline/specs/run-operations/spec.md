# Spec Delta

## Purpose

Define how `wizfix` is run and observed: its command-line interface,
configuration checks, dry-run mode, failure isolation, exit codes, run summary
and Google Chat message, plus the safety rules for subprocesses, secrets and
untrusted text. Design reference: `design.md` sections 4, 6, 13.4 and 19 to 23.

## ADDED Requirements

### Requirement: Command-line interface

The system SHALL provide one executable, `wizfix`, with the subcommands `run`,
`validate`, `pending` and `handoff` (`handoff prepare`, `handoff finish`), and
SHALL print usage and exit with code 2 for an unknown subcommand or a missing
required option.

#### Scenario: Run

- **WHEN** `wizfix run --config config.yaml --mapping mapping.yaml` is executed
- **THEN** the pipeline of `design.md` section 4 runs once

#### Scenario: Missing option

- **WHEN** `wizfix run` is executed without `--config`
- **THEN** usage is printed and the exit code is 2

### Requirement: Configuration validation

The system SHALL validate `config.yaml` and `mapping.yaml` completely before
any network call, SHALL reject unknown keys, wrong types, missing required keys
and rule violations with a message naming the file and key, and SHALL offer the
same checks without running the pipeline through `wizfix validate`.

#### Scenario: Unknown key

- **WHEN** `config.yaml` contains `wiz.buckett`
- **THEN** validation fails with fatal code `invalid-config`, a message naming `wiz.buckett`, and exit code 2

#### Scenario: Duplicate target

- **WHEN** two entries of `mapping.yaml` have the same `repo` and `path`
- **THEN** validation fails with `invalid-config`

#### Scenario: Match rule with both name forms

- **WHEN** a match rule has both `resource_name` and `resource_name_glob`
- **THEN** validation fails with `invalid-config`

#### Scenario: Path escapes the repository

- **WHEN** a target has `path: ../other`
- **THEN** validation fails with `invalid-config`

#### Scenario: Validate with a sample report

- **WHEN** `wizfix validate --config C --mapping M --issues-file sample.csv` is run and a configured column is missing from the sample
- **THEN** the missing column names and the actual header are printed and the exit code is 2

#### Scenario: Tool check

- **WHEN** `wizfix validate --check-tools` is run and `poetry` is not on `PATH`
- **THEN** the output names the missing tool, the fatal code is `missing-tool`, and the exit code is 2

#### Scenario: Valid files

- **WHEN** both files are valid
- **THEN** `wizfix validate` prints the number of targets and exits with code 0

### Requirement: Dry run

The system SHALL, when `--dry-run` is given, perform all reading, cloning,
resolving and local bump work, and SHALL NOT push, create, update, close,
label, comment on or delete anything on GitHub and SHALL NOT send a Chat
message.

#### Scenario: Dry run with findings

- **WHEN** `wizfix run --dry-run` plans two bumps for a target with no pull request
- **THEN** the summary shows outcome `pr-created` for that target with `"dry_run": true`, and no branch, pull request, issue, label or comment exists on GitHub afterwards

#### Scenario: Dry run logs intended writes

- **WHEN** a write would have happened
- **THEN** a log line starting `DRY-RUN would:` describes it

### Requirement: Target isolation

The system SHALL process targets one at a time and SHALL continue with the next
target when one target fails, recording the failed target with outcome `error`
and a detail message.

#### Scenario: One repository is unreachable

- **WHEN** cloning the second of three in-scope targets fails
- **THEN** the first and third targets are processed normally, the second has outcome `error`, and the exit code is 1

#### Scenario: Work directory cleanup

- **WHEN** a target finishes with any outcome
- **THEN** its clone directory no longer exists

### Requirement: Exit codes

The system SHALL exit with code 0 when the run completed and no target has
outcome `error`, code 1 when the run completed and at least one target has
outcome `error`, and code 2 for a fatal error outside the target loop.

#### Scenario: Escalations only

- **WHEN** a run opens two escalation issues and skips one target as `previously-closed`
- **THEN** the exit code is 0

#### Scenario: Fatal error exit code

- **WHEN** the report cannot be found
- **THEN** the exit code is 2 and no target is processed

### Requirement: Idempotent runs

The system SHALL make no change on GitHub when it is run a second time with the
same reports, the same mapping and unchanged repositories.

#### Scenario: Immediate second run

- **WHEN** `wizfix run` completes and is started again with identical inputs
- **THEN** the second run creates no pull request, issue, comment or label, pushes nothing, and reports `pr-unchanged` for targets that have an open bot-only pull request

### Requirement: Run summary

The system SHALL write a JSON summary of the run to the path given by
`--summary-out` and to standard output, containing the run date, the dry-run
flag, the package source, the reports used with row counts, unmapped resources,
and for every in-scope target its outcome, bumps, skipped packages, pull
request and issues.

#### Scenario: Summary after a normal run

- **WHEN** a run finishes
- **THEN** the summary file is valid JSON with the keys `run_date`, `dry_run`, `package_source`, `reports`, `unmapped`, `targets`, `fatal` and `exit_code`

#### Scenario: Summary after a fatal error

- **WHEN** a run stops with a fatal error
- **THEN** the summary file is still written, with `fatal` holding the code and message and `targets` empty

### Requirement: Google Chat notification

The system SHALL post one text message per run to the Google Chat webhook,
grouping results into: new or updated pull requests; pull requests waiting for
review with passed checks; items needing the laptop agent; findings without a
fix; resources not mapped to a repository; skipped targets; and errors.

#### Scenario: Mixed results

- **WHEN** a run creates one pull request, finds one open pull request with failed checks and has two unmapped resources
- **THEN** the message contains the pull request link in the first section, the failed one under "Needs the laptop agent", and both resources under "Not mapped to a repository"

#### Scenario: Nothing to report

- **WHEN** `chat.always_send` is false and there are no in-scope targets, no unmapped rows and no errors
- **THEN** no message is sent

#### Scenario: Fatal error message

- **WHEN** the run stops with a fatal error
- **THEN** a message beginning `*Wiz remediation FAILED*` with the fatal code is sent

#### Scenario: Long message

- **WHEN** the message would exceed `chat.max_chars`
- **THEN** it is cut at the last complete line that fits and ends with a truncation notice

#### Scenario: Webhook failure

- **WHEN** the webhook call fails
- **THEN** the failure is logged and the exit code is unchanged

#### Scenario: Chat disabled

- **WHEN** `chat.enabled` is false
- **THEN** no message is sent

### Requirement: Safe subprocess execution

The system SHALL start every external program through one wrapper that takes
an argument list, never uses a shell, applies a timeout, and passes a minimal
environment that excludes every `WIZFIX_*` variable and
`GOOGLE_APPLICATION_CREDENTIALS` for `uv`, `poetry` and `pip-audit`.

#### Scenario: Resolver environment

- **WHEN** `uv lock` is started while `WIZFIX_GITHUB_APP_PRIVATE_KEY_B64` is set in the parent process
- **THEN** that variable is not present in the child process environment

#### Scenario: Private index credentials

- **WHEN** `UV_INDEX_URL` is set and listed in `resolver.env_passthrough`
- **THEN** it is present in the child process environment

#### Scenario: Timeout

- **WHEN** a command runs longer than `resolver.timeout_seconds`
- **THEN** it is terminated and treated as a failed command with return code 124

#### Scenario: No shell

- **WHEN** the source code is searched for `shell=True`, `os.system` and `subprocess.` outside `runner.py`
- **THEN** there are no matches

### Requirement: Secrets are never written

The system SHALL NOT write the GitHub token, its base64 form, the App private
key or the Chat webhook URL to logs, the summary, pull requests, issues,
comments, commit messages or any file.

#### Scenario: Command logging

- **WHEN** a command whose arguments include the git authorization header is logged
- **THEN** the header value appears as `***`

#### Scenario: Tool output containing a secret

- **WHEN** captured tool output contains the token text
- **THEN** it is replaced by `***` before the output is used in an issue or log

### Requirement: Untrusted text handling

The system SHALL treat CSV fields, repository file content, tool output and
third-party GitHub text as untrusted: it SHALL render such text in Markdown
only as sanitised inline code or inside a fenced block, SHALL link a Wiz URL
only when it is an `https` URL on a `wiz.io` host, and SHALL NOT read the
free-text Wiz columns `Description`, `Remediation Recommendation`, `Note` or
`Resource original JSON` into any output.

#### Scenario: Issue title with a mention

- **WHEN** an Issue row's title is ``@everyone see `this` <b>now</b>``
- **THEN** it appears in the pull request body as inline code with the backticks replaced, so that no mention, link or HTML is rendered

#### Scenario: Unexpected URL

- **WHEN** an Issue row's Wiz URL is `https://evil.example/x`
- **THEN** no link is rendered for that row

#### Scenario: Tool output with a code fence

- **WHEN** tool output contains three consecutive backticks
- **THEN** they are replaced before the output is placed inside a fenced block

### Requirement: Deterministic, model-free execution

The system SHALL NOT call any language model or coding agent, and SHALL NOT
depend on any LLM client library.

#### Scenario: Dependency audit

- **WHEN** the project's declared dependencies are listed
- **THEN** they are exactly the runtime and development dependencies allowed in `design.md` section 5.2

#### Scenario: Same inputs, same plan

- **WHEN** `wizfix run --dry-run` is executed twice with identical inputs and unchanged repositories and package indexes
- **THEN** both summaries are identical apart from timestamps
