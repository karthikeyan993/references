You are searching the code of the service "$service" for places that load a service account key file for $service_account.

Look for: GOOGLE_APPLICATION_CREDENTIALS, from_service_account_file, from_service_account_json, credentials JSON files, key file paths in config, and secrets mounted as key files.

Rules:
- Read only. Do not edit any code.
- List real file paths with line numbers that you actually opened.

Write this JSON file and nothing else to $result_path:
{"files": ["<path>:<line>", "..."], "notes": "<one to three sentences: is a key needed, or can the runtime identity replace it?>"}

Use an empty list when the code never loads a key file.
