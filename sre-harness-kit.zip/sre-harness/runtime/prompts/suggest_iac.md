You are suggesting a Terraform change for a security finding in the service "$service".

Finding: $finding_title
Resource: $resource_name

The resource name appears at these places:
$matches

Rules:
- Read only. Do not edit any file. Your output is a suggestion a person will review.
- Keep the change as small as possible and limited to the resource above.

Write this JSON file and nothing else to $result_path:
{"diff": "<unified diff of the suggested change>", "explanation": "<one to three sentences: what the change does and any risk>"}
