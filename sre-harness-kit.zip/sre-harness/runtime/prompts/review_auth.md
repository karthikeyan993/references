You are reviewing the code of the service "$service" for HTTP routes that have no authentication.

The team declared these paths as intentionally public: $declared_public

Your job:
1. Find where HTTP routes are defined (route tables, decorators, router registrations).
2. For each route, decide if a request without credentials can reach the handler (no auth middleware, no token check, no session check).
3. Ignore the declared public paths listed above.
4. Do not edit any code. Read only.

Write this JSON file and nothing else to $result_path:
{"unprotected_routes": ["<METHOD> <path> (<file>:<line>)", "..."], "notes": "<one to three sentences on how auth works in this service>"}

Use an empty list when every other route requires auth.
