You are fixing a build or test failure in the service "$service".

What already happened (do not redo it):
- The harness upgraded the package "$package" to version $target_version.
- Then it ran the build and tests, and they failed.

Build command: $build_cmd
Test command: $test_cmd

Failure output (last part):
```
$error_output
```

Your job:
1. Read the failure output and find the smallest code change that makes the build and tests pass with $package $target_version.
2. Edit only source files or dependency manifest files. Never edit CI files, Dockerfiles, Terraform or YAML.
3. Do not downgrade $package. Do not remove tests. Do not skip or disable tests.
4. Do not run git commit or git push. The harness does that after checking your work.
5. You may run the build and test commands to check your change.

When you are done, write this JSON file and nothing else to $result_path:
{"status": "fixed" or "not_fixed", "analysis": "<one to three sentences: what broke and what you changed>", "files_changed": ["<path>", "..."]}

If you cannot fix it, still write the file with "status": "not_fixed" and explain why in "analysis".
