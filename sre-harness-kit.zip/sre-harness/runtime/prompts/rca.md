You are ranking likely root causes for an SLO alert on the service "$service".

Alert: $alert_title

The evidence is in this JSON file: $evidence_path
Each item has an id like E1, E2, a kind and a summary. Read the whole file first.
You may also read the service code in the current folder to understand an error message.

Rules:
- Every hypothesis must cite at least one evidence id from the file. Hypotheses that cite ids not in the file are thrown away.
- Rank at most 3 hypotheses, most likely first.
- A change shortly before the alert (a new revision or commits) is a strong signal; say so when it applies.
- Do not invent facts that are not in the evidence or the code.
- Read only. Do not edit any file.

Write this JSON file and nothing else to $result_path:
{"summary": "<one sentence>", "hypotheses": [{"cause": "<what went wrong>", "evidence": ["E2", "E5"], "confidence": "high" | "medium" | "low", "check_next": "<one concrete check>"}], "suspected_commit": "<sha or null>", "suggested_fix": "<one or two sentences>"}
