"""T11: Google Chat messages and delivery (src/sre_harness/chat.py)."""

from fakes import FakeHttp, FixedClock, finding, item
from sre_harness import chat
from sre_harness.models import ActionResult, ChatMessage, EvidenceItem, FindingClass, Outcome, SloAlert
from sre_harness.state import Store


def test_truncate():
    assert chat.truncate("abc") == "abc"
    long = "x" * 5000
    out = chat.truncate(long)
    assert len(out) == chat.MAX_TEXT and out.endswith(chat.TRUNCATION_MARK)


def test_highest_severity():
    assert chat.highest_severity(["low", "CRITICAL", "High"]) == "CRITICAL"
    assert chat.highest_severity(["weird", "medium"]) == "MEDIUM"
    assert chat.highest_severity(["weird", "odd"]) == "WEIRD"
    assert chat.highest_severity(["", " "]) == "UNKNOWN"


def test_render_result_layout():
    findings = [finding(title=f"CVE-{i}", severity="HIGH" if i else "CRITICAL") for i in range(7)]
    wi = item(FindingClass.APP_DEPENDENCY, findings, key="app_dependency:checkout:lodash")
    res = ActionResult(
        wi.key,
        Outcome.PR_OPENED,
        "Upgraded lodash to 4.17.23; build and tests passed",
        details={"target_version": "4.17.23", "files_changed": ["package.json", "package-lock.json"]},
        pr_url="https://github.com/acme/checkout-api/pull/7",
    )
    msg = chat.render_result(wi, res)
    assert msg.thread_key == wi.thread_key
    assert msg.text.splitlines() == [
        "*[PR OPENED]* checkout · lodash",
        "Upgraded lodash to 4.17.23; build and tests passed",
        "Class: app_dependency",
        "Findings: 7 (CVE-0, CVE-1, CVE-2, CVE-3, CVE-4, +2 more)",
        "Severity: CRITICAL",
        "PR: https://github.com/acme/checkout-api/pull/7",
        "files_changed: package.json, package-lock.json",
        "target_version: 4.17.23",
        "Key: `app_dependency:checkout:lodash`",
    ]


def test_render_result_unmapped_and_error_and_base_image():
    wi = item(FindingClass.UNMAPPED, [finding(package=None, title="Bucket is public")], service=None, key="unmapped:b1")
    msg = chat.render_result(wi, ActionResult(wi.key, Outcome.ERROR, "Unexpected error", error="ValueError: x", details={"d": {"b": 1}}))
    lines = msg.text.splitlines()
    assert lines[0] == "*[HARNESS ERROR]* unmapped · Bucket is public"
    assert "Error: ValueError: x" in lines and 'd: {"b": 1}' in lines
    base = item(FindingClass.BASE_IMAGE_OS, [finding(package="openssl")])
    assert chat.render_result(base, ActionResult(base.key, Outcome.REDEPLOY_NEEDED, "s")).text.startswith(
        "*[REDEPLOY NEEDED]* checkout · OS packages in image"
    )


def test_render_error_and_summary():
    err = chat.render_error("ingest", "Wiz report missing", "2026-11-19")
    assert err == ChatMessage("harness-2026-11-19", "*[HARNESS ERROR]* stage: ingest\nWiz report missing")
    s = chat.render_summary(
        "2026-11-19",
        {"recommendation": 2, "pr_opened": 1, "unchanged": 0},
        5,
        1,
        2,
        [("k1", "https://x/1")],
        ["open alert: checkout / avail since t0"],
    )
    assert s.thread_key == "daily-2026-11-19"
    assert s.text.splitlines() == [
        "*[DAILY SUMMARY]* 2026-11-19",
        "New findings: 5 · Resolved: 1 · Skipped rows: 2",
        "Outcomes: pr_opened=1, recommendation=2",
        "PRs open more than 7 days:",
        "- https://x/1 (k1)",
        "SLO:",
        "- open alert: checkout / avail since t0",
    ]
    empty = chat.render_summary("d", {}, 0, 0, 0, [], [])
    assert empty.text.splitlines()[2:] == ["Outcomes: none", "PRs open more than 7 days: none", "SLO: none"]


ALERT = SloAlert(
    "projects/p/alerts/abc", "p", "projects/p/alertPolicies/1", "Checkout availability", "OPEN",
    "2026-11-19T08:00:00Z", "2026-11-19T08:45:00Z", "burn rate high", "checkout", "checkout-availability",
)
EVIDENCE = [EvidenceItem("E1", "alert", "a"), EvidenceItem("E2", "log_signature", "b"), EvidenceItem("E3", "log_signature", "c")]


def test_render_slo_root_cause():
    rca = {"summary": "Pool exhausted", "suspected_commit": "abc123", "suggested_fix": "Roll back"}
    hyps = [{"cause": "Pool too small", "evidence": ["E2", "E3"], "confidence": "high", "check_next": "Compare pool"}]
    msg = chat.render_slo_root_cause(ALERT, rca, hyps, 1, EVIDENCE)
    assert msg.thread_key == "slo-abc"
    assert msg.text.splitlines() == [
        "*[SLO ROOT CAUSE]* checkout · Checkout availability",
        "Opened: 2026-11-19T08:00:00Z",
        "Summary: Pool exhausted",
        "1. Pool too small (confidence: high; evidence: E2, E3)",
        "   Check next: Compare pool",
        "Suspected commit: abc123",
        "Suggested fix: Roll back",
        "Evidence checked: 3 items (alert=1, log_signature=2)",
        "Rejected hypotheses: 1",
    ]


def test_render_slo_insufficient_and_agent_error():
    msg = chat.render_slo_root_cause(ALERT, None, [], 0, EVIDENCE[:1], agent_error="agent timed out")
    lines = msg.text.splitlines()
    assert lines[2] == "Insufficient evidence: no hypothesis cited valid evidence."
    assert lines[-1] == "Agent error: agent timed out"


def test_render_slo_resolved():
    msg = chat.render_slo_resolved(ALERT, 45)
    assert msg.text == (
        "*[SLO RESOLVED]* checkout · Checkout availability\n"
        "Open for 45 min (2026-11-19T08:00:00Z to 2026-11-19T08:45:00Z)"
    )


def test_webhook_url():
    url = "https://chat.googleapis.com/v1/spaces/S/messages?key=K&token=T"
    out = chat.webhook_url(url)
    assert out == url + "&messageReplyOption=REPLY_MESSAGE_FALLBACK_TO_NEW_THREAD"
    again = chat.webhook_url(out)
    assert again.count("messageReplyOption") == 1


def test_payload():
    assert chat.payload(ChatMessage("t", "hi")) == {"text": "hi", "thread": {"threadKey": "t"}}


def test_sender_success_failure_and_flush(tmp_path):
    store = Store(tmp_path / "h.db")
    http = FakeHttp(statuses=[200, 500, 503, 200, 200])
    sender = chat.ChatSender(http, "https://chat/x?key=K", store, FixedClock())
    assert sender.send(ChatMessage("t1", "one")) is True
    assert sender.send(ChatMessage("t2", "two")) is False
    assert store.outbox_pending()[0][1:] == ("t2", "two")
    assert http.posts[0][0].endswith("messageReplyOption=REPLY_MESSAGE_FALLBACK_TO_NEW_THREAD")
    assert http.posts[0][1] == {"text": "one", "thread": {"threadKey": "t1"}}
    assert sender.flush_outbox() == 0
    assert len(store.outbox_pending()) == 1
    store.outbox_add("t3", "three", "c")
    assert sender.flush_outbox() == 2
    assert store.outbox_pending() == []
