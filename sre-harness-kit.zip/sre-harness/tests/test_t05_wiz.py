"""T05: Wiz report finding and parsing (src/sre_harness/wiz.py)."""

import hashlib
from datetime import date

import pytest

from fakes import FIXTURES, FakeRunner, make_cfg
from sre_harness.config import DEFAULT_COLUMNS
from sre_harness.models import FindingKind
from sre_harness.wiz import ReportError, find_report, fingerprint, parse_report, report_prefix, resolve_columns

COLUMNS = dict(DEFAULT_COLUMNS) | {"package_type": ("PackageType",)}


def test_fingerprint_with_wiz_id():
    assert fingerprint("abc", FindingKind.ISSUE, "r", "n", "t", None) == "wiz:abc"


def test_fingerprint_without_wiz_id():
    expected = "wiz:h:" + hashlib.sha256(b"issue|svc-a|Public bucket|").hexdigest()[:16]
    assert fingerprint(None, FindingKind.ISSUE, "", "svc-a", "Public bucket", None) == expected
    expected2 = "wiz:h:" + hashlib.sha256(b"vulnerability|id-1|CVE-1|lodash").hexdigest()[:16]
    assert fingerprint("", FindingKind.VULNERABILITY, "id-1", "name", "CVE-1", "lodash") == expected2


def test_resolve_columns_first_candidate_case_insensitive():
    headers = [" title ", "Name", "resource name"]
    got = resolve_columns(headers, {"title": ("Name", "Title"), "resource_name": ("Resource Name",), "x": ("Nope",)})
    assert got == {"title": "Name", "resource_name": "resource name"}


def parsed():
    return parse_report((FIXTURES / "wiz_report.csv").read_text(encoding="utf-8"), COLUMNS)


def test_parse_fixture_counts():
    findings, skipped = parsed()
    assert [f.wiz_id for f in findings] == ["f1", "f2", "f3", "f4", "f5", "f6", "f7", "f9"]
    assert skipped == 2


def test_parse_fields():
    findings, _ = parsed()
    f1 = findings[0]
    assert f1.fingerprint == "wiz:f1"
    assert f1.kind is FindingKind.VULNERABILITY
    assert (f1.title, f1.severity, f1.package, f1.version, f1.fixed_version) == (
        "CVE-2024-1111",
        "HIGH",
        "lodash",
        "4.17.20",
        "4.17.21",
    )
    assert f1.package_type == "npm"
    assert f1.image.endswith("@sha256:aaa")
    assert f1.raw["ID"] == "f1"
    f4 = findings[3]
    assert f4.fixed_version is None
    f5 = findings[4]
    assert f5.kind is FindingKind.ISSUE and f5.package is None and f5.image is None
    assert f5.remediation == "Remove allUsers from roles/run.invoker"


def test_resource_id_defaults_to_name():
    text = "Name,Resource Name\nCVE-1,svc\n"
    findings, _ = parse_report(text, DEFAULT_COLUMNS)
    assert findings[0].resource_id == "svc" and findings[0].project == "" and findings[0].severity == ""


def test_package_type_lowercased():
    text = "Name,Resource Name,DetailedName,PackageType\nCVE-1,svc,openssl,DEB\n"
    findings, _ = parse_report(text, COLUMNS)
    assert findings[0].package_type == "deb"


def test_missing_required_columns():
    with pytest.raises(ReportError) as exc:
        parse_report("Foo,Bar\n1,2\n", DEFAULT_COLUMNS)
    msg = str(exc.value)
    assert "missing required columns" in msg and "title" in msg and "resource_name" in msg and "Foo" in msg


def test_empty_report():
    with pytest.raises(ReportError):
        parse_report("", DEFAULT_COLUMNS)


def test_report_prefix(tmp_path):
    assert report_prefix(make_cfg(tmp_path), date(2026, 11, 19)) == "gs://acme-wiz-reports/daily/2026-11-19/"


def test_find_report_picks_last_csv(tmp_path):
    runner = FakeRunner().on(
        ["gcloud", "storage", "ls", "gs://acme-wiz-reports/daily/2026-11-19/"],
        stdout="gs://acme-wiz-reports/daily/2026-11-19/a.csv\ngs://acme-wiz-reports/daily/2026-11-19/notes.txt\n"
        "gs://acme-wiz-reports/daily/2026-11-19/b.csv\n",
    )
    assert find_report(runner, make_cfg(tmp_path), date(2026, 11, 19)) == "gs://acme-wiz-reports/daily/2026-11-19/b.csv"


def test_find_report_none_when_no_objects(tmp_path):
    runner = FakeRunner().on(["gcloud", "storage", "ls"], returncode=1, stderr="ERROR: One or more URLs matched no objects.")
    assert find_report(runner, make_cfg(tmp_path), date(2026, 11, 19)) is None
