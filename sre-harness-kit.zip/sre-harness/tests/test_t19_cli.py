"""T19: command line, preflight and the STOP file (src/sre_harness/cli.py)."""

import shutil

import pytest

from fakes import FIXTURES, FakeChat, FakeRunner, make_ctx
from sre_harness import cli
from sre_harness.config import ConfigError


def ready_runner() -> FakeRunner:
    r = FakeRunner()
    r.on(["gcloud", "auth", "print-access-token"], stdout="token")
    r.on(["gh", "auth", "status"])
    r.on(["git", "--version"], stdout="git version 2.45")
    r.on(["opencode", "models"], stdout="github-copilot/claude-haiku-5.5\ngithub-copilot/gpt-6-luna\n")
    r.on(["docker", "version"])
    return r


def test_preflight_ok(tmp_path):
    assert cli.preflight(make_ctx(tmp_path, runner=ready_runner())) == []


def test_preflight_problems_in_order(tmp_path):
    r = FakeRunner()
    r.on(["gcloud"], returncode=1, stderr="Reauthentication required")
    r.on(["gh", "auth", "status"], returncode=1, stderr="")
    r.on(["git", "--version"], returncode=127)
    r.on(["opencode", "models"], stdout="github-copilot/other\n")
    r.on(["docker", "version"], returncode=1)
    assert cli.preflight(make_ctx(tmp_path, runner=r)) == [
        "gcloud auth: Reauthentication required",
        "gh auth: not logged in",
        "git: not installed",
        "opencode: model github-copilot/gpt-6-luna not available; run `opencode models` to list models",
        "docker: not available (set docker.enabled: false to skip image checks)",
    ]


def test_preflight_skips_disabled_tools(tmp_path):
    r = ready_runner().on(["opencode"], returncode=1, stderr="x").on(["docker"], returncode=1)
    assert cli.preflight(make_ctx(tmp_path, runner=r, agent_enabled=False, docker_enabled=False)) == []
    assert cli.preflight(make_ctx(tmp_path / "b", runner=r, docker_enabled=False)) == ["opencode: x"]


def factory_for(ctx):
    return lambda root: ctx


def test_stop_file(tmp_path, capsys):
    ctx = make_ctx(tmp_path, runner=FakeRunner())
    ctx.cfg.stop_file.write_text("")
    assert cli.main(["wiz-run"], context_factory=factory_for(ctx)) == 0
    assert "STOP file present" in capsys.readouterr().out
    assert ctx.runner.calls == []


def test_config_error(capsys):
    def bad(root):
        raise ConfigError("environment variable SRE_CHAT_WEBHOOK is not set")

    assert cli.main(["preflight"], context_factory=bad) == 3
    assert "SRE_CHAT_WEBHOOK" in capsys.readouterr().err


def test_preflight_failure_posts_card(tmp_path):
    chat = FakeChat()
    ctx = make_ctx(tmp_path, runner=FakeRunner().on(["gcloud"], returncode=1, stderr="expired"), chat=chat, agent_enabled=False, docker_enabled=False)
    ctx.runner.on(["gh"]).on(["git"])
    assert cli.main(["wiz-run", "--day", "2026-11-19"], context_factory=factory_for(ctx)) == 2
    assert chat.texts() == ["*[HARNESS ERROR]* stage: preflight\ngcloud auth: expired"]


def test_commands_dispatch(tmp_path, monkeypatch):
    ctx = make_ctx(tmp_path, runner=ready_runner())
    calls = []

    class Result:
        status = "ok"

    monkeypatch.setattr(cli.pipeline, "run_wiz", lambda c, d: calls.append(("wiz", d.isoformat())) or Result())
    monkeypatch.setattr(cli.slo, "run_slo_poll", lambda c: calls.append(("slo", c.day)) or 0)
    assert cli.main(["preflight"], context_factory=factory_for(ctx)) == 0
    assert cli.main(["wiz-run", "--day", "2026-11-18"], context_factory=factory_for(ctx)) == 0
    assert cli.main(["slo-poll", "--day", "2026-11-20"], context_factory=factory_for(ctx)) == 0
    assert cli.main(["flush-outbox"], context_factory=factory_for(ctx)) == 0
    assert calls == [("wiz", "2026-11-18"), ("slo", "2026-11-20")]
    Result.status = "failed"
    assert cli.main(["wiz-run"], context_factory=factory_for(ctx)) == 1


def test_build_context_requires_webhook_env(tmp_path, monkeypatch):
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    for name in ("harness.yaml", "services.yaml", "rules.yaml"):
        shutil.copy(FIXTURES / name, cfg_dir / name)
    monkeypatch.delenv("SRE_CHAT_WEBHOOK", raising=False)
    with pytest.raises(ConfigError, match="SRE_CHAT_WEBHOOK"):
        cli.build_context(tmp_path)
    monkeypatch.setenv("SRE_CHAT_WEBHOOK", "https://chat.googleapis.com/v1/spaces/S/messages?key=K&token=T")
    ctx = cli.build_context(tmp_path)
    assert sorted(ctx.services) == ["checkout", "payments"] and len(ctx.rules) == 7
    assert ctx.runtime_dir == tmp_path / "runtime"
    ctx.store.close()
