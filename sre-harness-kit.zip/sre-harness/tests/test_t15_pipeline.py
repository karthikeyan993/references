"""T15: the daily Wiz run end to end (src/sre_harness/pipeline.py)."""

import json
from datetime import date

import pytest

from fakes import FIXTURES, IMAGE_REPO, LOCK_OLD, FakeAgent, FakeChat, FakeRunner, make_ctx, repo_runner
from sre_harness import pipeline
from sre_harness.models import FindingClass

DAY = date(2026, 11, 19)
PREFIX = "gs://acme-wiz-reports/daily/2026-11-19/"
REPORT = PREFIX + "report.csv"
COLUMNS = {"package_type": ("PackageType",)}


def full_runner() -> FakeRunner:
    r = repo_runner(
        {
            "package.json": "{}",
            "package-lock.json": json.dumps(LOCK_OLD),
            "infra/main.tf": 'resource "x" "db" {\n  name = "payments-db"\n}\n',
        }
    )
    r.on(["gcloud", "storage", "ls", PREFIX], stdout=REPORT + "\n")
    r.on(["gcloud", "storage", "cat", REPORT], stdout=(FIXTURES / "wiz_report.csv").read_text(encoding="utf-8"))
    r.on_json(
        ["gcloud", "run", "services", "describe", "checkout-api"],
        {"status": {"traffic": [{"revisionName": "checkout-api-00042", "percent": 100}]}},
    )
    r.on_json(["gcloud", "run", "revisions", "describe", "checkout-api-00042"], {"status": {"imageDigest": f"{IMAGE_REPO}@sha256:aaa"}})
    r.on_json(["gcloud", "run", "services", "get-iam-policy"], {"bindings": [{"role": "roles/run.invoker", "members": ["allUsers"]}]})
    r.on_json(["gcloud", "iam", "service-accounts", "keys", "list"], [])
    return r


def agent():
    return FakeAgent(
        [
            {"diff": "--- a\n+++ b", "explanation": "Disable public IP"},
            {"files": [], "notes": "no key loaded"},
        ]
    )


def ctx_for(tmp_path, runner=None, chat=None, a=None, **kw):
    from dataclasses import replace

    from sre_harness.config import DEFAULT_COLUMNS

    ctx = make_ctx(tmp_path, runner=runner or full_runner(), agent=a or agent(), chat=chat or FakeChat(), **kw)
    ctx.cfg = replace(ctx.cfg, wiz_columns=dict(DEFAULT_COLUMNS) | COLUMNS)
    return ctx


def tags(chat: FakeChat) -> list[str]:
    return [t.splitlines()[0] for t in chat.texts()]


def test_classify_all(tmp_path):
    from sre_harness.wiz import parse_report

    ctx = ctx_for(tmp_path)
    findings, _ = parse_report((FIXTURES / "wiz_report.csv").read_text(encoding="utf-8"), ctx.cfg.wiz_columns)
    got = [(f.wiz_id, cls, svc) for f, cls, svc in pipeline.classify_all(ctx, findings)]
    assert got == [
        ("f1", FindingClass.APP_DEPENDENCY, "checkout"),
        ("f2", FindingClass.APP_DEPENDENCY, "checkout"),
        ("f3", FindingClass.BASE_IMAGE_OS, "checkout"),
        ("f4", FindingClass.NO_FIX_AVAILABLE, "checkout"),
        ("f5", FindingClass.UNAUTH_ENDPOINT, "checkout"),
        ("f6", FindingClass.SA_KEY, "checkout"),
        ("f7", FindingClass.UNMAPPED, None),
        ("f9", FindingClass.IAC_CONFIG, "payments"),
    ]


def test_full_run(tmp_path):
    chat = FakeChat()
    ctx = ctx_for(tmp_path, chat=chat)
    summary = pipeline.run_wiz(ctx, DAY)
    assert summary.status == "ok" and summary.report_uri == REPORT
    assert (summary.findings, summary.skipped_rows, summary.new_findings, summary.resolved_findings) == (8, 2, 8, 0)
    assert summary.outcomes == {
        "add_mapping": 1,
        "cleanup_recommended": 1,
        "no_fix_yet": 1,
        "pr_opened": 1,
        "recommendation": 3,
    }
    assert tags(chat) == [
        "*[PR OPENED]* checkout · lodash",
        "*[CLEANUP RECOMMENDED]* checkout · OS packages in image",
        "*[RECOMMENDATION]* payments · Database allows public IP",
        "*[NO FIX YET]* checkout · minimist",
        "*[RECOMMENDATION]* checkout · Service account key older than 90 days",
        "*[RECOMMENDATION]* checkout · Cloud Run service allows unauthenticated invocations",
        "*[ADD MAPPING]* unmapped · Bucket is publicly accessible",
        "*[DAILY SUMMARY]* 2026-11-19",
    ]
    assert chat.flushes == 1
    assert chat.messages[-1].text.splitlines()[1] == "New findings: 8 · Resolved: 0 · Skipped rows: 2"
    run = ctx.store.conn.execute("SELECT status FROM runs WHERE id = ?", (summary.run_id,)).fetchone()
    assert run["status"] == "ok"
    assert ctx.store.get_work_item("app_dependency:checkout:lodash")["pr_url"] == "https://github.com/acme/checkout-api/pull/12"


def test_second_run_is_quiet(tmp_path):
    ctx = ctx_for(tmp_path)
    pipeline.run_wiz(ctx, DAY)
    chat2 = FakeChat()
    ctx.chat = chat2
    ctx.agent = FakeAgent()
    summary = pipeline.run_wiz(ctx, DAY)
    assert summary.outcomes == {"unchanged": 7}
    assert tags(chat2) == ["*[DAILY SUMMARY]* 2026-11-19"]
    assert summary.new_findings == 0


def test_resolved_findings_are_counted(tmp_path):
    ctx = ctx_for(tmp_path)
    pipeline.run_wiz(ctx, DAY)
    smaller = "\n".join((FIXTURES / "wiz_report.csv").read_text(encoding="utf-8").splitlines()[:3]) + "\n"
    ctx.runner.on(["gcloud", "storage", "cat", REPORT], stdout=smaller)
    ctx.chat = FakeChat()
    summary = pipeline.run_wiz(ctx, DAY)
    assert summary.resolved_findings == 6


def test_report_missing(tmp_path):
    runner = FakeRunner().on(["gcloud", "storage", "ls"], returncode=1, stderr="matched no objects")
    chat = FakeChat()
    summary = pipeline.run_wiz(ctx_for(tmp_path, runner=runner, chat=chat), DAY)
    assert summary.status == "failed"
    assert chat.messages[0].thread_key == "harness-2026-11-19"
    assert chat.texts() == ["*[HARNESS ERROR]* stage: ingest\nWiz report missing for 2026-11-19"]


def test_bad_report(tmp_path):
    runner = full_runner().on(["gcloud", "storage", "cat", REPORT], stdout="Foo,Bar\n1,2\n")
    chat = FakeChat()
    ctx = ctx_for(tmp_path, runner=runner, chat=chat)
    summary = pipeline.run_wiz(ctx, DAY)
    assert summary.status == "failed"
    assert "missing required columns" in chat.texts()[0]
    row = ctx.store.conn.execute("SELECT status, error FROM runs").fetchone()
    assert row["status"] == "failed" and "missing required columns" in row["error"]


def test_card_limit(tmp_path):
    chat = FakeChat()
    summary = pipeline.run_wiz(ctx_for(tmp_path, chat=chat, max_cards_per_run=2), DAY)
    assert summary.cards_sent == 2 and summary.cards_grouped == 5
    assert len(chat.messages) == 3
    assert "cards_grouped=5" in chat.messages[-1].text


def test_item_exception_becomes_error_card(tmp_path, monkeypatch):
    real = pipeline.playbooks.run_playbook

    def boom(ctx, item, decision):
        if item.key.startswith("unmapped"):
            raise ValueError("kaboom")
        return real(ctx, item, decision)

    monkeypatch.setattr(pipeline.playbooks, "run_playbook", boom)
    chat = FakeChat()
    ctx = ctx_for(tmp_path, chat=chat)
    summary = pipeline.run_wiz(ctx, DAY)
    assert summary.status == "ok"
    err = [t for t in chat.texts() if t.startswith("*[HARNESS ERROR]* unmapped")][0]
    assert "Error: ValueError: kaboom" in err
    assert ctx.store.get_work_item("unmapped:bucket-1") is None


def test_running_images_failure_is_reported_once(tmp_path):
    runner = full_runner().on(["gcloud", "run", "services", "describe"], returncode=1, stderr="403 denied")
    chat = FakeChat()
    pipeline.run_wiz(ctx_for(tmp_path, runner=runner, chat=chat), DAY)
    errors = [t for t in chat.texts() if t.startswith("*[HARNESS ERROR]* stage: reconcile")]
    assert len(errors) == 1 and "checkout: could not read running images" in errors[0]


def test_agent_is_bound_to_run(tmp_path):
    class Bindable(FakeAgent):
        bound = None

        def bind(self, run_id, day):
            self.bound = (run_id, day)

    a = Bindable([{"diff": "", "explanation": "e"}, {"files": [], "notes": ""}])
    summary = pipeline.run_wiz(ctx_for(tmp_path, a=a), DAY)
    assert a.bound == (summary.run_id, "2026-11-19")


@pytest.mark.parametrize("open_alert", [True])
def test_summary_lists_open_slo_alerts(tmp_path, open_alert):
    from sre_harness.models import SloAlert

    chat = FakeChat()
    ctx = ctx_for(tmp_path, chat=chat)
    ctx.store.slo_alert_save(SloAlert("projects/p/alerts/1", "p", "pol", "d", "OPEN", "t0", None, "", "checkout", None), "open")
    pipeline.run_wiz(ctx, DAY)
    assert "- open alert: checkout / unknown since t0" in chat.messages[-1].text
