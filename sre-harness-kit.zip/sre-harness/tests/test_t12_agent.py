"""T12: running opencode agents safely (src/sre_harness/agent.py)."""

import json
from pathlib import Path

import pytest

from fakes import RUNTIME_DIR, FakeRunner, FixedClock, make_cfg
from sre_harness.agent import (
    RESULT_PATH,
    AgentError,
    AgentTask,
    OpencodeAgent,
    build_command,
    changed_files,
    edit_violations,
    glob_match,
    install_profiles,
    load_schema,
    render_prompt,
    validate_result,
)
from sre_harness.models import CommandResult
from sre_harness.state import Store


def test_render_prompt(tmp_path):
    (tmp_path / "t.md").write_text("Fix $package in $service. Cost: $$5")
    assert render_prompt(tmp_path, "t", {"package": "lodash", "service": "checkout"}) == "Fix lodash in checkout. Cost: $5"
    with pytest.raises(AgentError, match="service"):
        render_prompt(tmp_path, "t", {"package": "x"})
    with pytest.raises(AgentError):
        render_prompt(tmp_path, "missing", {})


def test_all_runtime_prompts_render():
    names = {
        "fix_build": ["service", "package", "target_version", "build_cmd", "test_cmd", "error_output"],
        "review_auth": ["service", "declared_public"],
        "find_key_usage": ["service", "service_account"],
        "suggest_iac": ["service", "finding_title", "resource_name", "matches"],
        "rca": ["evidence_path", "service", "alert_title"],
    }
    for name, keys in names.items():
        text = render_prompt(RUNTIME_DIR / "prompts", name, {k: "X" for k in keys} | {"result_path": RESULT_PATH})
        assert RESULT_PATH in text


def test_build_command(tmp_path):
    task = AgentTask("fixer", "fix_build", {}, tmp_path, "fix_result", attachments=("a.json",))
    cmd = build_command(make_cfg(tmp_path), task, "do it")
    assert cmd == [
        "opencode", "run", "--model", "github-copilot/gpt-6-luna", "--agent", "fixer", "--format", "json",
        "--file", "a.json", "do it",
    ]
    assert "--dangerously-skip-permissions" not in cmd
    with pytest.raises(AgentError):
        build_command(make_cfg(tmp_path), AgentTask("hacker", "x", {}, tmp_path, "s"), "p")


def test_install_profiles(tmp_path):
    out = install_profiles(RUNTIME_DIR / "opencode" / "agents", tmp_path)
    assert [p.name for p in out] == ["fixer.md", "rca.md", "reviewer.md"]
    assert (tmp_path / ".opencode" / "agents" / "reviewer.md").read_text().startswith("---")


def test_schemas_validate():
    schema = load_schema(RUNTIME_DIR / "schemas", "rca_result")
    good = {"summary": "s", "hypotheses": [{"cause": "c", "evidence": ["E1"], "confidence": "high"}]}
    assert validate_result(good, schema) == []
    bad = {"summary": "s", "hypotheses": [{"cause": "c", "evidence": ["X1"], "confidence": "sure"}], "extra": 1}
    errors = validate_result(bad, schema)
    assert any(e.startswith("hypotheses/0/confidence:") for e in errors)
    assert any(e.startswith("hypotheses/0/evidence/0:") for e in errors)
    assert any(e.startswith(": ") for e in errors)
    assert errors == sorted(errors)
    with pytest.raises(AgentError):
        load_schema(RUNTIME_DIR / "schemas", "nope")


def test_changed_files(tmp_path):
    runner = FakeRunner().on(
        ["git", "status"],
        stdout=' M src/a.py\n?? new file.txt\nR  old.py -> src/b.py\n?? .sre/result.json\n M .opencode/agents/x.md\n?? "q.txt"\n',
    )
    assert changed_files(runner, tmp_path) == ["new file.txt", "q.txt", "src/a.py", "src/b.py"]
    assert runner.calls[0] == (("git", "status", "--porcelain=v1", "--untracked-files=all"), str(tmp_path))
    with pytest.raises(AgentError):
        changed_files(FakeRunner().on(["git"], returncode=128, stderr="not a repo"), tmp_path)


def test_glob_and_violations():
    assert glob_match("a.py", "**/*.py") and glob_match("src/a.py", "**/*.py")
    assert not glob_match("Dockerfile", "**/*.py")
    assert edit_violations(["src/a.py", "Dockerfile"], ["**/*.py"]) == ["Dockerfile"]
    assert edit_violations(["b.txt", "a.txt"], []) == ["a.txt", "b.txt"]


def make_agent(tmp_path, runner, **cfg_overrides):
    store = Store(tmp_path / "h.db")
    cfg = make_cfg(tmp_path, **cfg_overrides)
    return OpencodeAgent(runner, cfg, store, FixedClock(), RUNTIME_DIR, 7, "2026-11-19"), store


def writer(result, rc=0, stderr=""):
    def handler(args, cwd):
        if result is not None:
            path = Path(cwd) / RESULT_PATH
            path.write_text(result if isinstance(result, str) else json.dumps(result))
        return CommandResult(tuple(args), rc, "", stderr)

    return handler


def task(tmp_path, **kw):
    base = dict(agent="reviewer", prompt_name="review_auth", variables={"service": "checkout", "declared_public": "/healthz"},
                workdir=tmp_path / "wt", schema_name="review_auth", key="k1")
    base.update(kw)
    (tmp_path / "wt").mkdir(exist_ok=True)
    return AgentTask(**base)


def test_run_happy_path(tmp_path):
    runner = FakeRunner().on(["opencode"], handler=writer({"unprotected_routes": [], "notes": "all good"}))
    agent, store = make_agent(tmp_path, runner)
    out = agent.run(task(tmp_path))
    assert out == {"unprotected_routes": [], "notes": "all good"}
    args, cwd = runner.calls[0]
    assert args[:6] == ("opencode", "run", "--model", "github-copilot/gpt-6-luna", "--agent", "reviewer")
    assert ".sre/result.json" in args[-1] and "/healthz" in args[-1]
    assert cwd == str(tmp_path / "wt")
    assert (tmp_path / "wt" / ".opencode" / "agents" / "reviewer.md").exists()
    row = store.conn.execute("SELECT * FROM actions").fetchone()
    assert (row["run_id"], row["kind"], row["outcome"], row["model"], row["key"]) == (7, "agent_call", "ok", "github-copilot/gpt-6-luna", "k1")
    assert json.loads(row["detail_json"]) == {"agent": "reviewer", "returncode": 0}


def test_run_removes_stale_result(tmp_path):
    t = task(tmp_path)
    (t.workdir / ".sre").mkdir(parents=True)
    (t.workdir / RESULT_PATH).write_text(json.dumps({"unprotected_routes": [], "notes": "old"}))
    agent, _ = make_agent(tmp_path, FakeRunner().on(["opencode"], handler=writer(None)))
    with pytest.raises(AgentError, match="no result file"):
        agent.run(t)


@pytest.mark.parametrize(
    "handler, needle",
    [
        (writer(None, rc=124), "timed out"),
        (writer(None, rc=1, stderr="boom"), "agent exited 1: boom"),
        (writer("not json"), "not valid JSON"),
        (writer({"unprotected_routes": "x", "notes": "n"}), "does not match schema"),
    ],
)
def test_run_failures(tmp_path, handler, needle):
    agent, store = make_agent(tmp_path, FakeRunner().on(["opencode"], handler=handler))
    with pytest.raises(AgentError, match=needle):
        agent.run(task(tmp_path))
    assert store.count_actions("agent_call", "2026-11-19") == 1


def test_disabled_and_cap(tmp_path):
    agent, _ = make_agent(tmp_path, FakeRunner(), agent_enabled=False)
    with pytest.raises(AgentError, match="disabled"):
        agent.run(task(tmp_path))
    runner = FakeRunner().on(["opencode"], handler=writer({"unprotected_routes": [], "notes": ""}))
    agent2, store2 = make_agent(tmp_path / "b", runner, agent_max_calls_per_day=1)
    agent2.run(task(tmp_path / "b"))
    with pytest.raises(AgentError, match="cap"):
        agent2.run(task(tmp_path / "b"))
    assert len(runner.calls) == 1


def test_forbidden_edits_in_git_tree(tmp_path):
    t = task(tmp_path, agent="fixer", prompt_name="fix_build", schema_name="fix_result",
             variables={"service": "s", "package": "p", "target_version": "1", "build_cmd": "b", "test_cmd": "t", "error_output": "e"},
             allowed_edit_globs=("**/*.py",))
    (t.workdir / ".git").write_text("gitdir: elsewhere")
    runner = FakeRunner().on(["opencode"], handler=writer({"status": "fixed", "analysis": "changed import"}))
    runner.on(["git", "status"], stdout=" M src/app.py\n M Dockerfile\n")
    agent, _ = make_agent(tmp_path, runner)
    with pytest.raises(AgentError, match="may not touch: Dockerfile"):
        agent.run(t)


def test_no_edit_check_outside_git(tmp_path):
    runner = FakeRunner().on(["opencode"], handler=writer({"unprotected_routes": [], "notes": ""}))
    agent, _ = make_agent(tmp_path, runner)
    agent.run(task(tmp_path))
    assert not runner.called(["git"])


def test_bind(tmp_path):
    agent, _ = make_agent(tmp_path, FakeRunner())
    agent.bind(99, "2026-12-01")
    assert (agent.run_id, agent.day) == (99, "2026-12-01")
