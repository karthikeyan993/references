"""T02: config loading and validation (src/sre_harness/config.py)."""

import shutil
import textwrap
from pathlib import Path

import pytest

from fakes import FIXTURES
from sre_harness.config import DEFAULT_COLUMNS, ConfigError, load_harness_config, load_rules, load_services
from sre_harness.models import FindingClass


def write(tmp_path: Path, name: str, text: str) -> Path:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir(exist_ok=True)
    p = cfg_dir / name
    p.write_text(textwrap.dedent(text), encoding="utf-8")
    return p


MINIMAL = """
chat: {webhook_url_env: HOOK}
wiz: {report_uri_template: "gs://b/{date}/"}
agent: {model: github-copilot/gpt-6-luna}
"""


# ---------- harness.yaml ----------

def test_fixture_harness_loads(tmp_path):
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    shutil.copy(FIXTURES / "harness.yaml", cfg_dir / "harness.yaml")
    cfg = load_harness_config(cfg_dir / "harness.yaml")
    assert cfg.root == tmp_path.resolve()
    assert cfg.chat_webhook_env == "SRE_CHAT_WEBHOOK"
    assert cfg.gcp_impersonate == "sre-ro@ops-project.iam.gserviceaccount.com"
    assert cfg.slo_projects == ("prod-project",)
    assert cfg.agent_max_calls_per_day == 10
    assert cfg.max_prs_per_day == 3
    assert cfg.workdir == (tmp_path / "work").resolve()
    assert cfg.state_db == (tmp_path / "state" / "test.db").resolve()
    assert cfg.wiz_columns["package_type"] == ("PackageType",)
    assert cfg.wiz_columns["title"] == DEFAULT_COLUMNS["title"]


def test_defaults(tmp_path):
    cfg = load_harness_config(write(tmp_path, "harness.yaml", MINIMAL))
    assert cfg.wiz_report_suffix == ".csv"
    assert cfg.gcp_impersonate is None
    assert cfg.slo_projects == ()
    assert cfg.slo_logs_lookback_minutes == 120
    assert cfg.slo_revision_lookback_hours == 24
    assert cfg.agent_enabled is True
    assert cfg.agent_binary == "opencode"
    assert cfg.agent_timeout_seconds == 900
    assert cfg.agent_max_calls_per_day == 40
    assert cfg.max_prs_per_day == 5
    assert cfg.max_cards_per_run == 30
    assert cfg.max_changed_lines == 300
    assert cfg.docker_enabled is True
    assert cfg.wiki_dir == (tmp_path / "wiki").resolve()
    assert cfg.stop_file == (tmp_path / "STOP").resolve()
    assert cfg.workdir == (Path.home() / ".sre-harness" / "work")


def test_empty_impersonation_means_none(tmp_path):
    cfg = load_harness_config(write(tmp_path, "harness.yaml", MINIMAL + "gcp: {impersonate_service_account: ''}\n"))
    assert cfg.gcp_impersonate is None


@pytest.mark.parametrize(
    "extra, needle",
    [
        ("colour: blue\n", "colour"),
        ("agent: {model: m, modle: x}\n", "agent.modle"),
        ("limits: {max_prs_per_day: 0}\n", "limits.max_prs_per_day"),
        ("limits: {max_prs_per_day: two}\n", "limits.max_prs_per_day"),
        ("wiz: {report_uri_template: 'gs://b/{date}/', columns: {colour: [X]}}\n", "wiz.columns.colour"),
    ],
)
def test_harness_errors_name_the_key(tmp_path, extra, needle):
    text = MINIMAL + extra
    if extra.startswith("agent:"):
        text = text.replace("agent: {model: github-copilot/gpt-6-luna}\n", "")
    if extra.startswith("wiz:"):
        text = text.replace('wiz: {report_uri_template: "gs://b/{date}/"}\n', "")
    with pytest.raises(ConfigError) as exc:
        load_harness_config(write(tmp_path, "harness.yaml", text))
    assert needle in str(exc.value)
    assert "harness.yaml" in str(exc.value)


@pytest.mark.parametrize(
    "text, needle",
    [
        ('wiz: {report_uri_template: "gs://b/{date}/"}\nagent: {model: m}\n', "chat.webhook_url_env"),
        ("chat: {webhook_url_env: H}\nagent: {model: m}\n", "wiz.report_uri_template"),
        ('chat: {webhook_url_env: H}\nwiz: {report_uri_template: "gs://b/{date}/"}\n', "agent.model"),
        ('chat: {webhook_url_env: H}\nwiz: {report_uri_template: "s3://b/{date}/"}\nagent: {model: m}\n', "gs://"),
        ('chat: {webhook_url_env: H}\nwiz: {report_uri_template: "gs://b/today/"}\nagent: {model: m}\n', "{date}"),
    ],
)
def test_harness_required_keys(tmp_path, text, needle):
    with pytest.raises(ConfigError) as exc:
        load_harness_config(write(tmp_path, "harness.yaml", text))
    assert needle in str(exc.value)


def test_missing_file(tmp_path):
    with pytest.raises(ConfigError):
        load_harness_config(tmp_path / "config" / "nope.yaml")


# ---------- services.yaml ----------

def test_fixture_services_load():
    services = load_services(FIXTURES / "services.yaml")
    assert sorted(services) == ["checkout", "payments"]
    c = services["checkout"]
    assert c.repo == "github.com/acme/checkout-api"
    assert c.runtime.kind == "cloud-run" and c.runtime.region == "europe-west1"
    assert c.ecosystem == "npm"
    assert c.images == ("europe-west1-docker.pkg.dev/prod-project/apps/checkout-api",)
    assert c.service_accounts == ("checkout-api@prod-project.iam.gserviceaccount.com",)
    p = services["payments"]
    assert p.branch == "main" and p.build == "" and p.dockerfile == "Dockerfile"
    assert p.runtime.kind == "none" and p.terraform_dir == "infra"
    assert p.resources == ("payments-db",)


SVC = """
services:
  a:
    repo: github.com/o/a
    runtime: {kind: none}
"""


@pytest.mark.parametrize(
    "patch, needle",
    [
        ("    colour: red\n", "a.colour"),
        ("    ecosystem: cobol\n", "a.ecosystem"),
        ("    images: [r.io/p/a:1.0]\n", "tag or digest"),
        ("    images: [r.io/p/a@sha256:abc]\n", "tag or digest"),
        ("    owners: owner-a\n", "a.owners"),
    ],
)
def test_service_errors(tmp_path, patch, needle):
    with pytest.raises(ConfigError) as exc:
        load_services(write(tmp_path, "services.yaml", SVC + patch))
    assert needle in str(exc.value)
    assert "services.yaml" in str(exc.value)


def test_service_bad_repo(tmp_path):
    with pytest.raises(ConfigError) as exc:
        load_services(write(tmp_path, "services.yaml", SVC.replace("github.com/o/a", "gitlab.com/o/a")))
    assert "a.repo" in str(exc.value)


def test_service_cloud_run_needs_location(tmp_path):
    text = SVC.replace("{kind: none}", "{kind: cloud-run, project: p, name: a}")
    with pytest.raises(ConfigError) as exc:
        load_services(write(tmp_path, "services.yaml", text))
    assert "a.runtime.region" in str(exc.value)


def test_service_unknown_runtime_kind(tmp_path):
    with pytest.raises(ConfigError) as exc:
        load_services(write(tmp_path, "services.yaml", SVC.replace("{kind: none}", "{kind: gke}")))
    assert "a.runtime.kind" in str(exc.value)


def test_registry_port_is_not_a_tag(tmp_path):
    services = load_services(write(tmp_path, "services.yaml", SVC + "    images: [localhost:5000/team/a]\n"))
    assert services["a"].images == ("localhost:5000/team/a",)


def test_duplicate_image_across_services(tmp_path):
    text = SVC + "    images: [r.io/p/x]\n  b:\n    repo: github.com/o/b\n    runtime: {kind: none}\n    images: [r.io/p/x]\n"
    with pytest.raises(ConfigError) as exc:
        load_services(write(tmp_path, "services.yaml", text))
    assert "a" in str(exc.value) and "b" in str(exc.value)


# ---------- rules.yaml ----------

def test_fixture_rules_load():
    rules = load_rules(FIXTURES / "rules.yaml")
    assert [r.name for r in rules][0] == "no-fix-yet"
    assert rules[-1].finding_class is FindingClass.UNCLASSIFIED and dict(rules[-1].when) == {}
    assert rules[1].when["package_type"] == {"in": ["deb", "dpkg", "apk", "rpm", "os"]}


def rules_text(body: str) -> str:
    return "rules:\n" + body + "  - {name: last, class: unclassified, when: {}}\n"


@pytest.mark.parametrize(
    "body, needle",
    [
        ("  - {name: r1, class: nonsense, when: {}}\n", "r1.class"),
        ("  - {name: r1, class: unmapped, when: {}}\n", "unmapped"),
        ("  - {name: r1, class: sa_key, when: {colour: red}}\n", "r1.when.colour"),
        ("  - {name: r1, class: sa_key, when: {title: {like: x}}}\n", "r1.when.title"),
        ("  - {name: r1, class: sa_key, when: {title: {in: x}}}\n", "r1.when.title.in"),
        ("  - {name: r1, class: sa_key, when: {title: {regex: '('}}}\n", "r1.when.title.regex"),
        ("  - {name: r1, class: sa_key, when: {title: {empty: maybe}}}\n", "r1.when.title.empty"),
        ("  - {name: last, class: sa_key, when: {}}\n", "duplicate"),
        ("  - {class: sa_key, when: {}}\n", "name"),
    ],
)
def test_rule_errors(tmp_path, body, needle):
    with pytest.raises(ConfigError) as exc:
        load_rules(write(tmp_path, "rules.yaml", rules_text(body)))
    assert needle in str(exc.value)
    assert "rules.yaml" in str(exc.value)


def test_last_rule_must_be_catch_all(tmp_path):
    text = "rules:\n  - {name: r1, class: sa_key, when: {kind: issue}}\n"
    with pytest.raises(ConfigError) as exc:
        load_rules(write(tmp_path, "rules.yaml", text))
    assert "catch-all" in str(exc.value)


def test_last_rule_catch_all_needs_unclassified(tmp_path):
    text = "rules:\n  - {name: r1, class: sa_key, when: {}}\n"
    with pytest.raises(ConfigError) as exc:
        load_rules(write(tmp_path, "rules.yaml", text))
    assert "catch-all" in str(exc.value)
