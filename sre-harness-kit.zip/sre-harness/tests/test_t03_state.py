"""T03: SQLite state store (src/sre_harness/state.py)."""

import json
from datetime import date

import pytest

from fakes import finding, item
from sre_harness.models import FindingClass, Outcome, SloAlert
from sre_harness.state import Store


@pytest.fixture
def store(tmp_path):
    s = Store(tmp_path / "nested" / "harness.db")
    yield s
    s.close()


def test_creates_parent_folder_and_is_idempotent(tmp_path):
    path = tmp_path / "a" / "b" / "h.db"
    Store(path).close()
    Store(path).close()
    assert path.exists()


def test_memory_store():
    s = Store(":memory:")
    assert s.start_run("wiz", "2026-11-19", "t0") == 1


def test_runs(store):
    rid = store.start_run("wiz", "2026-11-19", "2026-11-19T09:30:00+00:00")
    store.finish_run(rid, "failed", "2026-11-19T09:31:00+00:00", "boom")
    row = store.conn.execute("SELECT * FROM runs WHERE id = ?", (rid,)).fetchone()
    assert (row["kind"], row["status"], row["error"]) == ("wiz", "failed", "boom")
    assert row["finished"] == "2026-11-19T09:31:00+00:00"


def test_upsert_finding_new_then_existing(store):
    f = finding()
    assert store.upsert_finding(f, "checkout", FindingClass.APP_DEPENDENCY, "2026-11-18") is True
    assert store.upsert_finding(f, "checkout", FindingClass.APP_DEPENDENCY, "2026-11-19") is False
    row = store.conn.execute("SELECT * FROM findings").fetchone()
    assert (row["first_seen"], row["last_seen"], row["status"]) == ("2026-11-18", "2026-11-19", "open")


def test_resolve_missing_and_reopen(store):
    a, b = finding(fingerprint="wiz:a"), finding(fingerprint="wiz:b")
    store.upsert_finding(a, "checkout", FindingClass.APP_DEPENDENCY, "2026-11-18")
    store.upsert_finding(b, "checkout", FindingClass.APP_DEPENDENCY, "2026-11-18")
    assert store.resolve_missing({"wiz:a"}, "2026-11-19") == ["wiz:b"]
    assert store.resolve_missing({"wiz:a"}, "2026-11-19") == []
    assert store.upsert_finding(b, "checkout", FindingClass.APP_DEPENDENCY, "2026-11-20") is True


def test_work_items_and_unchanged(store):
    wi = item(FindingClass.APP_DEPENDENCY, [finding()], key="app_dependency:checkout:lodash")
    assert store.get_work_item(wi.key) is None
    assert store.is_unchanged(wi) is False
    store.save_work_item(wi, Outcome.PR_OPENED, "2026-11-19", "https://github.com/acme/x/pull/1")
    row = store.get_work_item(wi.key)
    assert row["outcome"] == "pr_opened" and row["thread_key"] == wi.thread_key and row["signature"] == wi.signature
    assert store.is_unchanged(wi) is True
    changed = item(FindingClass.APP_DEPENDENCY, [finding(fixed_version="9.9.9")], key=wi.key)
    assert store.is_unchanged(changed) is False
    store.save_work_item(wi, Outcome.RECOMMENDATION, "2026-11-20")
    assert store.get_work_item(wi.key)["pr_url"] == "https://github.com/acme/x/pull/1"


def test_non_terminal_outcome_is_not_unchanged(store):
    wi = item(FindingClass.APP_DEPENDENCY, [finding()])
    store.save_work_item(wi, Outcome.DEFERRED, "2026-11-19")
    assert store.is_unchanged(wi) is False


def test_open_prs_older_than(store):
    old = item(FindingClass.APP_DEPENDENCY, [finding()], key="k-old")
    new = item(FindingClass.APP_DEPENDENCY, [finding()], key="k-new")
    nourl = item(FindingClass.APP_DEPENDENCY, [finding()], key="k-nourl")
    store.save_work_item(old, Outcome.PR_OPENED, "2026-11-10", "https://x/1")
    store.save_work_item(new, Outcome.PR_OPENED, "2026-11-18", "https://x/2")
    store.save_work_item(nourl, Outcome.PR_OPENED, "2026-11-01")
    assert store.open_prs_older_than(7, date(2026, 11, 19)) == [("k-old", "https://x/1")]


def test_actions_counts(store):
    store.record_action(1, "2026-11-19", "k1", "playbook", outcome="pr_opened", detail={"b": 1, "a": 2})
    store.record_action(1, "2026-11-19", "k2", "playbook", outcome="pr_opened")
    store.record_action(1, "2026-11-19", "k3", "playbook", outcome="recommendation")
    store.record_action(2, "2026-11-19", "k4", "playbook", outcome="recommendation")
    store.record_action(1, "2026-11-19", "k1", "agent_call", outcome="ok", model="m", duration_s=1.5)
    store.record_action(1, "2026-11-18", "k1", "agent_call")
    assert store.count_actions("agent_call", "2026-11-19") == 1
    assert store.count_actions("playbook", "2026-11-19") == 4
    assert store.outcome_counts(1) == {"pr_opened": 2, "recommendation": 1}
    detail = store.conn.execute("SELECT detail_json FROM actions WHERE key='k1' AND kind='playbook'").fetchone()[0]
    assert detail == json.dumps({"b": 1, "a": 2}, sort_keys=True)


def test_outbox(store):
    a = store.outbox_add("t1", "hello", "c1")
    b = store.outbox_add("t2", "world", "c2")
    assert store.outbox_pending() == [(a, "t1", "hello"), (b, "t2", "world")]
    store.outbox_mark_sent(a, "s1")
    assert store.outbox_pending() == [(b, "t2", "world")]


def test_slo_alerts(store):
    alert = SloAlert("projects/p/alerts/1", "p", "pol", "Checkout availability", "OPEN", "t0", None, "", "checkout", "avail")
    store.slo_alert_save(alert, "open", "/wiki/x.md")
    assert store.slo_alert_get("projects/p/alerts/1")["wiki_path"] == "/wiki/x.md"
    assert [r["alert_id"] for r in store.slo_alerts_open()] == ["projects/p/alerts/1"]
    store.slo_alert_save(alert, "closed")
    assert store.slo_alert_get("projects/p/alerts/1")["wiki_path"] == "/wiki/x.md"
    assert store.slo_alerts_open() == []
