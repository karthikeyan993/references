"""T06: mapping findings to services (src/sre_harness/mapping.py)."""

from dataclasses import replace

import pytest

from fakes import CHECKOUT, IMAGE_REPO, SERVICES, finding
from sre_harness.mapping import image_repo, map_finding, split_image


@pytest.mark.parametrize(
    "ref, expected",
    [
        ("r.io/p/app:1.2@sha256:ab", ("r.io/p/app", "1.2", "sha256:ab")),
        ("localhost:5000/app", ("localhost:5000/app", None, None)),
        ("localhost:5000/app:7", ("localhost:5000/app", "7", None)),
        ("app@sha256:ab", ("app", None, "sha256:ab")),
        ("python:3.12-slim", ("python", "3.12-slim", None)),
    ],
)
def test_split_image(ref, expected):
    assert split_image(ref) == expected


def test_image_repo():
    assert image_repo(f"{IMAGE_REPO}:abc@sha256:1") == IMAGE_REPO


def test_map_by_image():
    r = map_finding(finding(), SERVICES)
    assert (r.service, r.reason) == ("checkout", "image")


def test_map_by_runtime_name():
    f = finding(image=None, resource_name="checkout-api", project="prod-project", package=None)
    assert map_finding(f, SERVICES).reason == "runtime"
    f2 = finding(image=None, resource_name="checkout-api", project="", package=None)
    assert map_finding(f2, SERVICES).service == "checkout"


def test_runtime_name_in_other_project_does_not_match():
    f = finding(image=None, resource_name="checkout-api", project="staging", package=None)
    assert map_finding(f, SERVICES).service is None


def test_map_by_service_account_and_resource():
    sa = finding(image=None, resource_name="checkout-api@prod-project.iam.gserviceaccount.com")
    assert (map_finding(sa, SERVICES).service, map_finding(sa, SERVICES).reason) == ("checkout", "service_account")
    db = finding(image=None, resource_name="x", resource_id="payments-db")
    assert (map_finding(db, SERVICES).service, map_finding(db, SERVICES).reason) == ("payments", "resource")


def test_no_match():
    r = map_finding(finding(image=None, resource_name="legacy-bucket", resource_id="b1"), SERVICES)
    assert (r.service, r.reason) == (None, "no match")


def test_image_wins_over_later_steps():
    other = replace(CHECKOUT, name="other", images=(), service_accounts=(), resources=("checkout-api",))
    r = map_finding(finding(), {"checkout": CHECKOUT, "other": other})
    assert r.service == "checkout"


def test_ambiguous():
    twin = replace(CHECKOUT, name="twin", images=())
    r = map_finding(finding(image=None), {"checkout": CHECKOUT, "twin": twin})
    assert r.service is None and r.reason == "ambiguous: checkout, twin"
