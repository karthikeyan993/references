"""T01: environment and provided types. These pass before you write any code."""

import hashlib

from fakes import finding, item
from sre_harness.models import TERMINAL_OUTCOMES, CommandResult, FindingClass, Outcome


def test_thread_key_is_stable_and_short():
    wi = item(FindingClass.APP_DEPENDENCY, [finding()], key="app_dependency:checkout:lodash")
    expected = "wiz-" + hashlib.sha256(b"app_dependency:checkout:lodash").hexdigest()[:12]
    assert wi.thread_key == expected


def test_signature_changes_when_fixed_version_changes():
    a = item(FindingClass.APP_DEPENDENCY, [finding(fixed_version="1.0.1")])
    b = item(FindingClass.APP_DEPENDENCY, [finding(fixed_version="1.0.2")])
    assert a.signature != b.signature


def test_signature_ignores_finding_order():
    f1, f2 = finding(fingerprint="wiz:a"), finding(fingerprint="wiz:b")
    assert item(FindingClass.APP_DEPENDENCY, [f1, f2]).signature == item(FindingClass.APP_DEPENDENCY, [f2, f1]).signature


def test_terminal_outcomes_exclude_retryable_ones():
    for retry in (Outcome.DEFERRED, Outcome.ERROR, Outcome.UNCHANGED):
        assert retry not in TERMINAL_OUTCOMES
    assert Outcome.PR_OPENED in TERMINAL_OUTCOMES


def test_command_result_ok():
    assert CommandResult(("x",), 0, "", "").ok
    assert not CommandResult(("x",), 1, "", "").ok
