"""T17: pure SLO helpers (src/sre_harness/slo_parse.py)."""

from sre_harness.slo_parse import (
    commit_from_image,
    entry_message,
    group_log_signatures,
    normalize_message,
    parse_alert,
    slo_resource_from_policy,
    validate_rca,
)

RAW = {
    "name": "projects/prod-project/alerts/abc",
    "state": "open",
    "openTime": "2026-11-19T08:00:00Z",
    "summaryText": "Burn rate above 14.4",
    "policy": {"name": "projects/prod-project/alertPolicies/9", "displayName": "Checkout fast burn"},
}
POLICY = {
    "displayName": "Policy name",
    "userLabels": {"service": "checkout", "slo": "checkout-availability"},
    "conditions": [
        {"conditionThreshold": {"filter": 'select_slo_burn_rate("projects/prod-project/services/s1/serviceLevelObjectives/o1", "3600s")'}}
    ],
}


def test_parse_alert():
    a = parse_alert(RAW, POLICY)
    assert (a.alert_id, a.project, a.policy_name, a.policy_display_name) == (
        "projects/prod-project/alerts/abc", "prod-project", "projects/prod-project/alertPolicies/9", "Checkout fast burn",
    )
    assert (a.state, a.open_time, a.close_time, a.summary, a.service, a.slo) == (
        "OPEN", "2026-11-19T08:00:00Z", None, "Burn rate above 14.4", "checkout", "checkout-availability",
    )


def test_parse_alert_snake_case_and_fallbacks():
    raw = {"name": "weird", "state": "CLOSED", "open_time": "t0", "close_time": "t1", "summary_text": "s", "policy": {"name": "p"}}
    a = parse_alert(raw, None)
    assert (a.project, a.policy_display_name, a.close_time, a.summary, a.service, a.slo) == ("", "", "t1", "s", None, None)
    assert parse_alert({"name": "projects/p/alerts/1", "policy": {}}, {"displayName": "From policy"}).policy_display_name == "From policy"


def test_slo_resource_from_policy():
    assert slo_resource_from_policy(POLICY) == "projects/prod-project/services/s1/serviceLevelObjectives/o1"
    assert slo_resource_from_policy({"conditions": [{"conditionThreshold": {"filter": "metric.type=x"}}]}) is None
    assert slo_resource_from_policy({}) is None


def test_normalize_message():
    assert normalize_message("user 42 failed at 2025-01-01T10:00:00Z") == "user <n> failed at <ts>"
    assert normalize_message("req 3f2a9c1e-5b7d-4e8a-9c21-7d4e5f6a8b90 from 10.0.0.12 timed out") == "req <uuid> from <ip> timed out"
    assert normalize_message("object deadbeef01 missing for 'alice'") == "object <hex> missing for <str>"
    assert normalize_message("  a    b\n c  ") == "a b c"
    assert len(normalize_message("x" * 500)) == 200


def test_entry_message():
    assert entry_message({"textPayload": "boom"}) == "boom"
    assert entry_message({"jsonPayload": {"message": "m", "msg": "x"}}) == "m"
    assert entry_message({"jsonPayload": {"msg": "x"}}) == "x"
    assert entry_message({"jsonPayload": {"b": 1, "a": 2}}) == '{"a":2,"b":1}'
    assert entry_message({"protoPayload": {"status": {"message": "denied"}}}) == "denied"
    assert entry_message({}) == ""


def test_group_log_signatures():
    entries = [
        {"textPayload": "timeout after 30s to db-1", "timestamp": "2026-11-19T07:59:00Z"},
        {"textPayload": "timeout after 31s to db-1", "timestamp": "2026-11-19T07:58:00Z"},
        {"textPayload": "timeout after 29s to db-1", "timestamp": "2026-11-19T08:01:00Z"},
        {"jsonPayload": {"message": "pool exhausted"}, "timestamp": "2026-11-19T08:00:00Z"},
        {"jsonPayload": {"message": "another"}, "timestamp": "2026-11-19T08:00:00Z"},
        {"timestamp": "2026-11-19T08:00:00Z"},
    ]
    groups = group_log_signatures(entries, top_n=2)
    assert groups == [
        {
            "signature": "timeout after <n>s to db-<n>",
            "count": 3,
            "first_seen": "2026-11-19T07:58:00Z",
            "last_seen": "2026-11-19T08:01:00Z",
            "sample": "timeout after 30s to db-1",
        },
        {"signature": "another", "count": 1, "first_seen": "2026-11-19T08:00:00Z", "last_seen": "2026-11-19T08:00:00Z", "sample": "another"},
    ]


def test_commit_from_image():
    assert commit_from_image("r.io/p/app:1a2b3c4d") == "1a2b3c4d"
    assert commit_from_image("r.io/p/app:1a2b3c4d@sha256:ffff") == "1a2b3c4d"
    assert commit_from_image("r.io/p/app:v1.2.3") is None
    assert commit_from_image("r.io/p/app@sha256:ffff") is None
    assert commit_from_image("localhost:5000/app") is None


def test_validate_rca():
    rca = {
        "hypotheses": [
            {"cause": "a", "evidence": ["E1"]},
            {"cause": "b", "evidence": ["E9"]},
            {"cause": "c", "evidence": []},
            {"cause": "d", "evidence": ["E2", "E1"]},
            {"cause": "e", "evidence": ["E2"]},
            {"cause": "f", "evidence": ["E1"]},
        ]
    }
    valid, rejected = validate_rca(rca, {"E1", "E2"})
    assert [h["cause"] for h in valid] == ["a", "d", "e"] and rejected == 2
    assert validate_rca({}, {"E1"}) == ([], 0)
