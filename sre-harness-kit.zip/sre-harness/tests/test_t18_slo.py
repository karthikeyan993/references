"""T18: SLO polling, evidence and root-cause notes (src/sre_harness/slo.py)."""

import json
from datetime import UTC, datetime

from fakes import IMAGE_REPO, FakeAgent, FakeChat, FakeRunner, make_ctx, repo_runner
from sre_harness import slo
from sre_harness.agent import AgentError
from sre_harness.models import SloAlert

ALERT = SloAlert(
    "projects/prod-project/alerts/abc", "prod-project", "projects/prod-project/alertPolicies/9", "Checkout fast burn",
    "OPEN", "2026-11-19T08:00:00Z", None, "Burn rate above 14.4", "checkout", "checkout-availability",
)

LOGS = [
    {"textPayload": "timeout after 30s to db-1", "timestamp": "2026-11-19T07:59:00Z"},
    {"textPayload": "timeout after 31s to db-1", "timestamp": "2026-11-19T07:58:00Z"},
]
REVISIONS = [
    {"metadata": {"name": "checkout-api-00040", "creationTimestamp": "2026-11-10T10:00:00Z"}, "status": {"imageDigest": f"{IMAGE_REPO}:aaaa111"}},
    {"metadata": {"name": "checkout-api-00041", "creationTimestamp": "2026-11-15T10:00:00Z"}, "status": {"imageDigest": f"{IMAGE_REPO}:bbbb222"}},
    {"metadata": {"name": "checkout-api-00042", "creationTimestamp": "2026-11-19T07:56:00Z"}, "status": {"imageDigest": f"{IMAGE_REPO}:cccc333"}},
]


def slo_runner() -> FakeRunner:
    r = repo_runner({"app.js": "x"})
    r.on_json(["gcloud", "logging", "read"], LOGS)
    r.on_json(["gcloud", "run", "revisions", "list"], REVISIONS)
    r.on(["git", "log"], stdout="cccc333 halve pool size\nbbbb999 docs\n")
    return r


def test_parse_time():
    assert slo.parse_time("2026-11-19T08:00:00Z") == datetime(2026, 11, 19, 8, tzinfo=UTC)
    assert slo.parse_time("2026-11-19T08:00:00.123456789Z") == datetime(2026, 11, 19, 8, 0, 0, 123456, tzinfo=UTC)
    assert slo.parse_time("") is None and slo.parse_time("nope") is None


def test_log_filter():
    from fakes import CHECKOUT

    assert slo.log_filter(CHECKOUT) == (
        'resource.type="cloud_run_revision" AND resource.labels.service_name="checkout-api" AND severity>=ERROR'
    )


def test_collect_evidence(tmp_path):
    ctx = make_ctx(tmp_path, runner=slo_runner())
    ev = slo.collect_evidence(ctx, ALERT, ctx.services["checkout"])
    assert [(e.id, e.kind) for e in ev] == [("E1", "alert"), ("E2", "log_signature"), ("E3", "revision"), ("E4", "commits")]
    assert ev[0].summary == "Alert 'Checkout fast burn' opened 2026-11-19T08:00:00Z: Burn rate above 14.4"
    assert ev[1].summary == "2x timeout after <n>s to db-<n> (first 2026-11-19T07:58:00Z, last 2026-11-19T07:59:00Z)"
    assert ev[2].summary == f"Revision checkout-api-00042 created 2026-11-19T07:56:00Z image {IMAGE_REPO}:cccc333"
    assert ev[3].summary == "2 commits between bbbb222 and cccc333"
    assert ctx.runner.called(["git", "log"])[0][-1] == "bbbb222..cccc333"
    logs_call = ctx.runner.called(["gcloud", "logging", "read"])[0]
    assert "--freshness=120m" in logs_call and "--project=prod-project" in logs_call


def test_collect_evidence_quiet_service_and_history(tmp_path):
    runner = FakeRunner().on_json(["gcloud", "logging", "read"], []).on_json(["gcloud", "run", "revisions", "list"], REVISIONS[:1])
    ctx = make_ctx(tmp_path, runner=runner)
    page = ctx.cfg.wiki_dir / "incidents" / "2026-11-01-checkout-x.md"
    page.parent.mkdir(parents=True)
    page.write_text("- Service: checkout\n- Opened: 2026-11-01T00:00:00Z\nActual cause: quota exhausted\n")
    ev = slo.collect_evidence(ctx, ALERT, ctx.services["checkout"])
    assert [e.summary for e in ev[1:]] == [
        "No ERROR log entries in the lookback window",
        "No new revisions in the 24h before the alert",
        "Past incident opened 2026-11-01T00:00:00Z: actual cause: quota exhausted",
    ]


def test_collect_evidence_unavailable_and_no_service(tmp_path):
    runner = FakeRunner().on(["gcloud"], returncode=1, stderr="403")
    ctx = make_ctx(tmp_path, runner=runner)
    ev = slo.collect_evidence(ctx, ALERT, ctx.services["checkout"])
    assert [e.summary for e in ev[1:]] == ["logs unavailable: 403", "revisions unavailable: 403"]
    assert [e.kind for e in slo.collect_evidence(ctx, ALERT, None)] == ["alert"]


def test_handle_new_alert(tmp_path):
    chat = FakeChat()
    agent = FakeAgent(
        [
            {
                "summary": "Pool halved in revision 42",
                "hypotheses": [
                    {"cause": "Pool size halved", "evidence": ["E3", "E4"], "confidence": "high", "check_next": "Diff pool config"},
                    {"cause": "Made up", "evidence": ["E99"], "confidence": "low"},
                ],
                "suspected_commit": "cccc333",
                "suggested_fix": "Revert cccc333",
            }
        ]
    )
    ctx = make_ctx(tmp_path, runner=slo_runner(), chat=chat, agent=agent)
    path = slo.handle_new_alert(ctx, ALERT)
    task = agent.tasks[0]
    assert (task.agent, task.prompt_name, task.schema_name, task.key) == ("rca", "rca", "rca_result", ALERT.alert_id)
    assert task.workdir == tmp_path / "work" / "heads" / "checkout"
    ev_file = tmp_path / "work" / "slo" / "abc" / "evidence.json"
    assert task.variables["evidence_path"] == str(ev_file)
    assert [e["id"] for e in json.loads(ev_file.read_text())] == ["E1", "E2", "E3", "E4"]
    text = chat.texts()[0]
    assert chat.messages[0].thread_key == "slo-abc"
    assert "1. Pool size halved (confidence: high; evidence: E3, E4)" in text and "Rejected hypotheses: 1" in text
    assert path == tmp_path / "wiki" / "incidents" / "2026-11-19-checkout-abc.md"
    assert "Pool halved in revision 42" in path.read_text()
    row = ctx.store.slo_alert_get(ALERT.alert_id)
    assert row["status"] == "open" and row["wiki_path"] == str(path)


def test_handle_new_alert_agent_error_and_unknown_service(tmp_path):
    chat = FakeChat()
    alert = SloAlert("projects/p/alerts/zz", "p", "pol", "Mystery", "OPEN", "2026-11-19T08:00:00Z", None, "s", None, None)
    ctx = make_ctx(tmp_path, chat=chat, agent=FakeAgent([AgentError("agent timed out")]))
    slo.handle_new_alert(ctx, alert)
    assert ctx.agent.tasks[0].workdir == tmp_path / "work" / "slo" / "zz"
    lines = chat.texts()[0].splitlines()
    assert lines[0] == "*[SLO ROOT CAUSE]* unknown service · Mystery"
    assert "Insufficient evidence: no hypothesis cited valid evidence." in lines and lines[-1] == "Agent error: agent timed out"


def test_handle_closed_alert(tmp_path):
    chat = FakeChat()
    ctx = make_ctx(tmp_path, chat=chat)
    page = tmp_path / "p.md"
    page.write_text("- Closed: open\n")
    closed = SloAlert(*[getattr(ALERT, f) for f in ("alert_id", "project", "policy_name", "policy_display_name")],
                      "CLOSED", ALERT.open_time, "2026-11-19T08:45:30Z", ALERT.summary, ALERT.service, ALERT.slo)
    slo.handle_closed_alert(ctx, closed, str(page))
    assert chat.texts()[0].endswith("Open for 45 min (2026-11-19T08:00:00Z to 2026-11-19T08:45:30Z)")
    assert page.read_text() == "- Closed: 2026-11-19T08:45:30Z\n"
    assert ctx.store.slo_alert_get(ALERT.alert_id)["status"] == "closed"


RAW_OPEN = {
    "name": "projects/prod-project/alerts/abc",
    "state": "OPEN",
    "openTime": "2026-11-19T08:00:00Z",
    "summaryText": "Burn rate above 14.4",
    "policy": {"name": "projects/prod-project/alertPolicies/9", "displayName": "Checkout fast burn"},
}
POLICY = {"userLabels": {"service": "checkout", "slo": "checkout-availability"}}


def test_run_slo_poll_open_then_close(tmp_path):
    runner = slo_runner()
    runner.on_json(["gcloud", "alpha", "monitoring", "alerts", "list"], [RAW_OPEN, dict(RAW_OPEN, name="projects/prod-project/alerts/old", state="CLOSED")])
    runner.on_json(["gcloud", "alpha", "monitoring", "policies", "describe"], POLICY)
    agent = FakeAgent([{"summary": "s", "hypotheses": []}])
    chat = FakeChat()
    ctx = make_ctx(tmp_path, runner=runner, agent=agent, chat=chat)
    assert slo.run_slo_poll(ctx) == 1
    assert len(runner.called(["gcloud", "alpha", "monitoring", "policies", "describe"])) == 1
    assert slo.run_slo_poll(ctx) == 0
    runner.on_json(["gcloud", "alpha", "monitoring", "alerts", "list"], [dict(RAW_OPEN, state="CLOSED", closeTime="2026-11-19T09:00:00Z")])
    assert slo.run_slo_poll(ctx) == 1
    assert [t.splitlines()[0] for t in chat.texts()] == [
        "*[SLO ROOT CAUSE]* checkout · Checkout fast burn",
        "*[SLO RESOLVED]* checkout · Checkout fast burn",
    ]


def test_run_slo_poll_list_failure(tmp_path):
    chat = FakeChat()
    ctx = make_ctx(tmp_path, runner=FakeRunner().on(["gcloud"], returncode=1, stderr="403"), chat=chat)
    assert slo.run_slo_poll(ctx) == 0
    assert chat.texts() == ["*[HARNESS ERROR]* stage: slo-poll\n403"]


def test_run_slo_poll_one_bad_alert(tmp_path, monkeypatch):
    runner = FakeRunner().on_json(["gcloud", "alpha", "monitoring", "alerts", "list"], [RAW_OPEN]).on_json(
        ["gcloud", "alpha", "monitoring", "policies", "describe"], POLICY
    )
    chat = FakeChat()
    ctx = make_ctx(tmp_path, runner=runner, chat=chat)

    def boom(ctx, alert):
        raise RuntimeError("disk full")

    monkeypatch.setattr(slo, "handle_new_alert", boom)
    assert slo.run_slo_poll(ctx) == 0
    assert chat.texts() == ["*[HARNESS ERROR]* stage: slo-alert\nRuntimeError: disk full"]
