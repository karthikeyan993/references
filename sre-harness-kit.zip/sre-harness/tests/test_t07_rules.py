"""T07: rule matching and classification (src/sre_harness/rules.py)."""

import pytest

from fakes import default_rules, finding
from sre_harness.models import FindingClass, FindingKind, Rule
from sre_harness.rules import classify, condition_matches, field_value, matches


def test_field_value():
    f = finding()
    assert field_value(f, "kind") == "vulnerability"
    assert field_value(f, "package") == "lodash"
    assert field_value(finding(package=None), "package") is None


@pytest.mark.parametrize(
    "value, cond, expected",
    [
        ("HIGH", "high", True),
        ("HIGH", "low", False),
        (None, "x", False),
        ("Deb", {"in": ["deb", "apk"]}, True),
        ("npm", {"in": ["deb"]}, False),
        (None, {"in": ["deb"]}, False),
        ("Service account key too old", {"regex": "(?i)service account key"}, True),
        (None, {"regex": "x"}, False),
        (None, {"empty": True}, True),
        ("", {"empty": True}, True),
        ("1.0", {"empty": True}, False),
        ("1.0", {"empty": False}, True),
        ("1.0", {"present": True}, True),
        ("", {"present": True}, False),
        (None, {"present": False}, True),
        ("true", True, True),
        ("false", True, False),
    ],
)
def test_condition_matches(value, cond, expected):
    assert condition_matches(value, cond) is expected


def test_matches_all_conditions():
    rule = Rule("r", FindingClass.SA_KEY, {"kind": "issue", "title": {"regex": "key"}})
    assert matches(rule, finding(kind=FindingKind.ISSUE, title="old key"))
    assert not matches(rule, finding(kind=FindingKind.VULNERABILITY, title="old key"))
    assert matches(Rule("all", FindingClass.UNCLASSIFIED, {}), finding())


@pytest.mark.parametrize(
    "f, expected",
    [
        (finding(), (FindingClass.APP_DEPENDENCY, "app-dependencies")),
        (finding(fixed_version=None), (FindingClass.NO_FIX_AVAILABLE, "no-fix-yet")),
        (finding(package="openssl", package_type="deb"), (FindingClass.BASE_IMAGE_OS, "os-packages")),
        (
            finding(kind=FindingKind.ISSUE, package=None, title="Cloud Run service allows unauthenticated invocations"),
            (FindingClass.UNAUTH_ENDPOINT, "unauthenticated-endpoints"),
        ),
        (
            finding(kind=FindingKind.ISSUE, package=None, title="Service account key older than 90 days"),
            (FindingClass.SA_KEY, "service-account-keys"),
        ),
        (finding(kind=FindingKind.ISSUE, package=None, title="Database allows public IP"), (FindingClass.IAC_CONFIG, "other-config")),
    ],
)
def test_classify_with_default_rules(f, expected):
    assert classify(f, default_rules()) == expected


def test_classify_falls_back_without_catch_all():
    rules = [Rule("only", FindingClass.SA_KEY, {"kind": "issue"})]
    assert classify(finding(), rules) == (FindingClass.UNCLASSIFIED, "<none>")
