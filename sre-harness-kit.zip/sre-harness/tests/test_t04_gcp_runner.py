"""T04: subprocess runner, HTTP client and read-only gcloud access (runner.py, gcp.py)."""

import sys

import pytest

from fakes import CHECKOUT, PAYMENTS, FakeRunner, make_cfg
from sre_harness import gcp
from sre_harness.runner import SubprocessRunner, UrllibHttp

# ---------- runner.py ----------


def test_subprocess_runner_captures_output(tmp_path):
    res = SubprocessRunner().run([sys.executable, "-c", "import sys; print('out'); print('err', file=sys.stderr)"])
    assert res.ok and res.stdout.strip() == "out" and res.stderr.strip() == "err"
    assert res.args[0] == sys.executable


def test_subprocess_runner_nonzero_and_cwd_and_env(tmp_path):
    code = "import os, sys; print(os.getcwd()); print(os.environ['SRE_X']); sys.exit(3)"
    res = SubprocessRunner().run([sys.executable, "-c", code], cwd=str(tmp_path), env={"SRE_X": "42"})
    assert res.returncode == 3
    lines = res.stdout.splitlines()
    assert lines[1] == "42" and lines[0].endswith(tmp_path.name)


def test_subprocess_runner_missing_executable():
    res = SubprocessRunner().run(["definitely-not-a-real-binary-xyz"])
    assert res.returncode == 127


def test_subprocess_runner_timeout():
    res = SubprocessRunner().run([sys.executable, "-c", "import time; time.sleep(5)"], timeout=1)
    assert res.returncode == 124 and "timeout" in res.stderr


def test_http_network_error_returns_zero():
    assert UrllibHttp().post_json("http://127.0.0.1:9/never", {"a": 1}, timeout=2) == 0


# ---------- gcp.py ----------


@pytest.mark.parametrize(
    "args, ok",
    [
        (["storage", "ls", "gs://b/"], True),
        (["alpha", "monitoring", "alerts", "list", "--project=p"], True),
        (["beta", "run", "revisions", "describe", "r"], True),
        (["iam", "service-accounts", "keys", "list"], True),
        (["run", "deploy", "x"], False),
        (["run", "services", "update", "x"], False),
        (["iam", "service-accounts", "keys", "delete", "k"], False),
        (["storage", "rm", "gs://b/x"], False),
        (["alpha"], False),
        ([], False),
    ],
)
def test_allowlist(args, ok):
    assert gcp.is_allowed(args) is ok


def test_forbidden_command_never_runs(tmp_path):
    runner = FakeRunner()
    with pytest.raises(gcp.ForbiddenCommand):
        gcp.run_gcloud(runner, make_cfg(tmp_path), ["run", "deploy", "x"])
    assert runner.calls == []


def test_impersonation_flag_is_last(tmp_path):
    runner = FakeRunner().on(["gcloud", "storage", "cat"], stdout="data")
    cfg = make_cfg(tmp_path, gcp_impersonate="ro@p.iam.gserviceaccount.com")
    assert gcp.read_object(runner, cfg, "gs://b/x.csv") == "data"
    assert runner.calls[0][0] == (
        "gcloud",
        "storage",
        "cat",
        "gs://b/x.csv",
        "--impersonate-service-account=ro@p.iam.gserviceaccount.com",
    )


def test_gcloud_failure_raises(tmp_path):
    runner = FakeRunner().on(["gcloud"], returncode=1, stderr="permission denied")
    with pytest.raises(gcp.GcpError, match="permission denied"):
        gcp.run_gcloud(runner, make_cfg(tmp_path), ["storage", "cat", "gs://b/x"])


def test_json_parsing(tmp_path):
    cfg = make_cfg(tmp_path)
    runner = FakeRunner().on(["gcloud", "logging", "read"], stdout="")
    assert gcp.read_logs(runner, cfg, "p", 'severity>=ERROR', 60, 10) == []
    assert runner.calls[0][0] == (
        "gcloud", "logging", "read", "severity>=ERROR", "--project=p", "--freshness=60m", "--limit=10", "--format=json",
    )
    bad = FakeRunner().on(["gcloud"], stdout="not json")
    with pytest.raises(gcp.GcpError):
        gcp.list_alerts(bad, cfg, "p")


def test_list_objects(tmp_path):
    cfg = make_cfg(tmp_path)
    runner = FakeRunner().on(["gcloud", "storage", "ls"], stdout="gs://b/2.csv\n\ngs://b/1.csv\n")
    assert gcp.list_objects(runner, cfg, "gs://b/") == ["gs://b/1.csv", "gs://b/2.csv"]
    missing = FakeRunner().on(["gcloud", "storage", "ls"], returncode=1, stderr="404 Not Found")
    assert gcp.list_objects(missing, cfg, "gs://b/") == []
    denied = FakeRunner().on(["gcloud", "storage", "ls"], returncode=1, stderr="403 Forbidden")
    with pytest.raises(gcp.GcpError):
        gcp.list_objects(denied, cfg, "gs://b/")


def test_serving_images(tmp_path):
    cfg = make_cfg(tmp_path)
    runner = FakeRunner()
    runner.on_json(
        ["gcloud", "run", "services", "describe", "checkout-api"],
        {
            "status": {
                "latestReadyRevisionName": "checkout-api-00042",
                "traffic": [
                    {"latestRevision": True, "percent": 90},
                    {"revisionName": "checkout-api-00041", "percent": 10},
                    {"revisionName": "checkout-api-00040", "percent": 0},
                ],
            }
        },
    )
    runner.on_json(
        ["gcloud", "run", "revisions", "describe", "checkout-api-00042"],
        {"status": {"imageDigest": "r.io/app@sha256:new"}},
    )
    runner.on_json(
        ["gcloud", "run", "revisions", "describe", "checkout-api-00041"],
        {"status": {}, "spec": {"containers": [{"image": "r.io/app:41"}]}},
    )
    assert gcp.serving_images(runner, cfg, CHECKOUT.runtime) == ["r.io/app:41", "r.io/app@sha256:new"]
    describe = runner.called(["gcloud", "run", "services", "describe"])[0]
    assert "--project=prod-project" in describe and "--region=europe-west1" in describe and describe[-1] == "--format=json"
    assert not runner.called(["gcloud", "run", "revisions", "describe", "checkout-api-00040"])


def test_serving_images_none_runtime(tmp_path):
    assert gcp.serving_images(FakeRunner(), make_cfg(tmp_path), PAYMENTS.runtime) is None


def test_list_revisions_sorted(tmp_path):
    runner = FakeRunner().on_json(
        ["gcloud", "run", "revisions", "list"],
        [
            {"metadata": {"name": "r2", "creationTimestamp": "2026-11-19T08:00:00Z"}, "status": {"imageDigest": "i2"}},
            {"metadata": {"name": "r1", "creationTimestamp": "2026-11-18T08:00:00Z"}, "spec": {"containers": [{"image": "i1"}]}},
        ],
    )
    revs = gcp.list_revisions(runner, make_cfg(tmp_path), CHECKOUT.runtime)
    assert revs == [
        {"name": "r1", "created": "2026-11-18T08:00:00Z", "image": "i1"},
        {"name": "r2", "created": "2026-11-19T08:00:00Z", "image": "i2"},
    ]
    assert "--service=checkout-api" in runner.calls[0][0]
    assert gcp.list_revisions(runner, make_cfg(tmp_path), PAYMENTS.runtime) == []


def test_has_public_invoker():
    assert gcp.has_public_invoker({"bindings": [{"role": "roles/run.invoker", "members": ["allUsers"]}]})
    assert gcp.has_public_invoker({"bindings": [{"role": "roles/run.invoker", "members": ["allAuthenticatedUsers"]}]})
    assert not gcp.has_public_invoker({"bindings": [{"role": "roles/run.admin", "members": ["allUsers"]}]})
    assert not gcp.has_public_invoker({})


def test_keys_alerts_policy_iam_commands(tmp_path):
    cfg = make_cfg(tmp_path)
    runner = FakeRunner()
    runner.on_json(["gcloud", "iam", "service-accounts", "keys", "list"], [{"name": "k1"}])
    runner.on_json(["gcloud", "alpha", "monitoring", "alerts", "list"], [{"name": "a1"}])
    runner.on_json(["gcloud", "alpha", "monitoring", "policies", "describe"], {"displayName": "p"})
    runner.on_json(["gcloud", "run", "services", "get-iam-policy"], {"bindings": []})
    assert gcp.user_managed_keys(runner, cfg, "sa@p.iam.gserviceaccount.com", "p") == [{"name": "k1"}]
    assert gcp.list_alerts(runner, cfg, "p") == [{"name": "a1"}]
    assert gcp.describe_policy(runner, cfg, "projects/p/alertPolicies/1") == {"displayName": "p"}
    assert gcp.run_iam_policy(runner, cfg, CHECKOUT.runtime) == {"bindings": []}
    keys_call = runner.called(["gcloud", "iam"])[0]
    assert "--iam-account=sa@p.iam.gserviceaccount.com" in keys_call and "--managed-by=user" in keys_call
    assert "--project=p" in runner.called(["gcloud", "alpha", "monitoring", "alerts"])[0]
