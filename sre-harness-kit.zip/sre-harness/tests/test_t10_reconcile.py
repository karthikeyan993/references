"""T10: stale-image reconciliation (src/sre_harness/reconcile.py)."""

import pytest

from fakes import IMAGE_REPO, finding, item
from sre_harness.models import Decision, FindingClass
from sre_harness.reconcile import decide, images_match, is_running

NEW = f"{IMAGE_REPO}@sha256:aaa"
OLD = f"{IMAGE_REPO}@sha256:old"


@pytest.mark.parametrize(
    "f_img, r_img, expected",
    [
        (NEW, NEW, True),
        (OLD, NEW, False),
        (f"{IMAGE_REPO}:1.0", f"{IMAGE_REPO}:1.0", True),
        (f"{IMAGE_REPO}:1.0", f"{IMAGE_REPO}:2.0", False),
        (f"{IMAGE_REPO}:1.0", NEW, None),
        ("other.io/x@sha256:aaa", NEW, False),
        (f"{IMAGE_REPO}:1.0@sha256:aaa", NEW, True),
    ],
)
def test_images_match(f_img, r_img, expected):
    assert images_match(f_img, r_img) is expected


def test_is_running_is_conservative():
    assert is_running(None, [NEW])
    assert is_running(OLD, None)
    assert is_running(f"{IMAGE_REPO}:1.0", [NEW])
    assert not is_running(OLD, [NEW])
    assert not is_running(OLD, [])


def test_other_classes_recommend():
    r = decide(item(FindingClass.SA_KEY, [finding()]), [NEW], None, "npm")
    assert r.decision is Decision.RECOMMEND and r.reason == "no reconcile for sa_key"


def test_cleanup_when_nothing_running():
    r = decide(item(FindingClass.APP_DEPENDENCY, [finding(image=OLD)]), [NEW], "4.17.20", "npm")
    assert r.decision is Decision.CLEANUP
    assert r.stale_images == (OLD,) and r.running_images == ()


def test_base_image_fix_when_running():
    wi = item(FindingClass.BASE_IMAGE_OS, [finding(image=NEW, package="openssl"), finding(image=OLD, package="openssl")])
    r = decide(wi, [NEW], None, "deb")
    assert r.decision is Decision.FIX and r.running_images == (NEW,) and r.stale_images == (OLD,)


def test_app_dependency_fix_when_vulnerable_at_head():
    wi = item(FindingClass.APP_DEPENDENCY, [finding(image=NEW, fixed_version="4.17.21"), finding(image=NEW, fixed_version="4.17.23")])
    r = decide(wi, [NEW], "4.17.20", "npm")
    assert r.decision is Decision.FIX and r.target_version == "4.17.23" and r.head_version == "4.17.20"


def test_app_dependency_redeploy_when_fixed_at_head():
    r = decide(item(FindingClass.APP_DEPENDENCY, [finding(image=NEW)]), [NEW], "4.17.21", "npm")
    assert r.decision is Decision.REDEPLOY and r.reason == "fixed at HEAD, running image is older"


def test_app_dependency_unknown_head_means_fix():
    r = decide(item(FindingClass.APP_DEPENDENCY, [finding(image=NEW)]), None, None, "npm")
    assert r.decision is Decision.FIX


def test_app_dependency_target_ignores_stale_findings():
    wi = item(FindingClass.APP_DEPENDENCY, [finding(image=NEW, fixed_version="4.17.21"), finding(image=OLD, fixed_version="9.0.0")])
    r = decide(wi, [NEW], "4.17.20", "npm")
    assert r.target_version == "4.17.21"


def test_already_fixed_per_finding_versions():
    r = decide(item(FindingClass.APP_DEPENDENCY, [finding(image=NEW, version="5.0.0", fixed_version="4.17.21")]), [NEW], None, "npm")
    assert r.decision is Decision.REDEPLOY and r.reason == "already fixed per finding versions"
