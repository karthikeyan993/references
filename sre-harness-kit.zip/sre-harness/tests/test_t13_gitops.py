"""T13: git and GitHub operations (src/sre_harness/gitops.py)."""

import hashlib
import json

import pytest

from fakes import FakeRunner
from sre_harness import gitops


def test_names():
    assert gitops.clone_url("github.com/acme/x") == "https://github.com/acme/x.git"
    assert gitops.gh_repo("github.com/acme/x") == "acme/x"
    key = "app_dependency:checkout:lodash"
    assert gitops.branch_name(key) == "sre-bot/app-dependency-checkout-lodash-" + hashlib.sha256(key.encode()).hexdigest()[:8]
    long = gitops.branch_name("x" * 100 + ":" + "y")
    assert len(long.split("/", 1)[1]) <= 40 + 1 + 8


def test_ensure_clone_new_then_fetch(tmp_path):
    runner = FakeRunner().on(["git", "clone"]).on(["git", "fetch"])
    dest = gitops.ensure_clone(runner, "github.com/acme/x", tmp_path)
    assert dest == tmp_path / "repos" / "acme__x"
    assert runner.calls[0] == (("git", "clone", "--filter=blob:none", "https://github.com/acme/x.git", str(dest)), str(tmp_path))
    (dest / ".git").mkdir(parents=True)
    gitops.ensure_clone(runner, "github.com/acme/x", tmp_path)
    assert runner.calls[1] == (("git", "fetch", "--prune", "origin"), str(dest))


def test_clone_failure(tmp_path):
    with pytest.raises(gitops.GitError, match="clone"):
        gitops.ensure_clone(FakeRunner().on(["git"], returncode=128, stderr="auth failed"), "github.com/acme/x", tmp_path)


def test_create_worktree(tmp_path):
    runner = FakeRunner().on(["git"])
    dest = tmp_path / "wt"
    dest.mkdir()
    (dest / "junk").write_text("x")
    out = gitops.create_worktree(runner, tmp_path / "clone", "main", "sre-bot/x", dest)
    assert out == dest and not (dest / "junk").exists()
    assert runner.called(["git", "worktree", "add"])[0] == ("git", "worktree", "add", "-B", "sre-bot/x", str(dest), "origin/main")
    with pytest.raises(gitops.GitError):
        gitops.create_worktree(runner, tmp_path, "main", "main", dest)


def test_checkout_head(tmp_path):
    runner = FakeRunner().on(["git"])
    gitops.checkout_head(runner, tmp_path, "develop", tmp_path / "head")
    assert runner.called(["git", "worktree", "add"])[0] == ("git", "worktree", "add", "--detach", str(tmp_path / "head"), "origin/develop")


def test_staged_numstat(tmp_path):
    runner = FakeRunner().on(["git", "add"]).on(["git", "diff"], stdout="3\t1\tpackage.json\n10\t4\tpackage-lock.json\n-\t-\tlogo.png\n")
    files, lines = gitops.staged_numstat(runner, tmp_path)
    assert files == ["logo.png", "package-lock.json", "package.json"] and lines == 18
    assert runner.calls[0][0] == ("git", "add", "-A", "--", ".", ":(exclude).sre", ":(exclude).opencode")
    assert runner.calls[1][0] == ("git", "diff", "--cached", "--numstat")


def test_commit_and_push(tmp_path):
    runner = FakeRunner().on(["git"])
    gitops.commit_and_push(runner, tmp_path, "sre-bot/x-1", "fix(deps): upgrade")
    cmds = [c[0] for c in runner.calls]
    assert cmds[1] == ("git", "commit", "-m", "fix(deps): upgrade")
    assert cmds[2] == ("git", "push", "-u", "origin", "sre-bot/x-1")
    assert not any("--force" in c for c in cmds)


def test_refuses_to_push_other_branches(tmp_path):
    runner = FakeRunner().on(["git"])
    with pytest.raises(gitops.GitError):
        gitops.commit_and_push(runner, tmp_path, "main", "m")
    assert runner.calls == []


def test_find_open_pr(tmp_path):
    runner = FakeRunner().on(["gh", "pr", "list"], stdout=json.dumps([{"url": "https://github.com/acme/x/pull/3"}]))
    assert gitops.find_open_pr(runner, "github.com/acme/x", "sre-bot/b") == "https://github.com/acme/x/pull/3"
    assert runner.calls[0][0] == ("gh", "pr", "list", "--repo", "acme/x", "--head", "sre-bot/b", "--state", "open", "--json", "url")
    assert gitops.find_open_pr(FakeRunner().on(["gh"], stdout="[]"), "github.com/acme/x", "b") is None
    with pytest.raises(gitops.GitError):
        gitops.find_open_pr(FakeRunner().on(["gh"], returncode=1), "github.com/acme/x", "b")


def test_open_pr(tmp_path):
    runner = FakeRunner().on(["gh", "pr", "create"], stdout="Creating pull request\nhttps://github.com/acme/x/pull/9\n")
    url = gitops.open_pr(runner, "github.com/acme/x", tmp_path, "main", "sre-bot/b", "Title", "Body text", ("sre-bot", "security"))
    assert url == "https://github.com/acme/x/pull/9"
    assert (tmp_path / ".sre" / "pr_body.md").read_text() == "Body text"
    args, cwd = runner.calls[0]
    assert args == ("gh", "pr", "create", "--repo", "acme/x", "--base", "main", "--head", "sre-bot/b", "--title", "Title",
                    "--body-file", str(tmp_path / ".sre" / "pr_body.md"), "--label", "sre-bot", "--label", "security")
    assert cwd == str(tmp_path)
    with pytest.raises(gitops.GitError):
        gitops.open_pr(FakeRunner().on(["gh"], stdout="weird"), "github.com/acme/x", tmp_path, "main", "b", "t", "b")


def test_commits_between(tmp_path):
    runner = FakeRunner().on(["git", "log"], stdout="abc fix pool\ndef bump deps\n")
    assert gitops.commits_between(runner, tmp_path, "111", "222") == ["abc fix pool", "def bump deps"]
    assert runner.calls[0][0] == ("git", "log", "--oneline", "--no-decorate", "111..222")
    assert gitops.commits_between(FakeRunner(), tmp_path, "1", "2") == []
