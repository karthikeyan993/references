"""T14: playbooks (src/sre_harness/playbooks.py)."""

import json
from dataclasses import replace
from pathlib import Path

from fakes import (
    CHECKOUT,
    IMAGE_REPO,
    LOCK_OLD,
    PAYMENTS,
    PR_URL,
    FakeAgent,
    FakeRunner,
    finding,
    item,
    make_ctx,
    repo_runner,
)
from sre_harness import playbooks
from sre_harness.agent import AgentError
from sre_harness.models import CommandResult, Decision, FindingClass, FindingKind, Outcome, ReconcileResult

NEW = f"{IMAGE_REPO}@sha256:aaa"
def app_item():
    return item(
        FindingClass.APP_DEPENDENCY,
        [finding(), finding(fingerprint="wiz:f2", title="CVE-2024-2222", fixed_version="4.17.23, 5.0.1")],
        key="app_dependency:checkout:lodash",
    )


FIX = ReconcileResult(Decision.FIX, "vulnerable at HEAD", running_images=(NEW,), target_version="4.17.23", head_version="4.17.20")


# ---------- dispatch ----------

def test_dispatch_cleanup(tmp_path):
    ctx = make_ctx(tmp_path)
    d = ReconcileResult(Decision.CLEANUP, "no affected image is running", stale_images=("img@sha256:old",))
    res = playbooks.run_playbook(ctx, app_item(), d)
    assert res.outcome is Outcome.CLEANUP_RECOMMENDED
    assert res.details == {"stale_images": ["img@sha256:old"], "docs": playbooks.CLEANUP_DOC}


def test_dispatch_redeploy(tmp_path):
    ctx = make_ctx(tmp_path)
    d = ReconcileResult(Decision.REDEPLOY, "fixed at HEAD, running image is older", running_images=(NEW,), target_version="4.17.23", head_version="4.17.23")
    res = playbooks.run_playbook(ctx, app_item(), d)
    assert res.outcome is Outcome.REDEPLOY_NEEDED and res.summary == "fixed at HEAD, running image is older"
    assert res.details == {"target_version": "4.17.23", "head_version": "4.17.23", "running_images": [NEW]}


# ---------- app_dependency ----------

def test_app_dependency_happy_path(tmp_path):
    runner = repo_runner({"package.json": "{}", "package-lock.json": json.dumps(LOCK_OLD)})
    ctx = make_ctx(tmp_path, runner=runner)
    res = playbooks.run_playbook(ctx, app_item(), FIX)
    assert res.outcome is Outcome.PR_OPENED, res
    assert res.pr_url == PR_URL
    assert res.summary == "Upgraded lodash to 4.17.23; build and tests passed"
    assert res.details["files_changed"] == ["package-lock.json", "package.json"] and res.details["lines_changed"] == 14
    assert runner.called(["npm", "install"])[0] == ("npm", "install", "lodash@4.17.23", "--ignore-scripts")
    assert [c[2] for c in runner.called(["sh", "-c"])] == ["npm ci && npm run build", "npm test"]
    assert runner.called(["git", "commit"])[0] == ("git", "commit", "-m", "fix(deps): upgrade lodash to 4.17.23")
    create = runner.called(["gh", "pr", "create"])[0]
    assert "[sre-bot] Upgrade lodash to 4.17.23" in create
    assert runner.called(["git", "worktree", "remove"])
    assert ctx.store.count_actions("pr", "2026-11-19") == 1


def test_pr_body_shape():
    body = playbooks.pr_body(app_item(), "Did it", ["build passed"])
    assert body.startswith("## Summary\nDid it\n\n## Findings\n- CVE-2024-1111 (HIGH) on ")
    assert "\n\n## Checks\n- build passed\n\nOpened by the SRE harness. Work item: `app_dependency:checkout:lodash`.\n" in body


def test_unsupported_ecosystem(tmp_path):
    ctx = make_ctx(tmp_path, services={"checkout": replace(CHECKOUT, ecosystem="maven")})
    res = playbooks.run_playbook(ctx, app_item(), FIX)
    assert res.outcome is Outcome.RECOMMENDATION
    assert res.summary == "Upgrade lodash to 4.17.23; no scripted upgrade for ecosystem maven"


def test_pr_cap_defers(tmp_path):
    ctx = make_ctx(tmp_path, max_prs_per_day=1)
    ctx.store.record_action(1, "2026-11-19", "other", "pr", outcome="opened")
    res = playbooks.run_playbook(ctx, app_item(), FIX)
    assert res.outcome is Outcome.DEFERRED
    assert ctx.runner.calls == []


def test_existing_pr(tmp_path):
    runner = repo_runner({}).on(["gh", "pr", "list"], stdout=json.dumps([{"url": "https://x/pull/1"}]))
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), app_item(), FIX)
    assert res.outcome is Outcome.PR_OPENED and res.pr_url == "https://x/pull/1"
    assert not runner.called(["git", "worktree", "add"])


def flaky_build(fail_times: int):
    state = {"n": 0}

    def handler(args, cwd):
        if args[2].startswith("npm ci"):
            state["n"] += 1
            if state["n"] <= fail_times:
                return CommandResult(tuple(args), 1, "", "TypeError: _.template is not a function")
        return CommandResult(tuple(args), 0, "", "")

    return handler


def test_build_fails_agent_fixes(tmp_path):
    runner = repo_runner({"package.json": "{}", "package-lock.json": json.dumps(LOCK_OLD)}).on(["sh", "-c"], handler=flaky_build(1))
    agent = FakeAgent([{"status": "fixed", "analysis": "Replaced removed _.template call"}])
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner, agent=agent), app_item(), FIX)
    assert res.outcome is Outcome.PR_OPENED
    t = agent.tasks[0]
    assert (t.agent, t.prompt_name, t.schema_name, t.key) == ("fixer", "fix_build", "fix_result", "app_dependency:checkout:lodash")
    assert t.allowed_edit_globs == playbooks.FIXER_ALLOWED_GLOBS
    assert "TypeError" in t.variables["error_output"] and t.variables["target_version"] == "4.17.23"


def test_build_still_fails(tmp_path):
    runner = repo_runner({"package.json": "{}", "package-lock.json": json.dumps(LOCK_OLD)}).on(["sh", "-c"], handler=flaky_build(2))
    agent = FakeAgent([{"status": "not_fixed", "analysis": "API removed"}])
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner, agent=agent), app_item(), FIX)
    assert res.outcome is Outcome.FIX_FAILED
    assert res.summary == "Build or tests still fail after the agent fix" and res.details["analysis"] == "API removed"
    assert runner.called(["git", "worktree", "remove"])
    assert not runner.called(["git", "push"])


def test_agent_error(tmp_path):
    runner = repo_runner({"package.json": "{}", "package-lock.json": json.dumps(LOCK_OLD)}).on(["sh", "-c"], handler=flaky_build(1))
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner, agent=FakeAgent([AgentError("agent timed out")])), app_item(), FIX)
    assert res.outcome is Outcome.FIX_FAILED and res.error == "agent timed out"


def test_upgrade_command_fails(tmp_path):
    runner = repo_runner({"package-lock.json": json.dumps(LOCK_OLD)}).on(["npm", "install"], returncode=1, stderr="ERESOLVE")
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), app_item(), FIX)
    assert res.outcome is Outcome.FIX_FAILED and res.summary == "Scripted upgrade failed" and "ERESOLVE" in res.error


def test_lockfile_still_old(tmp_path):
    runner = repo_runner({"package-lock.json": json.dumps(LOCK_OLD)}).on(["npm", "install"])
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), app_item(), FIX)
    assert res.outcome is Outcome.FIX_FAILED and res.summary == "Lockfile still pins lodash 4.17.20"


def test_forbidden_files_and_diff_limit(tmp_path):
    runner = repo_runner({"package-lock.json": json.dumps(LOCK_OLD)}).on(
        ["git", "diff", "--cached", "--numstat"], stdout="1\t1\tpackage-lock.json\n2\t0\tDockerfile\n"
    )
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), app_item(), FIX)
    assert res.outcome is Outcome.FIX_FAILED and res.error == "Dockerfile"
    big = repo_runner({"package-lock.json": json.dumps(LOCK_OLD)}).on(["git", "diff", "--cached", "--numstat"], stdout="400\t2\tpackage-lock.json\n")
    res2 = playbooks.run_playbook(make_ctx(tmp_path / "b", runner=big), app_item(), FIX)
    assert res2.outcome is Outcome.FIX_FAILED and res2.summary == "Diff too large: 402 lines"


def test_empty_diff(tmp_path):
    runner = repo_runner({"package-lock.json": json.dumps(LOCK_OLD)}).on(["git", "diff", "--cached", "--numstat"], stdout="")
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), app_item(), FIX)
    assert res.summary == "The upgrade changed no files"


def test_git_failure(tmp_path):
    runner = FakeRunner().on(["git", "clone"], returncode=128, stderr="Repository not found")
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), app_item(), FIX)
    assert res.outcome is Outcome.FIX_FAILED and res.summary == "Git or GitHub step failed" and "Repository not found" in res.error


def test_forbidden_files_helper():
    assert playbooks.forbidden_files(["a.py", ".github/workflows/ci.yml", "infra/main.tf", "x/Dockerfile.prod"], PAYMENTS) == [
        ".github/workflows/ci.yml", "infra/main.tf", "x/Dockerfile.prod",
    ]


def test_upgrade_command_table():
    assert playbooks.upgrade_command("npm", "lodash", "4.17.23") == [["npm", "install", "lodash@4.17.23", "--ignore-scripts"]]
    assert playbooks.upgrade_command("poetry", "jinja2", "3.1.4") == [["poetry", "add", "jinja2>=3.1.4"]]
    assert playbooks.upgrade_command("uv", "jinja2", "3.1.4") == [["uv", "lock", "--upgrade-package", "jinja2==3.1.4"]]
    assert playbooks.upgrade_command("go", "golang.org/x/net", "0.23.0") == [["go", "get", "golang.org/x/net@v0.23.0"], ["go", "mod", "tidy"]]
    assert playbooks.upgrade_command("go", "golang.org/x/net", "v0.23.0")[0][2] == "golang.org/x/net@v0.23.0"
    assert playbooks.upgrade_command("pip", "x", "1") == [] and playbooks.upgrade_command("maven", "x", "1") == []


def test_edit_requirements(tmp_path):
    (tmp_path / "requirements.txt").write_text("Flask==2.0.1\nrequests[socks] == 2.31.0  # http\njinja2==3.0.0\n")
    res = playbooks.edit_requirements(tmp_path, "requests", "2.32.0")
    assert res.ok
    assert (tmp_path / "requirements.txt").read_text() == "Flask==2.0.1\nrequests[socks] == 2.32.0  # http\njinja2==3.0.0\n"
    miss = playbooks.edit_requirements(tmp_path, "django", "5.0")
    assert not miss.ok and miss.stderr == "package not pinned in requirements*.txt"


def test_tail():
    assert playbooks.tail("abcdef", 3) == "def" and playbooks.tail("ab", 3) == "ab"


# ---------- base_image_os ----------

def os_item():
    return item(
        FindingClass.BASE_IMAGE_OS,
        [
            finding(package="openssl", version="3.0.11-1", fixed_version="3.0.13-1", package_type="deb"),
            finding(fingerprint="wiz:z", package="zlib", version="1.2.13-1", fixed_version="1.2.13-1+deb12u1", package_type="deb"),
        ],
        key="base_image_os:checkout",
    )


OS_FIX = ReconcileResult(Decision.FIX, "running image has vulnerable OS packages", running_images=(NEW,))


def test_final_base_image():
    text = "# build\nFROM --platform=linux/amd64 node:20 AS build\nRUN npm ci\nfrom gcr.io/distroless/nodejs20@sha256:abc as runtime\nFROM runtime\n"
    assert playbooks.final_base_image(text) == "gcr.io/distroless/nodejs20@sha256:abc"
    assert playbooks.final_base_image("RUN x\n") is None
    assert playbooks.final_base_image("FROM python:3.12-slim\n") == "python:3.12-slim"


def test_package_queries():
    assert playbooks.package_query("deb", "openssl") == "dpkg-query -W -f='${Version}' openssl"
    assert playbooks.package_query("apk", "openssl") == "apk list --installed openssl"
    assert playbooks.package_query("rpm", "openssl") == "rpm -q --qf '%{VERSION}-%{RELEASE}' openssl"
    assert playbooks.package_query("npm", "x") is None
    assert playbooks.parse_package_query("apk", "openssl", "openssl-3.1.4-r0 x86_64 {openssl} (Apache-2.0) [installed]\n") == "3.1.4-r0"
    assert playbooks.parse_package_query("deb", "openssl", " 3.0.13-1\n") == "3.0.13-1"
    assert playbooks.parse_package_query("deb", "openssl", "") is None


def test_base_image_docker_disabled(tmp_path):
    res = playbooks.run_playbook(make_ctx(tmp_path, docker_enabled=False), os_item(), OS_FIX)
    assert res.outcome is Outcome.RECOMMENDATION
    assert res.details == {"packages": ["openssl -> 3.0.13-1", "zlib -> 1.2.13-1+deb12u1"], "dockerfile": "Dockerfile"}


def docker_runner(dockerfile: str, versions: dict[str, str], new_digest: str = "sha256:new") -> FakeRunner:
    r = repo_runner({"Dockerfile": dockerfile})
    r.on(["docker", "pull"])
    r.on(["docker", "image", "inspect"], stdout=f"debian@{new_digest}\n")
    r.on(["docker", "build"])

    def query(args, cwd):
        pkg = args[-1].split()[-1]
        return CommandResult(tuple(args), 0, versions.get(pkg, ""), "")

    r.on(["docker", "run"], handler=query)
    r.on(["git", "diff", "--cached", "--numstat"], stdout="1\t1\tDockerfile\n")
    return r


def test_base_image_digest_bump_pr(tmp_path):
    runner = docker_runner("FROM debian:12-slim@sha256:old\nRUN apt-get update\n", {"openssl": "3.0.13-1", "zlib": "1:1.2.13-1"})
    ctx = make_ctx(tmp_path, runner=runner)
    res = playbooks.run_playbook(ctx, os_item(), OS_FIX)
    assert res.outcome is Outcome.PR_OPENED, res
    assert res.summary == "Bumped the base image digest; rebuilt image has fixed versions"
    assert runner.called(["docker", "pull"])[0] == ("docker", "pull", "debian:12-slim")
    build = runner.called(["docker", "build"])[0]
    assert build[:4] == ("docker", "build", "--pull", "-t") and build[-3:] == ("-f", "Dockerfile", ".")
    assert runner.called(["git", "commit"])[0][-1] == "fix(image): bump base image digest for checkout"


def test_base_image_floating_tag_redeploy(tmp_path):
    runner = docker_runner("FROM debian:12-slim\n", {"openssl": "3.0.13-1", "zlib": "1:1.2.13-1"})
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), os_item(), OS_FIX)
    assert res.outcome is Outcome.REDEPLOY_NEEDED
    assert res.details == {"base_image": "debian:12-slim", "packages": ["openssl -> 3.0.13-1", "zlib -> 1.2.13-1+deb12u1"]}
    assert not runner.called(["docker", "pull"]) and not runner.called(["git", "push"])


def test_base_image_still_vulnerable(tmp_path):
    runner = docker_runner("FROM debian:12-slim\n", {"openssl": "3.0.11-1"})
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), os_item(), OS_FIX)
    assert res.outcome is Outcome.RECOMMENDATION
    assert res.details["still_vulnerable"] == ["openssl installed 3.0.11-1 needs 3.0.13-1", "zlib installed unknown needs 1.2.13-1+deb12u1"]


def test_base_image_missing_dockerfile(tmp_path):
    runner = docker_runner("", {})
    runner.on(["git", "worktree", "add"], handler=lambda a, c: (Path(a[-2]).mkdir(parents=True, exist_ok=True), CommandResult(tuple(a), 0, "", ""))[1])
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), os_item(), OS_FIX)
    assert res.outcome is Outcome.FIX_FAILED and res.summary == "Dockerfile not found: Dockerfile"


# ---------- recommend ----------

def issue(**kw):
    base = dict(kind=FindingKind.ISSUE, package=None, version=None, fixed_version=None, package_type=None, image=None)
    base.update(kw)
    return finding(**base)


def test_no_fix(tmp_path):
    wi = item(FindingClass.NO_FIX_AVAILABLE, [finding(package="minimist", version="1.2.5", fixed_version=None, title="CVE-4")])
    res = playbooks.run_playbook(make_ctx(tmp_path), wi, ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.outcome is Outcome.NO_FIX_YET
    assert res.summary == "No fixed version of minimist is published yet; re-checked daily"
    assert res.details == {"package": "minimist", "installed": ["1.2.5"], "cves": ["CVE-4"]}


def test_unmapped_and_unclassified(tmp_path):
    ctx = make_ctx(tmp_path)
    um = item(FindingClass.UNMAPPED, [issue(title="Bucket is public", resource_name="legacy-bucket", resource_type="BUCKET", resource_id="b1", project="other")], service=None)
    res = playbooks.run_playbook(ctx, um, ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.outcome is Outcome.ADD_MAPPING
    assert res.details == {"resource_name": "legacy-bucket", "resource_type": "BUCKET", "resource_id": "b1", "project": "other", "image": ""}
    uc = item(FindingClass.UNCLASSIFIED, [issue(title="Odd", raw={"B": "1", "A": "2"})])
    res2 = playbooks.run_playbook(ctx, uc, ReconcileResult(Decision.RECOMMEND, "x"))
    assert res2.outcome is Outcome.ADD_RULE and res2.details["columns"] == ["A", "B"] and res2.details["kind"] == "issue"


def head_runner(files: dict[str, str]) -> FakeRunner:
    return repo_runner(files)


def unauth_item():
    return item(FindingClass.UNAUTH_ENDPOINT, [issue(title="Cloud Run service allows unauthenticated invocations", resource_id="run-1")])


PUBLIC = {"bindings": [{"role": "roles/run.invoker", "members": ["allUsers"]}]}


def test_unauth_not_public(tmp_path):
    runner = FakeRunner().on_json(["gcloud", "run", "services", "get-iam-policy"], {"bindings": []})
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), unauth_item(), ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.summary == "Cloud Run IAM does not allow public access; check app-level auth for this endpoint"


def test_unauth_public_undeclared(tmp_path):
    runner = FakeRunner().on_json(["gcloud", "run", "services", "get-iam-policy"], PUBLIC)
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), unauth_item(), ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.outcome is Outcome.RECOMMENDATION
    assert res.details["command"] == (
        "gcloud run services remove-iam-policy-binding checkout-api --member=allUsers --role=roles/run.invoker"
        " --region=europe-west1 --project=prod-project"
    )
    assert not runner.called(["gcloud", "run", "services", "remove-iam-policy-binding"])


def test_unauth_public_declared(tmp_path):
    svc = {"checkout": replace(CHECKOUT, public_endpoints=("/healthz", "/webhooks/payments"))}
    runner = head_runner({"app.js": "x"}).on_json(["gcloud", "run", "services", "get-iam-policy"], PUBLIC)
    agent = FakeAgent([{"unprotected_routes": [], "notes": "jwt middleware"}, {"unprotected_routes": ["GET /admin (app.js:3)"], "notes": "n"}])
    ctx = make_ctx(tmp_path, runner=runner, agent=agent, services=svc)
    res = playbooks.run_playbook(ctx, unauth_item(), ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.outcome is Outcome.ACCEPTED
    assert res.summary == "Public access is declared for: /healthz, /webhooks/payments; no other unprotected routes found"
    t = agent.tasks[0]
    assert (t.agent, t.prompt_name, t.schema_name, t.allowed_edit_globs) == ("reviewer", "review_auth", "review_auth", ())
    assert t.workdir == tmp_path / "work" / "heads" / "checkout"
    res2 = playbooks.run_playbook(ctx, unauth_item(), ReconcileResult(Decision.RECOMMEND, "x"))
    assert res2.outcome is Outcome.RECOMMENDATION and res2.details["unprotected_routes"] == ["GET /admin (app.js:3)"]


def test_sa_key(tmp_path):
    runner = head_runner({"app.py": "x"}).on_json(
        ["gcloud", "iam", "service-accounts", "keys", "list"],
        [{"name": "projects/p/serviceAccounts/sa/keys/abc123", "validAfterTime": "2026-08-01T00:00:00Z"}],
    )
    agent = FakeAgent([{"files": ["app.py:12"], "notes": "loads key"}])
    wi = item(FindingClass.SA_KEY, [issue(title="Service account key older than 90 days", resource_name="checkout-api@prod-project.iam.gserviceaccount.com")])
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner, agent=agent), wi, ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.outcome is Outcome.RECOMMENDATION
    assert res.summary == "Delete the user-managed key; Cloud Run uses the attached service account and needs no key"
    assert res.details["user_managed_keys"] == ["abc123 (110 days)"]
    assert res.details["key_usage_files"] == ["app.py:12"]
    assert res.details["command"] == "gcloud iam service-accounts keys delete KEY_ID --iam-account=checkout-api@prod-project.iam.gserviceaccount.com"


def test_iac_with_terraform(tmp_path):
    runner = head_runner({"infra/main.tf": 'resource "google_sql_database_instance" "db" {\n  name = "payments-db"\n}\n'})
    agent = FakeAgent([{"diff": "--- a\n+++ b", "explanation": "Disable public IP"}])
    wi = item(FindingClass.IAC_CONFIG, [issue(title="Database allows public IP", resource_name="payments-db")], service="payments")
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner, agent=agent), wi, ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.summary == "Config finding 'Database allows public IP' on payments-db"
    assert res.details["terraform_matches"] == ["infra/main.tf:2"]
    assert res.details["suggested_diff"] == "--- a\n+++ b"
    assert agent.tasks[0].variables["matches"] == "infra/main.tf:2"


def test_iac_without_terraform_dir_is_generic(tmp_path):
    wi = item(FindingClass.IAC_CONFIG, [issue(title="Weird", remediation="Do X")])
    res = playbooks.run_playbook(make_ctx(tmp_path), wi, ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.outcome is Outcome.RECOMMENDATION and res.summary == "Weird"
    assert res.details == {"resource_name": "checkout-api", "remediation": "Do X"}


def test_lookup_error_is_reported(tmp_path):
    runner = FakeRunner().on(["gcloud"], returncode=1, stderr="403")
    res = playbooks.run_playbook(make_ctx(tmp_path, runner=runner), unauth_item(), ReconcileResult(Decision.RECOMMEND, "x"))
    assert res.outcome is Outcome.RECOMMENDATION and res.details["lookup_error"] == "403"
