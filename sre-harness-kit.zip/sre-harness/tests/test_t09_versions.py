"""T09: version comparison and lockfile lookups (src/sre_harness/versions.py)."""

import json

import pytest

from fakes import finding
from sre_harness.versions import (
    compare_versions,
    ecosystem_for,
    installed_version,
    is_fixed,
    is_os_ecosystem,
    parse_fixed_versions,
    pick_target,
    sorted_versions,
    target_for_findings,
)


@pytest.mark.parametrize(
    "ptype, svc, expected",
    [("Debian", "npm", "deb"), ("pypi", "generic", "pip"), (None, "npm", "npm"), ("weird", "go", "go"), ("APK", "x", "apk")],
)
def test_ecosystem_for(ptype, svc, expected):
    assert ecosystem_for(ptype, svc) == expected


def test_is_os_ecosystem():
    assert is_os_ecosystem("deb") and is_os_ecosystem("rpm") and not is_os_ecosystem("npm")


@pytest.mark.parametrize(
    "a, b, expected",
    [
        ("1.10.0", "1.9.9", 1),
        ("1.2.3", "1.2.3", 0),
        ("1.0", "1.0.0", 0),
        ("v1.2.3", "1.2.3", 0),
        ("2.0.0-rc1", "2.0.0", -1),
        ("2.0.0", "2.0.0-rc1", 1),
        ("1.0.1", "1.0.rc1", 1),
        ("1.0a1", "1.0", -1),
        ("1.0.post1", "1.0", 1),
        ("4.17.21", "4.17.20", 1),
        ("1.2.3+build5", "1.2.3", 0),
        ("1.0.0-alpha", "1.0.0-beta", -1),
    ],
)
def test_semver_like(a, b, expected):
    assert compare_versions(a, b, "npm") == expected


@pytest.mark.parametrize(
    "a, b, expected",
    [
        ("1:1.0", "2.0", 1),
        ("1.0~rc1", "1.0", -1),
        ("1.2.3-1", "1.2.3-2", -1),
        ("3.0.13-1", "3.0.11-1", 1),
        ("1.0-1", "1.0-1", 0),
        ("1.0a", "1.0+", -1),
        ("2.36.1-8+deb11u1", "2.36.1-8", 1),
        ("1.10", "1.9", 1),
        ("3.1.4-r0", "3.1.4-r1", -1),
    ],
)
def test_dpkg_like(a, b, expected):
    assert compare_versions(a, b, "deb") == expected


def test_parse_fixed_versions():
    assert parse_fixed_versions(">=2.3.1, 3.0.2 || unknown") == ["2.3.1", "3.0.2"]
    assert parse_fixed_versions("v1.2.0 v1.2.0") == ["v1.2.0"]
    assert parse_fixed_versions("") == [] and parse_fixed_versions(None) == []


def test_pick_target():
    assert pick_target("2.1.0", "2.3.1, 3.0.2", "npm") == "2.3.1"
    assert pick_target("3.0.0", "2.3.1, 3.0.2", "npm") == "3.0.2"
    assert pick_target("3.0.5", "2.3.1, 3.0.2", "npm") is None
    assert pick_target(None, "3.0.2, 2.3.1", "npm") == "2.3.1"
    assert pick_target("1.0", None, "npm") is None


def test_sorted_versions_and_target_for_findings():
    assert sorted_versions(["1.10", "1.9", "1.9.1"], "npm") == ["1.9", "1.9.1", "1.10"]
    fs = [finding(fixed_version="4.17.21"), finding(fixed_version="4.17.23, 5.0.1"), finding(fixed_version=None)]
    assert target_for_findings(fs, "npm") == "4.17.23"
    assert target_for_findings([finding(fixed_version=None)], "npm") is None


def test_is_fixed():
    assert is_fixed("4.17.23", "4.17.21", "npm")
    assert not is_fixed("4.17.20", "4.17.21", "npm")
    assert not is_fixed(None, "1.0", "npm")


def test_npm_lockfile(tmp_path):
    (tmp_path / "package-lock.json").write_text(
        json.dumps({"packages": {"": {}, "node_modules/lodash": {"version": "4.17.20"}}}), encoding="utf-8"
    )
    assert installed_version(tmp_path, "lodash", "npm") == "4.17.20"
    assert installed_version(tmp_path, "minimist", "npm") is None


def test_npm_lockfile_v1(tmp_path):
    (tmp_path / "package-lock.json").write_text(json.dumps({"dependencies": {"lodash": {"version": "4.0.0"}}}))
    assert installed_version(tmp_path, "lodash", "npm") == "4.0.0"


def test_requirements(tmp_path):
    (tmp_path / "requirements.txt").write_text("# deps\nFlask==2.0.1\nrequests[socks] == 2.31.0  # http\n")
    (tmp_path / "requirements-dev.txt").write_text("pytest==8.0.0\n")
    assert installed_version(tmp_path, "flask", "pip") == "2.0.1"
    assert installed_version(tmp_path, "Requests", "pip") == "2.31.0"
    assert installed_version(tmp_path, "pytest", "pip") == "8.0.0"
    assert installed_version(tmp_path, "django", "pip") is None


def test_poetry_and_uv(tmp_path):
    lock = '[[package]]\nname = "Jinja2"\nversion = "3.1.2"\n\n[[package]]\nname = "markupsafe"\nversion = "2.1.3"\n'
    (tmp_path / "poetry.lock").write_text(lock)
    (tmp_path / "uv.lock").write_text(lock)
    assert installed_version(tmp_path, "jinja2", "poetry") == "3.1.2"
    assert installed_version(tmp_path, "MarkupSafe", "uv") == "2.1.3"


def test_go_mod(tmp_path):
    (tmp_path / "go.mod").write_text(
        "module x\n\ngo 1.22\n\nrequire golang.org/x/net v0.17.0\n\nrequire (\n\tgithub.com/a/b v1.2.3 // indirect\n)\n"
    )
    assert installed_version(tmp_path, "golang.org/x/net", "go") == "v0.17.0"
    assert installed_version(tmp_path, "github.com/a/b", "go") == "v1.2.3"


def test_unknown_or_missing(tmp_path):
    assert installed_version(tmp_path, "x", "maven") is None
    assert installed_version(tmp_path, "x", "npm") is None
    (tmp_path / "package-lock.json").write_text("{not json")
    assert installed_version(tmp_path, "x", "npm") is None
