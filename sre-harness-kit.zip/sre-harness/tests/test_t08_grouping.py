"""T08: grouping findings into work items (src/sre_harness/grouping.py)."""

import pytest

from fakes import finding
from sre_harness.grouping import group, work_item_key
from sre_harness.models import FindingClass, FindingKind


@pytest.mark.parametrize(
    "cls, service, f, expected",
    [
        (FindingClass.APP_DEPENDENCY, "checkout", finding(), "app_dependency:checkout:lodash"),
        (FindingClass.BASE_IMAGE_OS, "checkout", finding(package="openssl"), "base_image_os:checkout"),
        (FindingClass.NO_FIX_AVAILABLE, "checkout", finding(title="CVE-9"), "no_fix_available:checkout:lodash:CVE-9"),
        (FindingClass.NO_FIX_AVAILABLE, "checkout", finding(package=None, title="CVE-9"), "no_fix_available:checkout::CVE-9"),
        (FindingClass.UNAUTH_ENDPOINT, "checkout", finding(resource_id="run-1"), "unauth_endpoint:checkout:run-1"),
        (FindingClass.SA_KEY, "checkout", finding(resource_id="sa-1"), "sa_key:checkout:sa-1"),
        (FindingClass.IAC_CONFIG, "payments", finding(resource_id="sql-1"), "iac_config:payments:sql-1"),
        (FindingClass.UNMAPPED, None, finding(resource_id="bucket-1"), "unmapped:bucket-1"),
        (FindingClass.UNCLASSIFIED, "checkout", finding(fingerprint="wiz:zz"), "unclassified:wiz:zz"),
    ],
)
def test_work_item_key(cls, service, f, expected):
    assert work_item_key(cls, service, f) == expected


def test_group_merges_and_sorts():
    a = finding(fingerprint="wiz:a", title="CVE-1")
    b = finding(fingerprint="wiz:b", title="CVE-2")
    c = finding(fingerprint="wiz:c", kind=FindingKind.ISSUE, package=None, resource_id="bucket-1")
    items = group(
        [
            (c, FindingClass.UNMAPPED, None),
            (a, FindingClass.APP_DEPENDENCY, "checkout"),
            (b, FindingClass.APP_DEPENDENCY, "checkout"),
        ]
    )
    assert [i.key for i in items] == ["app_dependency:checkout:lodash", "unmapped:bucket-1"]
    assert [f.fingerprint for f in items[0].findings] == ["wiz:a", "wiz:b"]
    assert items[0].service == "checkout" and items[0].finding_class is FindingClass.APP_DEPENDENCY
    assert items[1].service is None


def test_group_empty():
    assert group([]) == []
