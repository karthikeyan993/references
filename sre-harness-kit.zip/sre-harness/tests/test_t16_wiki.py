"""T16: ops wiki incident pages (src/sre_harness/wiki.py)."""

from sre_harness import wiki
from sre_harness.models import EvidenceItem, SloAlert

ALERT = SloAlert(
    "projects/p/alerts/ABC_1", "p", "projects/p/alertPolicies/1", "Checkout availability", "OPEN",
    "2026-11-19T08:00:00Z", None, "burn", "checkout", "checkout-availability",
)
EVIDENCE = [EvidenceItem("E1", "alert", "Alert opened"), EvidenceItem("E2", "log_signature", "40x timeout")]
RCA = {"summary": "DB pool exhausted"}
HYPS = [{"cause": "Pool too small", "evidence": ["E2"], "confidence": "high"}]


def test_slug():
    assert wiki.slug("Checkout API!") == "checkout-api"
    assert wiki.slug("***") == "unknown"


def test_incident_path(tmp_path):
    assert wiki.incident_path(tmp_path, ALERT) == tmp_path / "incidents" / "2026-11-19-checkout-abc-1.md"


def test_render_incident_exact():
    assert wiki.render_incident(ALERT, RCA, HYPS, EVIDENCE) == (
        "# Incident: Checkout availability\n"
        "\n"
        "- Service: checkout\n"
        "- SLO: checkout-availability\n"
        "- Opened: 2026-11-19T08:00:00Z\n"
        "- Closed: open\n"
        "- Alert: `projects/p/alerts/ABC_1`\n"
        "\n"
        "## Harness analysis\n"
        "\n"
        "DB pool exhausted\n"
        "\n"
        "1. Pool too small (confidence: high; evidence: E2)\n"
        "\n"
        "## Evidence\n"
        "\n"
        "- E1 (alert): Alert opened\n"
        "- E2 (log_signature): 40x timeout\n"
        "\n"
        "## Actual cause\n"
        "\n"
        "<!-- Fill in after the incident. The next analysis for this service reads this line. -->\n"
        "Actual cause:\n"
    )


def test_render_insufficient():
    text = wiki.render_incident(ALERT, None, [], EVIDENCE[:1])
    assert "Insufficient evidence.\n\n## Evidence" in text


def test_write_does_not_overwrite(tmp_path):
    p = wiki.write_incident_page(tmp_path, ALERT, RCA, HYPS, EVIDENCE)
    p.write_text(p.read_text().replace("Actual cause:\n", "Actual cause: pool size halved in deploy 42\n"))
    again = wiki.write_incident_page(tmp_path, ALERT, None, [], [])
    assert again == p and "pool size halved" in p.read_text()


def test_mark_resolved(tmp_path):
    p = wiki.write_incident_page(tmp_path, ALERT, RCA, HYPS, EVIDENCE)
    assert wiki.mark_resolved(p, "2026-11-19T08:45:00Z") is True
    assert "- Closed: 2026-11-19T08:45:00Z\n" in p.read_text()
    assert wiki.mark_resolved(p, "x") is False
    assert wiki.mark_resolved(tmp_path / "missing.md", "x") is False


def test_read_incident_history(tmp_path):
    def page(name, service, cause):
        p = tmp_path / "incidents" / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(f"# Incident: x\n\n- Service: {service}\n- Opened: {name[:10]}\n\nActual cause: {cause}\n")

    page("2026-11-01-checkout-a.md", "checkout", "bad deploy")
    page("2026-11-05-checkout-b.md", "checkout", "")
    page("2026-11-07-checkout-api-c.md", "checkout-api", "other service")
    page("2026-11-09-checkout-d.md", "checkout", "quota")
    hist = wiki.read_incident_history(tmp_path, "checkout")
    assert hist == [
        {"file": "2026-11-09-checkout-d.md", "opened": "2026-11-09", "actual_cause": "quota"},
        {"file": "2026-11-01-checkout-a.md", "opened": "2026-11-01", "actual_cause": "bad deploy"},
    ]
    assert wiki.read_incident_history(tmp_path, "checkout", limit=1)[0]["actual_cause"] == "quota"
    assert wiki.read_incident_history(tmp_path / "none", "checkout") == []
