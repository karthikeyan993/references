"""Test doubles and builders. PROVIDED FILE. Do not edit.

Every test talks to the outside world only through these fakes, so the whole
suite runs offline, with no gcloud, gh, git, docker or opencode installed.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Sequence
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sre_harness.config import DEFAULT_COLUMNS, HarnessConfig
from sre_harness.models import (
    ChatMessage,
    CommandResult,
    Finding,
    FindingClass,
    FindingKind,
    RuntimeRef,
    Service,
    WorkItem,
)

FIXTURES = Path(__file__).parent / "fixtures"
REPO_ROOT = Path(__file__).resolve().parent.parent
RUNTIME_DIR = REPO_ROOT / "runtime"

Handler = Callable[[list[str], str | None], CommandResult]


class FakeRunner:
    """Scripted CommandRunner.

    runner.on(['git', 'fetch'], stdout='...') answers every command whose args
    START WITH that prefix. The most recently added matching rule wins, so a
    test can override a default. A handler callable gets (args, cwd) and
    returns a CommandResult; use it to simulate side effects (create files).
    Unscripted commands return returncode 127 with stderr 'fake: no response scripted'.
    """

    def __init__(self) -> None:
        self.rules: list[tuple[tuple[str, ...], Handler | CommandResult]] = []
        self.calls: list[tuple[tuple[str, ...], str | None]] = []

    def on(
        self,
        prefix: Sequence[str],
        stdout: str = "",
        returncode: int = 0,
        stderr: str = "",
        handler: Handler | None = None,
    ) -> FakeRunner:
        if handler is not None:
            self.rules.append((tuple(prefix), handler))
        else:
            self.rules.append((tuple(prefix), CommandResult(tuple(prefix), returncode, stdout, stderr)))
        return self

    def on_json(self, prefix: Sequence[str], data: Any) -> FakeRunner:
        return self.on(prefix, stdout=json.dumps(data))

    def run(
        self,
        args: Sequence[str],
        *,
        cwd: str | None = None,
        timeout: int = 300,
        env: Any = None,
    ) -> CommandResult:
        args_t = tuple(args)
        self.calls.append((args_t, cwd))
        for prefix, response in reversed(self.rules):
            if args_t[: len(prefix)] == prefix:
                if callable(response):
                    return response(list(args_t), cwd)
                return CommandResult(args_t, response.returncode, response.stdout, response.stderr)
        return CommandResult(args_t, 127, "", f"fake: no response scripted for {' '.join(args_t)}")

    def called(self, prefix: Sequence[str]) -> list[tuple[str, ...]]:
        p = tuple(prefix)
        return [a for a, _ in self.calls if a[: len(p)] == p]


class FakeHttp:
    """Records POSTs. statuses is consumed in order; when empty, `default` is returned."""

    def __init__(self, statuses: Sequence[int] = (), default: int = 200) -> None:
        self.statuses = list(statuses)
        self.default = default
        self.posts: list[tuple[str, dict[str, Any]]] = []

    def post_json(self, url: str, payload: Any, timeout: int = 30) -> int:
        self.posts.append((url, dict(payload)))
        return self.statuses.pop(0) if self.statuses else self.default


class FixedClock:
    def __init__(self, when: datetime | None = None) -> None:
        self.when = when or datetime(2026, 11, 19, 9, 30, tzinfo=UTC)

    def now(self) -> datetime:
        return self.when


class FakeChat:
    """ChatPort double that records every message."""

    def __init__(self) -> None:
        self.messages: list[ChatMessage] = []
        self.flushes = 0

    def send(self, msg: ChatMessage) -> bool:
        self.messages.append(msg)
        return True

    def flush_outbox(self) -> int:
        self.flushes += 1
        return 0

    def texts(self) -> list[str]:
        return [m.text for m in self.messages]


class FakeAgent:
    """AgentPort double. responses are returned (dict) or raised (Exception) in order."""

    def __init__(self, responses: Sequence[dict[str, Any] | Exception] = ()) -> None:
        self.responses = list(responses)
        self.tasks: list[Any] = []

    def run(self, task: Any) -> dict[str, Any]:
        self.tasks.append(task)
        if not self.responses:
            raise AssertionError(f"FakeAgent: unexpected call for agent {getattr(task, 'agent', '?')}")
        r = self.responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


def make_cfg(tmp_path: Path, **overrides: Any) -> HarnessConfig:
    """A valid HarnessConfig rooted at tmp_path, built directly (no YAML)."""
    cfg = HarnessConfig(
        root=tmp_path,
        chat_webhook_env="SRE_CHAT_WEBHOOK",
        wiz_report_uri_template="gs://acme-wiz-reports/daily/{date}/",
        wiz_report_suffix=".csv",
        wiz_columns=dict(DEFAULT_COLUMNS),
        gcp_impersonate=None,
        slo_projects=("prod-project",),
        slo_logs_lookback_minutes=120,
        slo_revision_lookback_hours=24,
        agent_enabled=True,
        agent_binary="opencode",
        agent_model="github-copilot/gpt-6-luna",
        agent_timeout_seconds=900,
        agent_max_calls_per_day=10,
        max_prs_per_day=3,
        max_cards_per_run=30,
        max_changed_lines=300,
        workdir=tmp_path / "work",
        state_db=tmp_path / "state" / "harness.db",
        wiki_dir=tmp_path / "wiki",
        stop_file=tmp_path / "STOP",
        docker_enabled=True,
    )
    return replace(cfg, **overrides)


CHECKOUT = Service(
    name="checkout",
    repo="github.com/acme/checkout-api",
    branch="main",
    build="npm ci && npm run build",
    test="npm test",
    runtime=RuntimeRef(kind="cloud-run", project="prod-project", name="checkout-api", region="europe-west1"),
    ecosystem="npm",
    images=("europe-west1-docker.pkg.dev/prod-project/apps/checkout-api",),
    service_accounts=("checkout-api@prod-project.iam.gserviceaccount.com",),
    slos=("checkout-availability",),
    owners=("payments-team",),
)

PAYMENTS = Service(
    name="payments",
    repo="github.com/acme/payments",
    branch="main",
    build="",
    test="pytest -q",
    runtime=RuntimeRef(kind="none"),
    ecosystem="pip",
    resources=("payments-db",),
    terraform_dir="infra",
)

SERVICES = {"checkout": CHECKOUT, "payments": PAYMENTS}

IMAGE_REPO = "europe-west1-docker.pkg.dev/prod-project/apps/checkout-api"


def finding(**kw: Any) -> Finding:
    """A Finding with sensible defaults; override any field by keyword."""
    base: dict[str, Any] = dict(
        fingerprint="wiz:f1",
        kind=FindingKind.VULNERABILITY,
        title="CVE-2024-1111",
        severity="HIGH",
        resource_name="checkout-api",
        resource_type="CONTAINER_IMAGE",
        resource_id="img-new",
        project="prod-project",
        package="lodash",
        version="4.17.20",
        fixed_version="4.17.21",
        package_type="npm",
        image=f"{IMAGE_REPO}@sha256:aaa",
        wiz_id="f1",
    )
    base.update(kw)
    return Finding(**base)


def item(cls: FindingClass, findings: Sequence[Finding], service: str | None = "checkout", key: str | None = None) -> WorkItem:
    return WorkItem(key=key or f"{cls.value}:{service}:x", finding_class=cls, service=service, findings=tuple(findings))


def default_rules() -> list[Any]:
    """The rules of fixtures/rules.yaml, built directly (no YAML loading)."""
    from sre_harness.models import Rule

    return [
        Rule("no-fix-yet", FindingClass.NO_FIX_AVAILABLE, {"kind": "vulnerability", "fixed_version": {"empty": True}}),
        Rule(
            "os-packages",
            FindingClass.BASE_IMAGE_OS,
            {"kind": "vulnerability", "package_type": {"in": ["deb", "dpkg", "apk", "rpm", "os"]}},
        ),
        Rule("app-dependencies", FindingClass.APP_DEPENDENCY, {"kind": "vulnerability"}),
        Rule(
            "unauthenticated-endpoints",
            FindingClass.UNAUTH_ENDPOINT,
            {"kind": "issue", "title": {"regex": "(?i)unauthenticated|allUsers|publicly invocable"}},
        ),
        Rule("service-account-keys", FindingClass.SA_KEY, {"kind": "issue", "title": {"regex": "(?i)service account key"}}),
        Rule("other-config", FindingClass.IAC_CONFIG, {"kind": "issue"}),
        Rule("catch-all", FindingClass.UNCLASSIFIED, {}),
    ]


def make_ctx(
    tmp_path: Path,
    runner: FakeRunner | None = None,
    agent: FakeAgent | None = None,
    chat: FakeChat | None = None,
    services: dict[str, Service] | None = None,
    day: str = "2026-11-19",
    **cfg_overrides: Any,
) -> Any:
    """A Context wired with fakes and a real SQLite store under tmp_path."""
    from sre_harness.context import Context
    from sre_harness.state import Store

    cfg = make_cfg(tmp_path, **cfg_overrides)
    return Context(
        cfg=cfg,
        services=services if services is not None else dict(SERVICES),
        rules=default_rules(),
        store=Store(cfg.state_db),
        runner=runner or FakeRunner(),
        chat=chat or FakeChat(),
        agent=agent or FakeAgent(),
        clock=FixedClock(),
        runtime_dir=RUNTIME_DIR,
        run_id=1,
        day=day,
    )


LOCK_OLD = {"packages": {"": {}, "node_modules/lodash": {"version": "4.17.20"}}}
LOCK_NEW = {"packages": {"": {}, "node_modules/lodash": {"version": "4.17.23"}}}
PR_URL = "https://github.com/acme/checkout-api/pull/12"


def repo_runner(files: dict[str, str]) -> FakeRunner:
    """A FakeRunner that simulates clone, worktrees, npm, build, diff, push and PR creation."""
    r = FakeRunner()

    def clone(args, cwd):
        Path(args[-1], ".git").mkdir(parents=True, exist_ok=True)
        return CommandResult(tuple(args), 0, "", "")

    def worktree_add(args, cwd):
        dest = Path(args[-2])
        dest.mkdir(parents=True, exist_ok=True)
        (dest / ".git").write_text("gitdir: x")
        for rel, text in files.items():
            p = dest / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text)
        return CommandResult(tuple(args), 0, "", "")

    def npm_install(args, cwd):
        Path(cwd, "package-lock.json").write_text(json.dumps(LOCK_NEW))
        return CommandResult(tuple(args), 0, "", "")

    r.on(["git"])
    r.on(["git", "clone"], handler=clone)
    r.on(["git", "worktree", "add"], handler=worktree_add)
    r.on(["gh", "pr", "list"], stdout="[]")
    r.on(["npm", "install"], handler=npm_install)
    r.on(["sh", "-c"])
    r.on(["git", "diff", "--cached", "--numstat"], stdout="1\t1\tpackage.json\n6\t6\tpackage-lock.json\n")
    r.on(["gh", "pr", "create"], stdout=PR_URL + "\n")
    return r


