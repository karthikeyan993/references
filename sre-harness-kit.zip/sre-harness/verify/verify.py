#!/usr/bin/env python3
"""Verification gate for the coding agent. PROVIDED FILE. Do not edit.

Usage:
  python verify/verify.py --task T05   run every gate for tasks T01..T05
  python verify/verify.py --status     quick test status of every task + the next task
  python verify/verify.py --all        same as --task T19

A task is DONE only when `--task TXX` prints 'RESULT: TXX PASS'.
The full report is also written to verify/last_report.txt.
"""

from __future__ import annotations

import argparse
import ast
import datetime as dt
import hashlib
import importlib
import inspect
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src" / "sre_harness"
VERIFY = ROOT / "verify"
TASKS: dict[str, dict] = json.loads((VERIFY / "tasks.json").read_text())
CONTRACTS: dict[str, dict] = json.loads((VERIFY / "contracts.json").read_text())
ORDER = sorted(TASKS)
MAX_LINES = 25

# Forbidden-pattern policy (gate 5). file names are relative to src/sre_harness.
STRING_RULES = [
    # (description, predicate on any non-docstring string constant, files where it is allowed)
    ("'--dangerously-skip-permissions' flag", lambda s: "--dangerously-skip-permissions" in s, set()),
]
# A list or tuple literal whose FIRST element is this word builds a command line.
COMMAND_RULES = {
    "gcloud": {"gcp.py"},
    "gh": {"gitops.py", "cli.py"},
    "git": {"gitops.py", "agent.py", "cli.py"},
    "docker": {"playbooks.py", "cli.py"},
}
IMPORT_RULES = [
    ("subprocess import outside runner.py", "subprocess", {"runner.py"}),
    ("urllib.request import outside runner.py", "urllib.request", {"runner.py"}),
    ("requests library (not a dependency)", "requests", set()),
    ("httpx library (not a dependency)", "httpx", set()),
    ("os.system-style shell access", "pty", set()),
]
CALL_RULES = [
    ("eval()", "eval", set()),
    ("exec()", "exec", set()),
    ("os.system()", "os.system", set()),
    ("os.popen()", "os.popen", set()),
    ("print() outside cli.py (use return values or Chat cards)", "print", {"cli.py"}),
]


def tasks_up_to(task: str) -> list[str]:
    if task not in TASKS:
        raise SystemExit(f"unknown task {task}; valid: {', '.join(ORDER)}")
    return ORDER[: ORDER.index(task) + 1]


def run(cmd: list[str]) -> tuple[int, str]:
    proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return proc.returncode, (proc.stdout + proc.stderr).strip()


def tool(name: str) -> list[str]:
    """[python, -m, name] when importable in this interpreter, else the bare command on PATH."""
    code, _ = run([sys.executable, "-c", f"import {name}"])
    return [sys.executable, "-m", name] if code == 0 else [name]


def clip(lines: list[str]) -> list[str]:
    return lines[:MAX_LINES] + ([f"... {len(lines) - MAX_LINES} more"] if len(lines) > MAX_LINES else [])


# ---------------------------------------------------------------- gates
def gate_protected() -> list[str]:
    manifest = VERIFY / "protected.sha256"
    if not manifest.exists():
        return ["verify/protected.sha256 is missing"]
    problems = []
    for line in manifest.read_text().splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        path = ROOT / rel
        if not path.exists():
            problems.append(f"missing protected file: {rel}")
        elif hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            problems.append(f"protected file was changed: {rel}  (restore it with: git checkout kit-baseline -- {rel})")
    return problems


def gate_modules(tasks: list[str]) -> list[str]:
    return [
        f"missing module src/sre_harness/{m}.py ({t})"
        for t in tasks
        for m in TASKS[t]["modules"]
        if not (SRC / f"{m}.py").exists()
    ]


def gate_no_stubs(tasks: list[str]) -> list[str]:
    problems = []
    for t in tasks:
        for m in TASKS[t]["modules"]:
            path = SRC / f"{m}.py"
            if not path.exists():
                continue
            for n, line in enumerate(path.read_text().splitlines(), 1):
                if "NotImplementedError" in line:
                    problems.append(f"src/sre_harness/{m}.py:{n} still raises NotImplementedError ({t})")
    return problems


def _default(value: object) -> str | None:
    if value is inspect.Parameter.empty:
        return None
    if callable(value):
        return f"<{getattr(value, '__name__', 'callable')}>"
    return repr(value)


def _spec(sig: inspect.Signature) -> list[list]:
    return [[p.name, p.kind.name, _default(p.default)] for p in sig.parameters.values()]


def _fmt(spec: list[list]) -> str:
    return "(" + ", ".join(p[0] + (f"={p[2]}" if p[2] is not None else "") for p in spec) + ")"


def gate_contracts(tasks: list[str]) -> list[str]:
    sys.path.insert(0, str(ROOT / "src"))
    problems = []
    for t in tasks:
        for m in TASKS[t]["modules"]:
            contract = CONTRACTS[m]
            try:
                mod = importlib.import_module(f"sre_harness.{m}")
            except Exception as exc:  # noqa: BLE001
                problems.append(f"{m}.py does not import: {type(exc).__name__}: {exc}")
                continue
            for name in contract["constants"]:
                if not hasattr(mod, name):
                    problems.append(f"{m}.{name}: constant is missing")
            for name, spec in contract["functions"].items():
                fn = getattr(mod, name, None)
                if fn is None or not callable(fn):
                    problems.append(f"{m}.{name}: function is missing")
                elif _spec(inspect.signature(fn)) != spec:
                    problems.append(f"{m}.{name}: parameters must be {_fmt(spec)}, found {_fmt(_spec(inspect.signature(fn)))}")
            for cname, cspec in contract["classes"].items():
                cls = getattr(mod, cname, None)
                if cls is None or not inspect.isclass(cls):
                    problems.append(f"{m}.{cname}: class is missing")
                    continue
                if "fields" in cspec:
                    import dataclasses

                    got = [f.name for f in dataclasses.fields(cls)] if dataclasses.is_dataclass(cls) else None
                    if got != cspec["fields"]:
                        problems.append(f"{m}.{cname}: dataclass fields must be {cspec['fields']}, found {got}")
                for mname, spec in cspec.get("methods", {}).items():
                    meth = vars(cls).get(mname)
                    if meth is None:
                        problems.append(f"{m}.{cname}.{mname}: method is missing")
                    elif _spec(inspect.signature(meth)) != spec:
                        problems.append(
                            f"{m}.{cname}.{mname}: parameters must be {_fmt(spec)}, found {_fmt(_spec(inspect.signature(meth)))}"
                        )
    return problems


def _docstring_nodes(tree: ast.AST) -> set[int]:
    ids = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                ids.add(id(first.value))
    return ids


def _call_name(func: ast.AST) -> str:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
        return f"{func.value.id}.{func.attr}"
    return ""


def gate_forbidden() -> list[str]:
    problems = []
    for path in sorted(SRC.glob("*.py")):
        rel = path.name
        try:
            tree = ast.parse(path.read_text())
        except SyntaxError as exc:
            problems.append(f"{rel}: syntax error: {exc}")
            continue
        docs = _docstring_nodes(tree)
        for node in ast.walk(tree):
            line = getattr(node, "lineno", 0)
            if isinstance(node, ast.Constant) and isinstance(node.value, str) and id(node) not in docs:
                for desc, pred, allowed in STRING_RULES:
                    if rel not in allowed and pred(node.value):
                        problems.append(f"{rel}:{line}: forbidden {desc}")
            elif isinstance(node, (ast.List, ast.Tuple)) and node.elts:
                words = [e.value for e in node.elts if isinstance(e, ast.Constant) and isinstance(e.value, str)]
                if "push" in words and any(w.startswith("--force") or w == "-f" for w in words):
                    problems.append(f"{rel}:{line}: forbidden force push")
                first = node.elts[0]
                if isinstance(first, ast.Constant) and first.value in COMMAND_RULES and rel not in COMMAND_RULES[first.value]:
                    allowed = "/".join(sorted(COMMAND_RULES[first.value]))
                    problems.append(f"{rel}:{line}: forbidden '{first.value}' command outside {allowed}")
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                names = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or ""]
                for desc, mod, allowed in IMPORT_RULES:
                    if rel not in allowed and any(n == mod or n.startswith(mod + ".") for n in names):
                        problems.append(f"{rel}:{line}: forbidden {desc}")
            elif isinstance(node, ast.Call):
                name = _call_name(node.func)
                for desc, target, allowed in CALL_RULES:
                    if rel not in allowed and name == target:
                        problems.append(f"{rel}:{line}: forbidden {desc}")
                for kw in node.keywords:
                    if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                        problems.append(f"{rel}:{line}: forbidden shell=True")
            elif isinstance(node, ast.ExceptHandler) and node.type is None:
                problems.append(f"{rel}:{line}: forbidden bare 'except:' (catch specific exceptions)")
    return problems


def gate_ruff() -> list[str]:
    code, out = run([*tool("ruff"), "check", "src", "--output-format", "concise"])
    return [] if code == 0 else [line for line in out.splitlines() if line.strip()]


def gate_mypy() -> list[str]:
    code, out = run([*tool("mypy")])
    return [] if code == 0 else [line for line in out.splitlines() if ": error:" in line] or out.splitlines()


def gate_tests(tasks: list[str]) -> list[str]:
    files = [f for t in tasks for f in TASKS[t]["tests"]]
    code, out = run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "--tb=short", *files])
    if code == 0:
        return []
    lines = out.splitlines()
    failed = [line for line in lines if line.startswith(("FAILED", "ERROR"))]
    detail = []
    for line in lines:
        if line.startswith("E ") or line.startswith("tests/") and ":" in line:
            detail.append(line)
    return failed + ["--- first error lines ---"] + detail[:15] if failed else lines[-MAX_LINES:]


# ---------------------------------------------------------------- driver
def full(task: str) -> int:
    tasks = tasks_up_to(task)
    gates = [
        ("1 protected files unchanged", gate_protected),
        ("2 modules exist", lambda: gate_modules(tasks)),
        ("3 no NotImplementedError left", lambda: gate_no_stubs(tasks)),
        ("4 signatures match contracts", lambda: gate_contracts(tasks)),
        ("5 no forbidden patterns", gate_forbidden),
        ("6 ruff lint", gate_ruff),
        ("7 mypy types", gate_mypy),
        (f"8 tests {tasks[0]}..{tasks[-1]}", lambda: gate_tests(tasks)),
    ]
    report = [f"VERIFY {task}  ({TASKS[task]['title']})", ""]
    failed = []
    for name, fn in gates:
        problems = fn()
        report.append(f"GATE {name}: {'PASS' if not problems else 'FAIL'}")
        if problems:
            failed.append(name.split()[0])
            report += ["    " + p for p in clip(problems)]
    report.append("")
    verdict = "PASS" if not failed else "FAIL"
    report.append(f"RESULT: {task} {verdict}" + (f" (failed gates: {', '.join(failed)})" if failed else ""))
    if failed:
        report.append(f"Fix the FIRST failing gate first. Task card: docs/tasks/{task}.md")
    manifest = VERIFY / "protected.sha256"
    if manifest.exists():
        report.append(f"kit fingerprint: {hashlib.sha256(manifest.read_bytes()).hexdigest()[:16]}")
    text = "\n".join(report)
    print(text)
    (VERIFY / "last_report.txt").write_text(text + "\n")
    progress = ROOT / "docs" / "PROGRESS.md"
    stamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    with progress.open("a", encoding="utf-8") as fh:
        fh.write(f"| {stamp} | {task} | {verdict} | {', '.join(failed) or '-'} |\n")
    return 0 if not failed else 1


def status() -> int:
    nxt = None
    for t in ORDER:
        code, _ = run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", *TASKS[t]["tests"]])
        stubs = gate_no_stubs([t])
        ok = code == 0 and not stubs
        print(f"{t}  {'PASS' if ok else 'TODO'}  {TASKS[t]['title']}")
        if not ok and nxt is None:
            nxt = t
    print("")
    print(f"Next task: {nxt} -> docs/tasks/{nxt}.md" if nxt else "All tasks pass their tests. Run --all for the full gate.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--task")
    group.add_argument("--status", action="store_true")
    group.add_argument("--all", action="store_true")
    args = ap.parse_args()
    if args.status:
        return status()
    return full(ORDER[-1] if args.all else args.task.upper())


if __name__ == "__main__":
    sys.exit(main())
