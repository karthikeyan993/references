# SRE harness: build kit for a coding agent

This repository is a **starter kit** for building the self-healing SRE harness
with a small coding model (GPT-6 Luna through opencode with a GitHub Copilot
login). The kit is designed so the model does as little thinking as possible
and can't quietly drift from the plan:

- **Every function already exists** as a stub with its exact signature and a
  docstring that says precisely what it must do.
- **312 tests are written in advance.** They were run against a private
  reference implementation before this kit shipped, and all 8 gates passed.
  The target is known to be reachable.
- **A verifier gates every task.** It refuses the work if protected files
  changed, signatures drifted, stubs remain, forbidden patterns appear, lint or
  types fail, or any test of this or an earlier task fails.
- **A runner script** drives opencode one task at a time, re-checks the
  protected files against a git tag, and commits only verified work.

The design and the reasons behind it are in `docs/SPEC.md`. The task list is
in `docs/TASKS.md`.

## What is in the kit

```
AGENTS.md                 rules the coding agent follows (opencode reads this automatically)
opencode.json             builder permissions: may edit only src/sre_harness/*.py
docs/SPEC.md              the specification
docs/TASKS.md             19 tasks in order, each with a card in docs/tasks/
src/sre_harness/          models/ports/context provided; every other module is a stub
tests/                    pre-written tests + fakes + fixtures (offline, no cloud needed)
verify/verify.py          the 8-gate verifier
verify/contracts.json     required signatures, constants and dataclass fields
verify/protected.sha256   checksums of every file the agent must not touch
runtime/                  prompts, JSON schemas and opencode profiles the HARNESS uses at run time
config/                   example config you edit for your environment
scripts/                  run_task.sh, run_all.sh, rebaseline.sh, schedule examples
```

## The verification layer

`python verify/verify.py --task T07` runs these gates for tasks T01 to T07:

| Gate | Checks | Catches |
| --- | --- | --- |
| 1 protected files | sha256 of tests, verifier, spec, cards, runtime files, provided modules | Weakened tests, edited spec or verifier |
| 2 modules exist | every module of the tasks so far | Deleted or renamed files |
| 3 no stubs left | no `NotImplementedError` in those modules | Half-finished work |
| 4 contracts | parameter names, order, defaults; constants; dataclass fields | Renamed or reordered parameters |
| 5 forbidden patterns | AST scan: `shell=True`, `eval`, force push, `subprocess` outside runner, `gcloud` outside gcp.py, `print` outside cli.py, bare `except` | Unsafe shortcuts |
| 6 ruff | lint | Sloppy code, unused names |
| 7 mypy | types | Wrong types between modules |
| 8 tests | all tests of this AND every earlier task | Regressions |

On top of that, `scripts/run_task.sh` compares the protected files with the
git tag `kit-baseline` before and after each agent run, so even an edited
checksum file is caught. Each verifier run appends a row to `docs/PROGRESS.md`
and writes the full report to `verify/last_report.txt`, which the agent reads
on its next attempt.

Kit fingerprint (printed at the end of every verifier report): `51381994bc01f9c2`.
If the report prints a different value, `verify/protected.sha256` was changed.

## Build it

1. **Python environment** (3.11 or newer):
   ```
   python3 -m venv .venv && source .venv/bin/activate
   pip install -e ".[dev]"
   python verify/verify.py --task T01      # must print RESULT: T01 PASS
   ```
2. **Pin the baseline** so tampering is detectable:
   ```
   git init && git add -A && git commit -m "SRE harness kit" && git tag kit-baseline
   ```
3. **opencode with Copilot**: log in with GitHub Copilot in opencode, then run
   `opencode models` and note the exact GPT-6 Luna id. If it is not
   `github-copilot/gpt-6-luna`, `export SRE_BUILD_MODEL=<id>`.
4. **Run the tasks**, one at a time so you can review each commit:
   ```
   scripts/run_task.sh T02          # up to 3 attempts, commits only on PASS
   git show --stat HEAD             # review
   ```
   or all remaining tasks in a row: `scripts/run_all.sh`.
5. **When a task gets stuck**: read `verify/last_report.txt` and
   `docs/QUESTIONS.md`. Then either rerun with more attempts
   (`scripts/run_task.sh T14 6`), add a one-line hint to the prompt, or write
   the failing function yourself. T14 (playbooks) is the largest task; letting
   the agent do it one function at a time works best.
6. **Finish**: `python verify/verify.py --all` must print `RESULT: T19 PASS`.

If you decide a test is wrong, fix it yourself, then run
`scripts/rebaseline.sh` (human only) to regenerate the checksums and move the
tag.

## Configure it for real (after T19)

1. **Wiz columns**: open one real report, compare its header row with
   `DEFAULT_COLUMNS` in `src/sre_harness/config.py`, and set any differences
   under `wiz.columns` in `config/harness.yaml`. The parser reports missing
   columns by name, so a wrong mapping fails loudly.
2. **Bucket path**: set `wiz.report_uri_template` to where Wiz publishes
   (`{date}` becomes `YYYY-MM-DD`).
3. **Chat**: create an incoming webhook in the Chat space and
   `export SRE_CHAT_WEBHOOK=<url>` (never commit the URL).
4. **Read-only identity** (recommended): a service account with viewer roles
   for Monitoring, Logging, the Wiz bucket, Cloud Run, Artifact Registry and
   service account key listing; set `gcp.impersonate_service_account`.
5. **Services**: fill `config/services.yaml` (your manual mapping).
6. **SLO alert labels**: make your SLO implement skill add user labels
   `service` and `slo` to every alert policy it creates.
7. **Check**: `python -m sre_harness preflight` must print `preflight ok`.
8. **First run by hand**: set `agent.enabled: false` and
   `limits.max_prs_per_day: 1`, run `python -m sre_harness wiz-run`, read the
   cards in Chat, then turn the agent back on.
9. **Schedule**: `scripts/crontab.example` or
   `scripts/com.sre-harness.wiz.plist` (macOS). If no DAILY SUMMARY card
   appears by 10:30, the laptop run did not happen.

Emergency stop: `touch STOP` in the repo root. Every command exits without
doing anything until you delete it.
