# Rules for the coding agent

You are implementing the SRE harness one task at a time. Follow these rules
exactly. They exist because a verifier checks your work and rejects anything
outside them.

## The loop (do this every time)

1. Run `python verify/verify.py --status`. It prints the next task, for example `Next task: T05`.
   If you were given a task id, use that one.
2. Read the task card `docs/tasks/TXX.md` completely.
3. Open the module(s) the card lists. Read every docstring in them. The
   docstrings are the specification; follow them word for word.
4. Read the test file the card lists. The tests show the exact expected values.
5. Implement the functions. Replace each `raise NotImplementedError(...)` line
   with working code. Keep every function name, parameter name, parameter
   order and default value exactly as written.
6. Run `python verify/verify.py --task TXX`.
7. If it prints `RESULT: TXX FAIL`, fix the FIRST failing gate, then run it again.
8. Stop when it prints `RESULT: TXX PASS`. Do not start the next task unless asked.

## What you may change

- ONLY the module files listed in the task card (in `src/sre_harness/`).
- You may add private helper functions (names starting with `_`) inside those modules.
- You may append to `docs/QUESTIONS.md` and `docs/PROGRESS.md`.

## What you must never do

- Never edit: `tests/`, `verify/`, `docs/SPEC.md`, `docs/TASKS.md`, `docs/tasks/`,
  `runtime/`, `scripts/`, `AGENTS.md`, `opencode.json`, `pyproject.toml`,
  `src/sre_harness/models.py`, `ports.py`, `context.py`, `__init__.py`, `__main__.py`.
  The verifier detects any change to these files and fails.
- Never change a test to make it pass. Never skip, delete or weaken a test.
- Never rename a function, parameter, class, constant or dataclass field.
- Never add a dependency. Only the Python standard library, `PyYAML` and `jsonschema` are available.
- Never use `shell=True`, `os.system`, `eval` or `exec`.
- Never import `subprocess` or `urllib.request` outside `runner.py`.
- Never build a `gcloud` command outside `gcp.py`, a `gh` command outside
  `gitops.py`/`cli.py`, a `git` command outside `gitops.py`/`agent.py`/`cli.py`,
  or a `docker` command outside `playbooks.py`/`cli.py`.
- Never use `print()` outside `cli.py`.
- Never use a bare `except:`. Catch the specific exceptions the docstring names.
  `except Exception` is allowed only where the docstring says one failure must not stop the run.
- Never run `git commit`, `git push`, `git checkout`, `git reset` or `rm -rf`.
  The human's script commits after the verifier passes.

## How to write the code

- Copy exact strings from the docstrings and tests (messages, card text, keys, command arguments).
  The tests compare them character for character.
- Work through the docstring's numbered steps in order. Each step usually becomes a few lines.
- Call the other modules exactly as the docstring says (for example `gcp.list_objects(...)`,
  `gitops.ensure_clone(...)`). Earlier tasks already implemented them.
- External programs are ALWAYS run through the `runner` argument (a `CommandRunner`), never directly.
- Keep functions small. Prefer plain loops and `if` statements over clever code.
- After editing, run `ruff check src` and `mypy` yourself if gate 6 or 7 fails.

## When you are stuck

After 3 failed attempts at the same gate, stop and append to `docs/QUESTIONS.md`:

```
## TXX: <short title>
- Gate that fails: <number and name>
- Exact error: <copy the lines from verify/last_report.txt>
- What I tried: <one line per attempt>
- What I think is wrong: <one line>
```

Then stop. Do not change protected files to get unstuck.
