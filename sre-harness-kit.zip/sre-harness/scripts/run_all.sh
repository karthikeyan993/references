#!/usr/bin/env bash
# Run every remaining task in order, stopping at the first one that does not pass.
# Usage: scripts/run_all.sh [max_attempts_per_task]
set -uo pipefail
cd "$(dirname "$0")/.." || exit 2
MAX="${1:-3}"
for TASK in $(python -c "import json;print(' '.join(sorted(json.load(open('verify/tasks.json')))))"); do
  if python verify/verify.py --task "$TASK" >/dev/null 2>&1; then
    echo "$TASK already passes"
    continue
  fi
  scripts/run_task.sh "$TASK" "$MAX" || { echo "Stopped at $TASK."; exit 1; }
done
python verify/verify.py --all
