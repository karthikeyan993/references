#!/usr/bin/env bash
# Run the coding agent on ONE task until the verifier passes, then commit.
# Usage: scripts/run_task.sh T05 [max_attempts]
# Env:   SRE_BUILD_MODEL (default github-copilot/gpt-6-luna)
set -uo pipefail
TASK="${1:?usage: scripts/run_task.sh TXX [max_attempts]}"
MAX="${2:-3}"
MODEL="${SRE_BUILD_MODEL:-github-copilot/gpt-6-luna}"
cd "$(dirname "$0")/.." || exit 2

git rev-parse -q --verify kit-baseline >/dev/null || { echo "Tag kit-baseline is missing. See README, step 2."; exit 2; }
PROTECTED=$(cut -d' ' -f3- verify/protected.sha256)

check_protected() {
  # shellcheck disable=SC2086
  if ! git diff --quiet kit-baseline -- $PROTECTED verify/protected.sha256; then
    echo "STOP: protected files differ from kit-baseline:"
    # shellcheck disable=SC2086
    git diff --stat kit-baseline -- $PROTECTED verify/protected.sha256
    echo "Restore them with: git checkout kit-baseline -- <file>"
    exit 2
  fi
}

check_protected
for attempt in $(seq 1 "$MAX"); do
  echo "=== $TASK attempt $attempt/$MAX ==="
  if [ "$attempt" -eq 1 ]; then
    PROMPT="Implement task $TASK. Follow AGENTS.md exactly. Start by reading docs/tasks/$TASK.md, then the docstrings and the tests it lists. Finish by running: python verify/verify.py --task $TASK"
  else
    PROMPT="Task $TASK is not done yet. Read verify/last_report.txt, fix the FIRST failing gate, then run: python verify/verify.py --task $TASK. Follow AGENTS.md exactly."
  fi
  opencode run --model "$MODEL" --agent build "$PROMPT" || echo "(opencode exited non-zero; verifying anyway)"
  check_protected
  if python verify/verify.py --task "$TASK"; then
    git add src/sre_harness docs/PROGRESS.md docs/QUESTIONS.md
    git commit -q -m "$TASK: verified" && echo "$TASK passed and was committed."
    exit 0
  fi
done
echo "$TASK still fails after $MAX attempts. Read verify/last_report.txt and docs/QUESTIONS.md."
exit 1
