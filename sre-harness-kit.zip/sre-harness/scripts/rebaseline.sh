#!/usr/bin/env bash
# HUMAN ONLY. After you deliberately change a protected file (for example a test you
# decided was wrong), regenerate the manifest and move the kit-baseline tag.
set -euo pipefail
cd "$(dirname "$0")/.."
python - <<'PY'
import hashlib
from pathlib import Path
patterns = ["AGENTS.md", "opencode.json", "pyproject.toml", "docs/SPEC.md", "docs/TASKS.md", "docs/tasks/*.md",
            "tests/*.py", "tests/fixtures/*", "verify/verify.py", "verify/contracts.json", "verify/tasks.json",
            "runtime/prompts/*", "runtime/schemas/*", "runtime/opencode/agents/*", "scripts/*",
            "src/sre_harness/models.py", "src/sre_harness/ports.py", "src/sre_harness/context.py",
            "src/sre_harness/__init__.py", "src/sre_harness/__main__.py"]
root = Path(".")
files = sorted({p for pat in patterns for p in root.glob(pat) if p.is_file()})
lines = [f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.as_posix()}" for p in files]
Path("verify/protected.sha256").write_text("\n".join(lines) + "\n")
print("manifest:", len(lines), "files")
PY
git add -A verify/protected.sha256 && git commit -q -m "rebaseline protected files" || true
git tag -f kit-baseline
echo "kit-baseline now points at $(git rev-parse --short HEAD)"
