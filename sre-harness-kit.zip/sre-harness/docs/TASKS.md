# Tasks

Implement the tasks in order. Each task has a card in `docs/tasks/`, a test
file, and a gate: `python verify/verify.py --task TXX`. A task is done only
when that command prints `RESULT: TXX PASS`. Every gate run re-checks all
earlier tasks, so breaking an earlier module fails the current task.

| Task | What | Module(s) | Tests |
| --- | --- | --- | --- |
| [T01](tasks/T01.md) | Set up the environment and confirm the provided code passes | - | `test_t01_models.py` |
| [T02](tasks/T02.md) | Load and validate the three config files | `config.py` | `test_t02_config.py` |
| [T03](tasks/T03.md) | SQLite state store | `state.py` | `test_t03_state.py` |
| [T04](tasks/T04.md) | Command runner, HTTP client and read-only gcloud | `runner.py`, `gcp.py` | `test_t04_gcp_runner.py` |
| [T05](tasks/T05.md) | Find and parse the daily Wiz report | `wiz.py` | `test_t05_wiz.py` |
| [T06](tasks/T06.md) | Map findings to services | `mapping.py` | `test_t06_mapping.py` |
| [T07](tasks/T07.md) | Classify findings with rules | `rules.py` | `test_t07_rules.py` |
| [T08](tasks/T08.md) | Group findings into work items | `grouping.py` | `test_t08_grouping.py` |
| [T09](tasks/T09.md) | Version comparison and lockfile lookups | `versions.py` | `test_t09_versions.py` |
| [T10](tasks/T10.md) | Stale-image reconciliation | `reconcile.py` | `test_t10_reconcile.py` |
| [T11](tasks/T11.md) | Google Chat messages and delivery | `chat.py` | `test_t11_chat.py` |
| [T12](tasks/T12.md) | Run opencode agents safely | `agent.py` | `test_t12_agent.py` |
| [T13](tasks/T13.md) | Git and GitHub operations | `gitops.py` | `test_t13_gitops.py` |
| [T14](tasks/T14.md) | Playbooks: fixes and recommendations | `playbooks.py` | `test_t14_playbooks.py` |
| [T15](tasks/T15.md) | The daily Wiz run end to end | `pipeline.py` | `test_t15_pipeline.py` |
| [T16](tasks/T16.md) | Ops wiki incident pages | `wiki.py` | `test_t16_wiki.py` |
| [T17](tasks/T17.md) | Pure SLO helpers | `slo_parse.py` | `test_t17_slo_parse.py` |
| [T18](tasks/T18.md) | SLO polling, evidence and root-cause notes | `slo.py` | `test_t18_slo.py` |
| [T19](tasks/T19.md) | Command line, preflight and the STOP file | `cli.py` | `test_t19_cli.py` |

Milestones:
- After **T15** the daily Wiz run works end to end (with fakes in tests; for real after T19).
- After **T18** the SLO root-cause path works.
- After **T19** run `python verify/verify.py --all`, then follow README.md to configure and schedule it.
