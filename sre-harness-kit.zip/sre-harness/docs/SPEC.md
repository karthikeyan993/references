# SRE harness: technical specification

Version 1.0 · 2026-11-19 · PROTECTED FILE (coding agents must not edit it)

This spec says **what** the harness does and **why**. The exact behaviour of
every function is in its docstring in `src/sre_harness/`, and the tests in
`tests/` pin it down. When this spec, a docstring and a test disagree, the
**test wins**, then the docstring, then this spec. Report the disagreement in
`docs/QUESTIONS.md`.

---

## 1. Purpose and scope

A Python program that runs on one laptop and does two jobs:

1. **Daily Wiz run (09:30).** Read the Wiz report that Wiz publishes to a GCS
   bucket at 09:00, decide what to do with each finding, open a pull request
   when a safe automated fix exists, otherwise post a recommendation. Every
   outcome goes to one Google Chat space.
2. **SLO poll (every 5 minutes, 09:00 to 17:00).** Find newly opened SLO alerts
   in Cloud Monitoring, collect evidence, ask a read-only AI agent to rank
   likely causes, post a root-cause note to Chat and write a wiki page. When
   the alert closes, post a resolved note.

Out of scope: changing any cloud resource, deploying, merging PRs, paging.

## 2. Constraints and design rules

| Constraint | Rule in the code |
| --- | --- |
| Runs on a laptop, 09:00 to 17:00 | Every stage is idempotent. State lives in SQLite. A missed run is caught up by the next one. |
| Only model: GPT-6 Luna through opencode with a GitHub Copilot login | The model never decides control flow. It is called for 4 narrow jobs, gets collected evidence, must write a JSON file that matches a schema, and its file edits are checked afterwards. |
| Fewest GCP services | Only Cloud Storage, Cloud Monitoring, Cloud Logging and read-only Cloud Run/IAM/registry calls, all through the `gcloud` CLI. No Pub/Sub, BigQuery or Cloud Functions. |
| Never change cloud state | `gcp.run_gcloud` refuses any command not on `ALLOWED_GCLOUD`. Cloud changes appear only as text in recommendations. |
| Deterministic and controllable | Every decision that can be a rule is a rule in `config/rules.yaml` or plain code. |
| Everything goes to Chat | Each work item gets exactly one outcome per run. Each failure posts a HARNESS ERROR card. Each run ends with a DAILY SUMMARY card. |

### Where AI is used (and nowhere else)

| Job | Agent profile | Can edit code? | Output schema |
| --- | --- | --- | --- |
| Fix build or test breakage after a scripted dependency upgrade | `fixer` | Yes, source and manifest files only | `fix_result` |
| Review routes for missing auth when a service is public by design | `reviewer` | No | `review_auth` |
| Find where a service account key is loaded | `reviewer` | No | `key_usage` |
| Suggest a Terraform change for a config finding | `reviewer` | No | `iac_suggestion` |
| Rank SLO root causes from an evidence file | `rca` | No | `rca_result` |

## 3. Architecture and the daily run

```
GCS (Wiz CSV) ──┐
Monitoring ─────┼──> laptop: cli.py ──> pipeline.py / slo.py ──> playbooks.py ──> gitops.py ──> GitHub PR
Logging ────────┤          │                 │                      │
Cloud Run (ro) ─┘          │                 └── agent.py (opencode, sandboxed)
                           └── state.py (SQLite) · chat.py (webhook) · wiki.py (markdown)
```

Module map (one module per task; see docs/TASKS.md):

| Module | Responsibility |
| --- | --- |
| `models.py` (provided) | All shared dataclasses and enums |
| `ports.py` (provided) | Protocols for the outside world: CommandRunner, HttpClient, Clock, AgentPort |
| `context.py` (provided) | `Context`, the one object every stage receives |
| `config.py` | Load and validate `config/*.yaml` |
| `state.py` | SQLite store |
| `wiz.py` | Find, read, parse the Wiz report |
| `mapping.py` | Finding to service |
| `rules.py` | Finding to class |
| `grouping.py` | Findings to work items |
| `versions.py` | Version ordering, lockfile lookups |
| `runner.py` | Real subprocess runner and HTTP client |
| `gcp.py` | Read-only gcloud calls |
| `reconcile.py` | Stale-image decision |
| `chat.py` | Chat message text and delivery with an outbox |
| `agent.py` | Run opencode safely |
| `gitops.py` | Clone, worktree, commit, push, PR |
| `playbooks.py` | What to do with one work item |
| `pipeline.py` | The daily Wiz run |
| `wiki.py` | Incident pages |
| `slo_parse.py` | Pure SLO helpers |
| `slo.py` | SLO poll, evidence, root-cause notes |
| `cli.py` | Entry points, preflight, STOP file |

### 3.1 Daily Wiz run stages (`pipeline.run_wiz`)

1. Start a run row; bind the agent to the run; flush the Chat outbox.
2. Find today's report (`wiz.find_report`). Missing: HARNESS ERROR card, run failed, stop.
3. Read and parse it. Parse error: HARNESS ERROR card naming the missing columns, run failed, stop.
4. Map and classify every finding; record it; mark findings missing from today's report as resolved.
5. Group into work items. For each item:
   unchanged since last run → no card; else reconcile → playbook → record → card.
   An exception inside one item becomes an ERROR card for that item; the run continues.
6. Send the DAILY SUMMARY card. Finish the run.

Card budget: at most `limits.max_cards_per_run` result cards per run; the
rest are counted as `cards_grouped` in the summary. DEFERRED and UNCHANGED
outcomes never get their own card.

## 4. The Wiz report

The report is a CSV file under `wiz.report_uri_template` (for example
`gs://bucket/daily/{date}/`). The harness lists that prefix for the day and
takes the last object ending in `wiz.report_suffix`.

Column names differ between Wiz report types, so the parser maps **logical
fields** to **candidate column names** (`config.DEFAULT_COLUMNS`, overridable
per field in `harness.yaml` under `wiz.columns`). Required logical fields:
`title`, `resource_name`. A row is a VULNERABILITY when it has a package
(`DetailedName`), otherwise an ISSUE (a control or configuration finding).

Fingerprint: `wiz:<Wiz ID>` when the report has an ID column, otherwise a
hash of kind, resource, title and package (`wiz.fingerprint`).

## 5. Config files

All three live in `config/`. They are edited by people, validated strictly,
and every error names the file and key path.

### 5.1 `harness.yaml`

```yaml
chat:   {webhook_url_env: SRE_CHAT_WEBHOOK}      # the URL itself stays in the environment
wiz:    {report_uri_template: "gs://bucket/daily/{date}/", report_suffix: ".csv", columns: {}}
gcp:    {impersonate_service_account: "", slo_projects: [prod-project]}
slo:    {logs_lookback_minutes: 120, revision_lookback_hours: 24}
agent:  {enabled: true, binary: opencode, model: github-copilot/gpt-6-luna, timeout_seconds: 900, max_calls_per_day: 40}
limits: {max_prs_per_day: 5, max_cards_per_run: 30, max_changed_lines: 300}
paths:  {workdir: ~/.sre-harness/work, state_db: state/harness.db, wiki_dir: wiki, stop_file: STOP}
docker: {enabled: true}
```

### 5.2 `services.yaml` (the manual service-to-repo mapping)

One entry per service. `images` are repository paths without tag or digest.
Mapping order (`mapping.map_finding`): image, then Cloud Run name and project,
then service accounts, then extra resource names. Zero matches is `unmapped`;
two or more is `unmapped` with reason `ambiguous`.

`ecosystem` selects the scripted upgrade: `npm`, `pip` (requirements*.txt),
`poetry`, `uv`, `go`, or `maven`/`generic` (no scripted upgrade, recommendation only).
`public_endpoints` declares paths that are public on purpose.

### 5.3 `rules.yaml`

An ordered list; the first matching rule decides the class. A rule tests
finding fields with equality or one operator (`in`, `regex`, `empty`,
`present`). The last rule must be the catch-all (`when: {}`, class
`unclassified`), so no finding is ever dropped.

## 6. Classes and work items

| Class | Typical source | Work item key | Opens a PR? |
| --- | --- | --- | --- |
| `app_dependency` | Library CVE with a fixed version | `app_dependency:{service}:{package}` | Yes |
| `base_image_os` | OS package CVE in an image | `base_image_os:{service}` | Yes, digest bump only |
| `no_fix_available` | CVE without fixed version | `no_fix_available:{service}:{package}:{title}` | No |
| `unauth_endpoint` | Public or unauthenticated endpoint control | `unauth_endpoint:{service}:{resource_id}` | No |
| `sa_key` | Service account key control | `sa_key:{service}:{resource_id}` | No |
| `iac_config` | Any other control on a mapped resource | `iac_config:{service}:{resource_id}` | No |
| `unmapped` | No service owns the resource | `unmapped:{resource_id}` | No |
| `unclassified` | No rule matched | `unclassified:{fingerprint}` | No |

All CVEs on the same package in the same service become ONE work item and
ONE PR; the target version is the highest of the per-finding targets
(`versions.target_for_findings`). Change detection uses `WorkItem.signature`:
an item whose signature and terminal outcome match the stored row is
UNCHANGED and gets no card.

## 7. Reconciliation and playbooks

### 7.1 Why reconcile first

Upgrading a package in the repo does not clear a Wiz finding on an older
image. Before any fix, `reconcile.decide` answers three questions with code:

1. Is any affected image running? (Cloud Run revisions serving traffic.) No → **CLEANUP**:
   recommend an Artifact Registry cleanup policy. Unknown counts as running.
2. For `app_dependency`: is the package already fixed at HEAD of the default
   branch? Yes → **REDEPLOY**: the fix is merged but not deployed.
3. Otherwise → **FIX**.

### 7.2 `app_dependency` playbook

Scripted upgrade (`playbooks.upgrade_command` or `edit_requirements`) →
build and test → on failure ONE fixer-agent attempt → build and test again →
lockfile version check → diff checks (non-empty, no forbidden files,
`max_changed_lines`) → commit, push `sre-bot/...` branch, open PR. Daily PR
cap reached → DEFERRED (no card, retried next run). An open PR for the same
branch is reused.

### 7.3 `base_image_os` playbook

Needs Docker. Reads the final `FROM`. Digest-pinned base: resolve the newest
digest of the same tag and rewrite the `FROM`. Build with `--pull`, query the
package versions inside the image, compare with the fixed versions (dpkg
ordering). All fixed and Dockerfile changed → PR. All fixed and nothing
changed → REDEPLOY (a rebuild is enough). Anything still vulnerable →
RECOMMENDATION listing what remains.

### 7.4 Recommendation playbook

Everything else ends in a card a person acts on: NO FIX YET, ADD MAPPING,
ADD RULE, or RECOMMENDATION with exact commands or a suggested diff.
Public Cloud Run services with declared `public_endpoints` get a reviewer
check; if no undeclared route lacks auth the outcome is ACCEPTED.

### 7.5 Version ordering

OS packages (`deb`, `apk`, `rpm`) use dpkg ordering; everything else uses a
semver-like ordering that handles pre-releases and `v` prefixes. See
`versions.compare_versions` for the exact rules.

## 8. GCP access

All through `gcloud`, all read-only, all through `gcp.run_gcloud`, which:
refuses commands not on `ALLOWED_GCLOUD`, appends
`--impersonate-service-account=...` last when configured, and raises
`GcpError` on non-zero exit. Recommended setup: a dedicated read-only service
account with viewer roles for Monitoring, Logging, the Wiz bucket, Cloud Run,
Artifact Registry and service account key listing, used through
impersonation.

Listing open alerts uses `gcloud alpha monitoring alerts list`, which is in
preview at the time of writing. If that command changes, only
`gcp.list_alerts` needs updating.

## 9. State (SQLite)

Tables: `runs`, `findings`, `work_items`, `actions`, `outbox`, `slo_alerts`
(see `state.SCHEMA`). Action kinds: `playbook` (one per work item per run),
`agent_call` (counts toward the daily agent cap), `pr` (counts toward the
daily PR cap), `card`.

## 10. Google Chat

One space, one incoming webhook. Messages are plain text with a fixed first
line `*[TAG]* service · headline` so people can scan the space. Threads:
`wiz-<12 hex>` per work item, `slo-<alert>` per alert, `harness-<day>` for
errors, `daily-<day>` for summaries. The webhook URL gets
`messageReplyOption=REPLY_MESSAGE_FALLBACK_TO_NEW_THREAD` so the first message
opens a thread and later ones reply. A failed post goes to the SQLite outbox
and is re-sent at the start of the next run.

Tags: PR OPENED, RECOMMENDATION, REDEPLOY NEEDED, CLEANUP RECOMMENDED,
ACCEPTED, NO FIX YET, FIX FAILED, ADD MAPPING, ADD RULE, HARNESS ERROR,
DAILY SUMMARY, SLO ROOT CAUSE, SLO RESOLVED.

## 11. Running the AI agent (`agent.OpencodeAgent`)

Command: `opencode run --model <model> --agent <fixer|reviewer|rca> --format json [--file ...] "<prompt>"`,
run inside the work directory with a timeout. Never
`--dangerously-skip-permissions`.

Safety, in order: daily call cap → prompt from `runtime/prompts/` →
agent profiles from `runtime/opencode/agents/` copied into the work directory
→ run → result file `.sre/result.json` must exist, parse and match
`runtime/schemas/<name>.schema.json` → in a git work tree, every changed file
must match the task's allowed globs. Any failure raises `AgentError`, whose
message ends up in the Chat card. Every call is recorded in `actions`.

Because headless opencode may not enforce interactive permission prompts,
the harness never relies on them: profiles use explicit allow and deny, and
the post-run edit check is the real guard.

## 12. Git and GitHub

The laptop's existing `git` and `gh` logins are used. Clones live under
`<workdir>/repos/`, fix work trees under `<workdir>/worktrees/`, read-only
HEAD snapshots under `<workdir>/heads/`. Branches are always
`sre-bot/<slug>-<8 hex>`. The harness, never the agent, commits and pushes;
pushing any other branch or with force is refused.

## 13. SLO path and the wiki

### 13.1 Poll (`slo.run_slo_poll`)

For each project in `gcp.slo_projects`: list alerts, describe each policy once
(for its `userLabels`), parse. New OPEN alert → analyse. Stored open alert now
CLOSED → resolved note. Alert policies must carry user labels `service` and
`slo`; set them when your SLO implement skill creates the policy.

### 13.2 Evidence (`slo.collect_evidence`)

Numbered items `E1, E2, ...`: the alert itself; top error log signatures
(messages normalised by `slo_parse.normalize_message`, grouped and counted
in code, never raw logs); Cloud Run revisions created in the lookback window;
commits between the last revision before the window and the newest one (when
image tags are git SHAs); past incidents of the service whose wiki page has
an "Actual cause:" filled in.

### 13.3 Root-cause note

The `rca` agent reads the evidence file and the code (read-only) and returns
hypotheses that cite evidence ids. `slo_parse.validate_rca` drops any
hypothesis citing an id that does not exist and keeps at most 3. If none
survive, the note says "Insufficient evidence".

### 13.4 Wiki

`wiki/incidents/<date>-<service>-<alert>.md`, written once from a fixed
template and never overwritten (people edit it). A person fills in the
`Actual cause:` line after the incident; later analyses read it back.

## 14. Command line and scheduling

```
python -m sre_harness preflight   [--root DIR]
python -m sre_harness wiz-run     [--root DIR] [--day YYYY-MM-DD]
python -m sre_harness slo-poll    [--root DIR]
python -m sre_harness flush-outbox
```

Exit codes: 0 ok (also when `STOP` exists), 1 run failed, 2 preflight failed,
3 config error. Preflight checks gcloud auth, gh auth, git, the opencode
model, and Docker when enabled; problems are posted as one HARNESS ERROR card.

Schedule (examples in `scripts/`): `wiz-run` at 09:30 on weekdays,
`slo-poll` every 5 minutes from 09:00 to 17:00. If no DAILY SUMMARY appears
by 10:30, the laptop run did not happen.

## 15. Safety rules (all enforced by code and tests)

1. No gcloud command outside the allowlist; no cloud writes.
2. No shell (`shell=True`) anywhere; build and test commands from
   `services.yaml` run as `sh -c` because people wrote them.
3. Push only `sre-bot/...` branches, never with force; never to the default branch.
4. Agent edits checked against allowed globs after every run.
5. Daily caps on agent calls and PRs; `STOP` file disables all runs.
6. Logs and Wiz text are untrusted data: they reach the model only inside
   the evidence or prompt, the agents have no credentials and no web access.

## 16. Glossary

- **Finding**: one row of the Wiz report.
- **Work item**: findings handled together (one card, at most one PR).
- **Outcome**: what happened to a work item in one run (`models.Outcome`).
- **Terminal outcome**: an outcome after which an unchanged item stays quiet.
- **HEAD**: the latest commit of the service's default branch on GitHub.
