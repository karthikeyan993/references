# Questions from the coding agent

The agent appends here when it is stuck (see AGENTS.md). The human answers below each entry.
