"""Classify findings with config/rules.yaml (task T07, docs/SPEC.md section 6)."""

from __future__ import annotations

from typing import Any, Sequence

from .models import Finding, FindingClass, Rule


def field_value(finding: Finding, field_name: str) -> str | None:
    """The finding attribute as a string: enums give their .value, None stays None."""
    raise NotImplementedError("T07: implement field_value")


def condition_matches(value: str | None, cond: Any) -> bool:
    """Evaluate one rule condition against one field value.

    - scalar cond: value is not None and value.lower() == str(cond).lower()
      (bools compare as 'true'/'false').
    - {'in': [..]}: value is not None and value.lower() is in the lower-cased list.
    - {'regex': p}: value is not None and re.search(p, value) finds a match.
    - {'empty': True}: value is None or ''. {'empty': False}: the opposite.
    - {'present': True}: value is not None and value != ''. {'present': False}: the opposite.
    """
    raise NotImplementedError("T07: implement condition_matches")


def matches(rule: Rule, finding: Finding) -> bool:
    """True when every condition in rule.when matches (an empty 'when' always matches)."""
    raise NotImplementedError("T07: implement matches")


def classify(finding: Finding, rules: Sequence[Rule]) -> tuple[FindingClass, str]:
    """(class, rule name) of the first matching rule.

    If nothing matches (only possible with a broken rule list) return
    (FindingClass.UNCLASSIFIED, '<none>').
    """
    raise NotImplementedError("T07: implement classify")
