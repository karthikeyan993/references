"""Interfaces to the outside world.

PROVIDED FILE. Do not edit. Business logic depends only on these protocols,
so tests can swap in the fakes from tests/fakes.py. Real implementations live
in runner.py (CommandRunner, HttpClient) and agent.py (AgentPort).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Mapping, Protocol, Sequence

from .models import CommandResult


class CommandRunner(Protocol):
    """Runs one external command. Never uses a shell. Never raises on non-zero exit."""

    def run(
        self,
        args: Sequence[str],
        *,
        cwd: str | None = None,
        timeout: int = 300,
        env: Mapping[str, str] | None = None,
    ) -> CommandResult: ...


class HttpClient(Protocol):
    """Minimal HTTP client used for the Google Chat webhook."""

    def post_json(self, url: str, payload: Mapping[str, Any], timeout: int = 30) -> int:
        """POST JSON, return the HTTP status code. Return 0 on network error."""
        ...


class Clock(Protocol):
    def now(self) -> datetime:
        """Timezone-aware current time."""
        ...


class AgentPort(Protocol):
    """Runs one opencode agent task and returns its validated JSON result.

    Raises sre_harness.agent.AgentError on any failure (cap reached, timeout,
    missing or invalid result file, forbidden edits).
    """

    def run(self, task: Any) -> dict[str, Any]: ...


class SystemClock:
    def now(self) -> datetime:
        return datetime.now(UTC)
