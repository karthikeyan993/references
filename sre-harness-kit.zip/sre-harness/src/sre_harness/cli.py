"""Command line entry points (task T19, docs/SPEC.md section 14).

    python -m sre_harness preflight     [--root DIR]
    python -m sre_harness wiz-run       [--root DIR] [--day YYYY-MM-DD]
    python -m sre_harness slo-poll      [--root DIR]
    python -m sre_harness flush-outbox  [--root DIR]

Exit codes: 0 ok (also when the STOP file is present), 1 run failed,
2 preflight failed, 3 configuration error.
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Sequence

from .context import Context

COMMANDS: tuple[str, ...] = ("preflight", "wiz-run", "slo-poll", "flush-outbox")


def build_context(root: Path) -> Context:
    """Real Context for a harness checkout at root.

    Loads root/config/harness.yaml, services.yaml and rules.yaml. The webhook URL
    comes from the environment variable named by cfg.chat_webhook_env; when it is
    unset or empty raise ConfigError(f'environment variable {name} is not set').
    Wires Store(cfg.state_db), SubprocessRunner, SystemClock, ChatSender(UrllibHttp, ...),
    and OpencodeAgent(runtime_dir=root/'runtime', run_id=None, day=today's local date).
    """
    raise NotImplementedError("T19: implement build_context")


def preflight(ctx: Context) -> list[str]:
    """Problems that would make a run fail, in this order (empty list = ready):

    - gcp.run_gcloud(['auth', 'print-access-token']) raises GcpError -> f'gcloud auth: {exc}'
    - ['gh', 'auth', 'status'] non-zero -> f'gh auth: {stderr stripped or "not logged in"}'
    - ['git', '--version'] non-zero -> 'git: not installed'
    - cfg.agent_enabled: [cfg.agent_binary, 'models'] non-zero -> f'opencode: {stderr stripped}';
      else cfg.agent_model not among the whitespace-separated tokens of stdout ->
      f'opencode: model {model} not available; run `{binary} models` to list models'
    - cfg.docker_enabled: ['docker', 'version'] non-zero ->
      'docker: not available (set docker.enabled: false to skip image checks)'
    """
    raise NotImplementedError("T19: implement preflight")


def main(argv: Sequence[str] | None = None, context_factory: Callable[[Path], Context] = build_context) -> int:
    """Parse args, build the context, honour the STOP file, run preflight, run the command.

    1. argparse: positional command in COMMANDS; --root (default '.'); --day (YYYY-MM-DD,
       default ctx.day).
    2. ctx = context_factory(Path(root).resolve()); ConfigError -> print to stderr, return 3.
    3. ctx.cfg.stop_file exists -> print 'STOP file present; nothing done' and return 0.
    4. Commands preflight, wiz-run, slo-poll: problems = preflight(ctx). Non-empty ->
       ctx.chat.send(chat.render_error('preflight', '\\n'.join(problems), day)), print them, return 2.
    5. preflight -> print 'preflight ok', return 0.
       wiz-run -> pipeline.run_wiz(ctx, date.fromisoformat(day)); return 0 when status 'ok' else 1.
       slo-poll -> set ctx.day = day; ctx.chat.flush_outbox(); slo.run_slo_poll(ctx); return 0.
       flush-outbox -> print the number sent by ctx.chat.flush_outbox(); return 0.
    """
    raise NotImplementedError("T19: implement main")
