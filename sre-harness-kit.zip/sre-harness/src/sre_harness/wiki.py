"""Ops wiki pages for SLO incidents (task T16, docs/SPEC.md section 13).

Pages are plain markdown written from a fixed template. People fill in the
'Actual cause:' line afterwards; later analyses read it back as evidence.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence

from .models import EvidenceItem, SloAlert

ACTUAL_CAUSE_PREFIX = "Actual cause:"


def slug(text: str) -> str:
    """Lower-case, runs of characters outside [a-z0-9] become '-', stripped of '-'; '' -> 'unknown'."""
    raise NotImplementedError("T16: implement slug")


def incident_path(wiki_dir: Path, alert: SloAlert) -> Path:
    """wiki_dir/'incidents'/f'{open_time[:10]}-{slug(service or "unknown")}-{slug(last segment of alert_id)}.md'."""
    raise NotImplementedError("T16: implement incident_path")


def render_incident(
    alert: SloAlert,
    rca: Mapping[str, Any] | None,
    hypotheses: Sequence[Mapping[str, Any]],
    evidence: Sequence[EvidenceItem],
) -> str:
    """Markdown page. Exact template (each line ends with '\\n'):

    # Incident: {policy_display_name}
    <blank>
    - Service: {service or 'unknown'}
    - SLO: {slo or 'unknown'}
    - Opened: {open_time}
    - Closed: open
    - Alert: `{alert_id}`
    <blank>
    ## Harness analysis
    <blank>
    {rca['summary'] if rca and hypotheses else 'Insufficient evidence.'}
    <blank>
    then for each hypothesis i: '{i}. {cause} (confidence: {confidence}; evidence: {ids comma-joined})'
    <blank>   (only when there are hypotheses)
    ## Evidence
    <blank>
    one line per item: '- {id} ({kind}): {summary}'
    <blank>
    ## Actual cause
    <blank>
    <!-- Fill in after the incident. The next analysis for this service reads this line. -->
    Actual cause:
    """
    raise NotImplementedError("T16: implement render_incident")


def write_incident_page(
    wiki_dir: Path,
    alert: SloAlert,
    rca: Mapping[str, Any] | None,
    hypotheses: Sequence[Mapping[str, Any]],
    evidence: Sequence[EvidenceItem],
) -> Path:
    """Write render_incident(...) to incident_path(...) (creating folders); return the path.

    If the file already exists it is left untouched (people may have edited it).
    """
    raise NotImplementedError("T16: implement write_incident_page")


def mark_resolved(path: Path, close_time: str) -> bool:
    """Replace the line '- Closed: open' with f'- Closed: {close_time}'. True if replaced."""
    raise NotImplementedError("T16: implement mark_resolved")


def read_incident_history(wiki_dir: Path, service: str, limit: int = 5) -> list[dict[str, str]]:
    """Past incidents of `service` that have a filled-in actual cause.

    Scans wiki_dir/'incidents'/*.md in reverse file-name order. A page counts
    when its '- Service: X' line equals service and its 'Actual cause:' line has
    non-empty text after the prefix. Returns up to `limit` dicts
    {'file': file name, 'opened': value of the '- Opened: ' line, 'actual_cause': text}.
    """
    raise NotImplementedError("T16: implement read_incident_history")
