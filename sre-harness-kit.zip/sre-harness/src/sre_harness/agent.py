"""Run opencode agents safely (task T12, docs/SPEC.md section 11).

The model never decides what happens next. Each call is one task, in one
directory, with one agent profile, a timeout, and a JSON result file that is
validated against a schema. File edits are checked against an allowlist
AFTER the run, because opencode's own permission prompts cannot be relied on
in headless mode.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

from .config import HarnessConfig
from .ports import Clock, CommandRunner
from .state import Store

RESULT_PATH = ".sre/result.json"
AGENT_NAMES: tuple[str, ...] = ("fixer", "reviewer", "rca")
IGNORED_PREFIXES: tuple[str, ...] = (".sre/", ".opencode/")


class AgentError(Exception):
    """Any agent failure. The message is shown in the Chat card."""


@dataclass(frozen=True)
class AgentTask:
    agent: str
    prompt_name: str
    variables: Mapping[str, str]
    workdir: Path
    schema_name: str
    allowed_edit_globs: tuple[str, ...] = ()
    key: str | None = None
    attachments: tuple[str, ...] = field(default_factory=tuple)


def render_prompt(prompts_dir: Path, name: str, variables: Mapping[str, str]) -> str:
    """Read prompts_dir/'{name}.md' and substitute $variables with string.Template.substitute.

    A missing file or a missing variable raises AgentError naming it.
    """
    raise NotImplementedError("T12: implement render_prompt")


def build_command(cfg: HarnessConfig, task: AgentTask, prompt: str) -> list[str]:
    """[cfg.agent_binary, 'run', '--model', cfg.agent_model, '--agent', task.agent,
    '--format', 'json', *('--file', a for each attachment), prompt].

    Raises AgentError when task.agent is not in AGENT_NAMES. Never adds
    '--dangerously-skip-permissions'.
    """
    raise NotImplementedError("T12: implement build_command")


def install_profiles(profiles_dir: Path, workdir: Path) -> list[Path]:
    """Copy every profiles_dir/*.md into workdir/.opencode/agents/ (overwriting).

    Returns the destination paths sorted.
    """
    raise NotImplementedError("T12: implement install_profiles")


def load_schema(schemas_dir: Path, name: str) -> dict[str, Any]:
    """Parse schemas_dir/'{name}.schema.json'. Missing file -> AgentError."""
    raise NotImplementedError("T12: implement load_schema")


def validate_result(data: Any, schema: Mapping[str, Any]) -> list[str]:
    """All jsonschema (Draft 2020-12) errors as sorted strings '{path}: {message}'.

    path is the '/'-joined absolute path of the error ('' for the root). Empty list = valid.
    """
    raise NotImplementedError("T12: implement validate_result")


def changed_files(runner: CommandRunner, workdir: Path) -> list[str]:
    """Paths changed in the git work tree, relative to its root.

    Runs ['git', 'status', '--porcelain=v1', '--untracked-files=all'] in workdir.
    Each line is 'XY path' (path from column 4); for renames 'old -> new' use
    new; surrounding double quotes are removed. Paths starting with any
    IGNORED_PREFIXES are dropped. Returns sorted unique paths.
    Raises AgentError if git fails.
    """
    raise NotImplementedError("T12: implement changed_files")


def glob_match(path: str, pattern: str) -> bool:
    """fnmatch.fnmatch(path, pattern), plus: a pattern starting with '**/' also
    matches paths at the root (fnmatch(path, pattern[3:]))."""
    raise NotImplementedError("T12: implement glob_match")


def edit_violations(changed: Sequence[str], allowed_globs: Sequence[str]) -> list[str]:
    """Changed paths not allowed. No globs -> every changed path is a violation. Sorted."""
    raise NotImplementedError("T12: implement edit_violations")


class OpencodeAgent:
    """AgentPort implementation that shells out to `opencode run`."""

    def __init__(
        self,
        runner: CommandRunner,
        cfg: HarnessConfig,
        store: Store,
        clock: Clock,
        runtime_dir: Path,
        run_id: int | None,
        day: str,
    ) -> None:
        """Keep runner, cfg, store, clock, run_id, day as attributes and set
        self.prompts_dir = runtime_dir/'prompts', self.schemas_dir = runtime_dir/'schemas',
        self.profiles_dir = runtime_dir/'opencode'/'agents'."""
        raise NotImplementedError("T12: implement OpencodeAgent.__init__")

    def bind(self, run_id: int | None, day: str) -> None:
        """Set the run id and day used for the actions log and the daily cap."""
        raise NotImplementedError("T12: implement OpencodeAgent.bind")

    def run(self, task: AgentTask) -> dict[str, Any]:
        """Run one task end to end. Steps, in order (each failure raises AgentError):

        1. cfg.agent_enabled false -> 'agent disabled'.
        2. store.count_actions('agent_call', day) >= cfg.agent_max_calls_per_day
           -> 'daily agent call cap reached'.
        3. prompt = render_prompt(prompts_dir, task.prompt_name,
           {**task.variables, 'result_path': RESULT_PATH}).
        4. install_profiles(profiles_dir, workdir); delete an old result file;
           create workdir/.sre/.
        5. Run build_command(...) with cwd=workdir, timeout=cfg.agent_timeout_seconds.
        6. ALWAYS record_action(run_id, day, task.key, 'agent_call',
           outcome 'ok' if returncode == 0 else 'failed', model=cfg.agent_model,
           duration_s=elapsed seconds, detail={'agent': task.agent, 'returncode': rc}).
        7. returncode 124 -> 'agent timed out'; other non-zero ->
           f'agent exited {rc}: ' + last 500 chars of stderr.
        8. Result file missing -> 'agent wrote no result file'; not JSON ->
           'result file is not valid JSON'.
        9. validate_result against load_schema(schemas_dir, task.schema_name);
           errors -> 'result does not match schema: ' + '; '.join(errors).
        10. Only when workdir/.git exists (a file or a folder): edit_violations(changed_files(...),
            task.allowed_edit_globs) non-empty -> 'agent edited files it may not touch: ' + ', '.join(violations).
        11. Return the parsed result dict.
        """
        raise NotImplementedError("T12: implement OpencodeAgent.run")
