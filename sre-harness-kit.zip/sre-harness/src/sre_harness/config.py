"""Load and validate the three config files (task T02, docs/SPEC.md section 5).

Every validation failure raises ConfigError with a message that names the
file and the exact key path, for example "services.yaml: checkout.runtime.kind".
Unknown keys are errors, so typos never pass silently.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .models import Rule, Service


class ConfigError(Exception):
    """Raised for any invalid or missing configuration."""


#: Logical Wiz fields -> candidate CSV column names, first present column wins.
#: These are best guesses; config/harness.yaml wiz.columns overrides per field.
DEFAULT_COLUMNS: dict[str, tuple[str, ...]] = {
    "wiz_id": ("ID", "Id", "Finding ID"),
    "title": ("Name", "Title"),
    "severity": ("Severity", "VendorSeverity", "CVSSSeverity"),
    "resource_name": ("Resource Name", "ResourceName", "Asset Name"),
    "resource_type": ("Resource Type", "ResourceType", "Asset Type"),
    "resource_id": ("Resource External ID", "ResourceExternalId", "Resource ID"),
    "project": ("Project ID", "SubscriptionExternalId", "Project"),
    "package": ("DetailedName", "Package"),
    "version": ("Version",),
    "fixed_version": ("FixedVersion", "Fixed Version"),
    "package_type": ("PackageType", "Package Type", "DetectionMethod"),
    "image": ("Image", "ImageName", "Container Image"),
    "remediation": ("Remediation", "Recommendation"),
}

#: Logical fields that must resolve to a column, or the report is rejected.
REQUIRED_COLUMNS: tuple[str, ...] = ("title", "resource_name")

#: Allowed values of services.yaml <service>.ecosystem.
ECOSYSTEMS: frozenset[str] = frozenset({"npm", "pip", "poetry", "uv", "go", "maven", "generic"})

#: Finding fields a rule may test.
RULE_FIELDS: frozenset[str] = frozenset(
    {
        "kind",
        "title",
        "severity",
        "resource_name",
        "resource_type",
        "resource_id",
        "project",
        "package",
        "version",
        "fixed_version",
        "package_type",
        "image",
        "remediation",
    }
)

#: Operators a rule condition may use.
RULE_OPERATORS: frozenset[str] = frozenset({"in", "regex", "empty", "present"})

_REPO_RE = re.compile(r"^github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")

_SECTIONS: dict[str, frozenset[str]] = {
    "chat": frozenset({"webhook_url_env"}),
    "wiz": frozenset({"report_uri_template", "report_suffix", "columns"}),
    "gcp": frozenset({"impersonate_service_account", "slo_projects"}),
    "slo": frozenset({"logs_lookback_minutes", "revision_lookback_hours"}),
    "agent": frozenset({"enabled", "binary", "model", "timeout_seconds", "max_calls_per_day"}),
    "limits": frozenset({"max_prs_per_day", "max_cards_per_run", "max_changed_lines"}),
    "paths": frozenset({"workdir", "state_db", "wiki_dir", "stop_file"}),
    "docker": frozenset({"enabled"}),
}

_SERVICE_KEYS = frozenset(
    {
        "repo",
        "branch",
        "build",
        "test",
        "runtime",
        "ecosystem",
        "images",
        "dockerfile",
        "terraform_dir",
        "service_accounts",
        "resources",
        "public_endpoints",
        "slos",
        "owners",
    }
)
_RUNTIME_KEYS = frozenset({"kind", "project", "name", "region"})


@dataclass(frozen=True)
class HarnessConfig:
    """Validated contents of config/harness.yaml. Paths are absolute."""

    root: Path
    chat_webhook_env: str
    wiz_report_uri_template: str
    wiz_report_suffix: str
    wiz_columns: Mapping[str, tuple[str, ...]]
    gcp_impersonate: str | None
    slo_projects: tuple[str, ...]
    slo_logs_lookback_minutes: int
    slo_revision_lookback_hours: int
    agent_enabled: bool
    agent_binary: str
    agent_model: str
    agent_timeout_seconds: int
    agent_max_calls_per_day: int
    max_prs_per_day: int
    max_cards_per_run: int
    max_changed_lines: int
    workdir: Path
    state_db: Path
    wiki_dir: Path
    stop_file: Path
    docker_enabled: bool


def load_harness_config(path: str | Path) -> HarnessConfig:
    """Load config/harness.yaml and return a HarnessConfig.

    Rules (each violation raises ConfigError naming 'harness.yaml: <keypath>'):
    - Top-level keys must be a subset of: chat, wiz, gcp, slo, agent, limits,
      paths, docker. Keys inside each section must be from the documented set
      (see _SECTIONS). Unknown key -> error naming 'section.key'.
    - Required: chat.webhook_url_env, wiz.report_uri_template, agent.model.
    - wiz.report_uri_template must start with 'gs://' and contain '{date}'.
    - wiz.columns (optional) maps a logical field from DEFAULT_COLUMNS to a list
      of column names. It replaces the default candidates for that field only.
      Unknown logical field -> error 'wiz.columns.<field>'.
    - Integer settings must be positive integers.
    - root = the parent of the directory that contains the file
      (config/harness.yaml -> the repo root). Relative paths in 'paths' resolve
      against root; '~' expands to the home directory.

    Defaults: report_suffix '.csv', impersonate_service_account None (empty
    string also means None), slo_projects (), logs_lookback_minutes 120,
    revision_lookback_hours 24, agent.enabled True, agent.binary 'opencode',
    timeout_seconds 900, max_calls_per_day 40, max_prs_per_day 5,
    max_cards_per_run 30, max_changed_lines 300, workdir '~/.sre-harness/work',
    state_db 'state/harness.db', wiki_dir 'wiki', stop_file 'STOP',
    docker.enabled True.
    """
    raise NotImplementedError("T02: implement load_harness_config")


def load_services(path: str | Path) -> dict[str, Service]:
    """Load config/services.yaml and return {service_name: Service}.

    File shape: a top-level 'services' mapping of name -> entry.
    Rules (each violation raises ConfigError naming 'services.yaml: <name>.<key>'):
    - Allowed entry keys: see _SERVICE_KEYS. Unknown key -> error.
    - repo is required and must look like 'github.com/<org>/<repo>'.
    - runtime is required; runtime.kind is 'cloud-run' or 'none'.
      For 'cloud-run', project, name and region are all required.
    - ecosystem defaults to 'generic' and must be one of ECOSYSTEMS.
    - images entries are repository paths WITHOUT tag or digest: an entry that
      contains '@', or whose last '/'-segment contains ':', is an error.
    - The same image path in two services is an error naming both services.
    - List-valued keys must be lists of strings.
    Defaults: branch 'main', build '', test '', dockerfile 'Dockerfile',
    terraform_dir None, all lists empty.
    """
    raise NotImplementedError("T02: implement load_services")


def load_rules(path: str | Path) -> list[Rule]:
    """Load config/rules.yaml and return the rules in file order.

    File shape: a top-level 'rules' list; each item has name, class, when.
    Rules (each violation raises ConfigError naming 'rules.yaml: <rule name or index>'):
    - name: non-empty string, unique across rules.
    - class: a FindingClass value other than 'unmapped' (mapping assigns that).
    - when: a mapping (may be empty). Each key must be in RULE_FIELDS.
      Each value is either a scalar (str, int, bool: equality test) or a
      mapping with exactly ONE key from RULE_OPERATORS:
        in: list of scalars      regex: string that compiles with re.compile
        empty: bool              present: bool
    - The LAST rule must have an empty 'when' and class 'unclassified'
      (the catch-all). Otherwise raise ConfigError mentioning 'catch-all'.
    """
    raise NotImplementedError("T02: implement load_rules")
