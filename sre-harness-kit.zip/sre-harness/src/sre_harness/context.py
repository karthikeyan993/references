"""Everything a stage needs, passed as one object.

PROVIDED FILE. Do not edit.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Protocol, Sequence

from .config import HarnessConfig
from .models import ChatMessage, Rule, Service
from .ports import AgentPort, Clock, CommandRunner
from .state import Store


class ChatPort(Protocol):
    def send(self, msg: ChatMessage) -> bool: ...

    def flush_outbox(self) -> int: ...


@dataclass
class Context:
    cfg: HarnessConfig
    services: Mapping[str, Service]
    rules: Sequence[Rule]
    store: Store
    runner: CommandRunner
    chat: ChatPort
    agent: AgentPort
    clock: Clock
    runtime_dir: Path
    run_id: int | None = None
    day: str = ""
