"""python -m sre_harness ... (PROVIDED FILE)."""

import sys

from .cli import main

sys.exit(main())
