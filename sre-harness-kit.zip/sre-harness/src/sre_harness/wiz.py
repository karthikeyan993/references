"""Find, read and parse the daily Wiz report (task T05, docs/SPEC.md section 4)."""

from __future__ import annotations

from datetime import date
from typing import Mapping, Sequence

from .config import HarnessConfig
from .models import Finding, FindingKind
from .ports import CommandRunner


class ReportError(Exception):
    """The report is missing, empty or lacks required columns."""


def fingerprint(
    wiz_id: str | None,
    kind: FindingKind,
    resource_id: str,
    resource_name: str,
    title: str,
    package: str | None,
) -> str:
    """Stable id of one finding.

    - wiz_id present (non-empty): 'wiz:' + wiz_id
    - otherwise: 'wiz:h:' + first 16 hex chars of sha256 over the UTF-8 string
      '|'.join([kind.value, resource_id or resource_name, title, package or ''])
    Example: fingerprint(None, FindingKind.ISSUE, '', 'svc-a', 'Public bucket', None)
    hashes 'issue|svc-a|Public bucket|'.
    """
    raise NotImplementedError("T05: implement fingerprint")


def resolve_columns(headers: Sequence[str], columns: Mapping[str, Sequence[str]]) -> dict[str, str]:
    """Map each logical field to the actual header that holds it.

    For each logical field in `columns`, pick the FIRST candidate name that
    matches a header, comparing stripped and case-insensitively. Fields with
    no matching header are absent from the result. Returned values are the
    headers exactly as they appear in `headers`.
    """
    raise NotImplementedError("T05: implement resolve_columns")


def parse_report(text: str, columns: Mapping[str, Sequence[str]]) -> tuple[list[Finding], int]:
    """Parse CSV text into findings. Returns (findings, skipped_row_count).

    - A leading UTF-8 BOM is removed.
    - No header row -> ReportError('empty report').
    - Any field in config.REQUIRED_COLUMNS unresolved -> ReportError whose
      message contains 'missing required columns', the missing field names and
      the list of available headers.
    - Cell values are stripped; an empty cell is None for optional fields.
    - Rows with an empty title or empty resource_name are skipped (counted).
    - kind = VULNERABILITY when package is non-empty, else ISSUE.
    - resource_id defaults to resource_name; project and severity default to ''
      and resource_type defaults to ''.
    - package_type is lower-cased.
    - raw = the full row dict (header -> stripped value).
    - Duplicate fingerprints: keep the first row, skip later ones (not counted
      as skipped).
    - Output order = input order.
    """
    raise NotImplementedError("T05: implement parse_report")


def report_prefix(cfg: HarnessConfig, day: date) -> str:
    """cfg.wiz_report_uri_template with '{date}' replaced by day.isoformat()."""
    raise NotImplementedError("T05: implement report_prefix")


def find_report(runner: CommandRunner, cfg: HarnessConfig, day: date) -> str | None:
    """URI of the day's report or None.

    Lists report_prefix(cfg, day) with gcp.list_objects, keeps URIs ending with
    cfg.wiz_report_suffix, and returns the LAST one in sorted order.
    """
    raise NotImplementedError("T05: implement find_report")
