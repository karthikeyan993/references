"""Google Chat messages and delivery (task T11, docs/SPEC.md section 10).

Messages are plain text (Chat formatting: *bold*, `code`). One thread per work
item or alert, through the incoming-webhook threadKey mechanism.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from .models import ActionResult, ChatMessage, EvidenceItem, Outcome, SloAlert, WorkItem
from .ports import Clock, HttpClient
from .state import Store

MAX_TEXT = 4000
TRUNCATION_MARK = "\n…(truncated)"

TAGS: dict[Outcome, str] = {
    Outcome.PR_OPENED: "PR OPENED",
    Outcome.RECOMMENDATION: "RECOMMENDATION",
    Outcome.REDEPLOY_NEEDED: "REDEPLOY NEEDED",
    Outcome.CLEANUP_RECOMMENDED: "CLEANUP RECOMMENDED",
    Outcome.ACCEPTED: "ACCEPTED",
    Outcome.NO_FIX_YET: "NO FIX YET",
    Outcome.FIX_FAILED: "FIX FAILED",
    Outcome.ADD_MAPPING: "ADD MAPPING",
    Outcome.ADD_RULE: "ADD RULE",
    Outcome.DEFERRED: "DEFERRED",
    Outcome.UNCHANGED: "UNCHANGED",
    Outcome.ERROR: "HARNESS ERROR",
}

SEVERITY_ORDER: tuple[str, ...] = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL", "INFO")


def truncate(text: str) -> str:
    """Return text unchanged if len <= MAX_TEXT, else text[:MAX_TEXT - len(TRUNCATION_MARK)] + TRUNCATION_MARK."""
    raise NotImplementedError("T11: implement truncate")


def highest_severity(severities: Sequence[str]) -> str:
    """Highest severity by SEVERITY_ORDER (case-insensitive), returned upper-case.

    Unknown values rank below all known ones; among unknowns the first one wins.
    Empty input or only empty strings -> 'UNKNOWN'.
    """
    raise NotImplementedError("T11: implement highest_severity")


def headline(item: WorkItem) -> str:
    """'OS packages in image' for base_image_os, else the first finding's package, else its title."""
    raise NotImplementedError("T11: implement headline")


def render_result(item: WorkItem, result: ActionResult) -> ChatMessage:
    """One card for one work item. thread_key = item.thread_key. Lines, in order:

    1. '*[{TAGS[outcome]}]* {service or "unmapped"} · {headline(item)}'
    2. result.summary
    3. 'Class: {class value}'
    4. 'Findings: {n} ({first up to 5 distinct titles, comma-joined}{", +K more" if more})'
    5. 'Severity: {highest_severity of the findings}'
    6. 'PR: {pr_url}'          only when pr_url
    7. 'Error: {error}'        only when error
    8. '{key}: {value}' for each details key in sorted order (lists comma-joined,
       dicts as sorted JSON, other values str())
    9. 'Key: `{item.key}`'
    Joined with '\\n' and passed through truncate().
    """
    raise NotImplementedError("T11: implement render_result")


def render_error(stage: str, error: str, day: str) -> ChatMessage:
    """thread 'harness-{day}', text '*[HARNESS ERROR]* stage: {stage}\\n{error}' (truncated)."""
    raise NotImplementedError("T11: implement render_error")


def render_summary(
    day: str,
    counts: Mapping[str, int],
    new_findings: int,
    resolved_findings: int,
    skipped_rows: int,
    stale_prs: Sequence[tuple[str, str]],
    slo_lines: Sequence[str],
) -> ChatMessage:
    """thread 'daily-{day}'. Lines:

    '*[DAILY SUMMARY]* {day}'
    'New findings: {n} · Resolved: {m} · Skipped rows: {k}'
    'Outcomes: ' + ', '.join(f'{k}={v}' for sorted counts with v > 0) or 'Outcomes: none'
    'PRs open more than 7 days: none'  OR that header followed by one line
        '- {pr_url} ({key})' per stale PR
    'SLO: none'  OR 'SLO:' followed by one '- {line}' per slo line
    """
    raise NotImplementedError("T11: implement render_summary")


def slo_thread_key(alert_id: str) -> str:
    """'slo-' + the last '/'-segment of alert_id."""
    raise NotImplementedError("T11: implement slo_thread_key")


def render_slo_root_cause(
    alert: SloAlert,
    rca: Mapping[str, Any] | None,
    hypotheses: Sequence[Mapping[str, Any]],
    rejected: int,
    evidence: Sequence[EvidenceItem],
    agent_error: str | None = None,
) -> ChatMessage:
    """Root-cause note. thread slo_thread_key(alert.alert_id). Lines:

    '*[SLO ROOT CAUSE]* {service or "unknown service"} · {policy_display_name}'
    'Opened: {open_time}'
    'Summary: {rca["summary"]}' when rca and hypotheses are non-empty, otherwise
        'Insufficient evidence: no hypothesis cited valid evidence.'
    For each hypothesis i (1-based):
        '{i}. {cause} (confidence: {confidence}; evidence: {comma-joined ids})'
        '   Check next: {check_next}'   only when check_next is non-empty
    'Suspected commit: {x}' / 'Suggested fix: {y}' when rca has them non-empty
        (only when hypotheses are non-empty)
    'Evidence checked: {len(evidence)} items ({kind=count, sorted by kind})'
    'Rejected hypotheses: {rejected}'  only when rejected > 0
    'Agent error: {agent_error}'       only when agent_error
    """
    raise NotImplementedError("T11: implement render_slo_root_cause")


def render_slo_resolved(alert: SloAlert, minutes_open: int) -> ChatMessage:
    """'*[SLO RESOLVED]* {service or "unknown service"} · {policy_display_name}\\n'
    'Open for {minutes_open} min ({open_time} to {close_time})'."""
    raise NotImplementedError("T11: implement render_slo_resolved")


def webhook_url(url: str) -> str:
    """url with query parameter messageReplyOption=REPLY_MESSAGE_FALLBACK_TO_NEW_THREAD.

    Existing query parameters are kept in order; an existing messageReplyOption
    is replaced (not duplicated).
    """
    raise NotImplementedError("T11: implement webhook_url")


def payload(msg: ChatMessage) -> dict[str, Any]:
    """{'text': msg.text, 'thread': {'threadKey': msg.thread_key}}."""
    raise NotImplementedError("T11: implement payload")


class ChatSender:
    """Sends messages; anything that fails goes to the SQLite outbox."""

    def __init__(self, http: HttpClient, url: str, store: Store, clock: Clock) -> None:
        """Keep http, store and clock as attributes; self.url = webhook_url(url)."""
        raise NotImplementedError("T11: implement ChatSender.__init__")

    def send(self, msg: ChatMessage) -> bool:
        """POST payload(msg) to self.url. 2xx -> True. Otherwise store.outbox_add(...) and False."""
        raise NotImplementedError("T11: implement ChatSender.send")

    def flush_outbox(self) -> int:
        """Re-send pending outbox messages oldest first. Mark each success as sent.

        Stop at the first failure (leave it and later ones pending). Return the
        number sent.
        """
        raise NotImplementedError("T11: implement ChatSender.flush_outbox")
