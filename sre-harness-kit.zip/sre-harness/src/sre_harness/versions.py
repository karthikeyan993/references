"""Version comparison and lockfile lookups (task T09, docs/SPEC.md section 7).

Two comparison families:
- OS packages (ecosystems 'deb', 'apk', 'rpm'): dpkg ordering.
- Everything else: a semver-like ordering that also copes with pip and Go versions.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

from .models import Finding

OS_ECOSYSTEMS: frozenset[str] = frozenset({"deb", "apk", "rpm"})

_PACKAGE_TYPE_MAP: dict[str, str] = {
    "deb": "deb",
    "dpkg": "deb",
    "debian": "deb",
    "ubuntu": "deb",
    "apk": "apk",
    "alpine": "apk",
    "rpm": "rpm",
    "redhat": "rpm",
    "rhel": "rpm",
    "centos": "rpm",
    "npm": "npm",
    "node": "npm",
    "javascript": "npm",
    "pip": "pip",
    "pypi": "pip",
    "python": "pip",
    "go": "go",
    "golang": "go",
    "maven": "maven",
    "java": "maven",
}

_POST_WORDS = frozenset({"post", "p", "patch", "pl"})


def ecosystem_for(package_type: str | None, service_ecosystem: str) -> str:
    """Ecosystem used to compare a finding's versions.

    package_type (case-insensitive) is looked up in _PACKAGE_TYPE_MAP; unknown
    or None falls back to service_ecosystem. Examples: 'Debian' -> 'deb',
    'pypi' -> 'pip', None with service 'npm' -> 'npm'.
    """
    raise NotImplementedError("T09: implement ecosystem_for")


def is_os_ecosystem(ecosystem: str) -> bool:
    """True for 'deb', 'apk' and 'rpm' (OS_ECOSYSTEMS)."""
    raise NotImplementedError("T09: implement is_os_ecosystem")


def compare_versions(a: str, b: str, ecosystem: str) -> int:
    """Return -1, 0 or 1 for a < b, a == b, a > b.

    OS ecosystems (deb, apk, rpm) use dpkg rules: optional integer epoch before
    ':', then upstream and revision split at the LAST '-', each compared with
    the dpkg algorithm ('~' sorts before everything, even the end of string;
    letters sort before other symbols; digit runs compare numerically).
    Examples: '1:1.0' > '2.0'; '1.0~rc1' < '1.0'; '1.2.3-1' < '1.2.3-2'.

    Other ecosystems use semver-like rules: a leading 'v' before a digit is
    dropped, '+build' suffixes are ignored, the string is split into digit runs
    and letter runs (other characters are separators). Compare position by
    position: numbers compare numerically, a number beats a word, words
    compare lexically. When one version has run out: a missing token counts
    as 0 against a number ('1.0' == '1.0.0'); against a word the word side is a
    pre-release and therefore smaller ('2.0.0-rc1' < '2.0.0'), except the words
    'post', 'p', 'patch', 'pl', which make that side larger.
    Examples: '1.10.0' > '1.9.9'; '2.0.0-rc1' < '2.0.0'; 'v1.2.3' == '1.2.3';
    '1.0.post1' > '1.0'.
    """
    raise NotImplementedError("T09: implement compare_versions")


def parse_fixed_versions(field: str | None) -> list[str]:
    """Split a Wiz fixed-version cell into candidate versions.

    Separators: commas, '|' and whitespace. A leading '>=' or '>' or '=' on a
    token is removed. Tokens that do not start with a digit (after removing an
    optional leading 'v') are dropped. Order and duplicates are preserved
    except exact duplicates, which are removed.
    Example: '>=2.3.1, 3.0.2 || unknown' -> ['2.3.1', '3.0.2'].
    """
    raise NotImplementedError("T09: implement parse_fixed_versions")


def pick_target(installed: str | None, fixed_field: str | None, ecosystem: str) -> str | None:
    """The version to upgrade to for one finding.

    candidates = parse_fixed_versions(fixed_field). No candidates -> None.
    installed None -> the smallest candidate.
    Otherwise the smallest candidate strictly greater than installed, or None
    when every candidate is <= installed (already fixed).
    """
    raise NotImplementedError("T09: implement pick_target")


def sorted_versions(versions: Sequence[str], ecosystem: str) -> list[str]:
    """Versions sorted ascending with compare_versions (stable for equal versions)."""
    raise NotImplementedError("T09: implement sorted_versions")


def target_for_findings(findings: Sequence[Finding], ecosystem: str) -> str | None:
    """Max over pick_target(f.version, f.fixed_version, ecosystem) of all findings; None if no picks."""
    raise NotImplementedError("T09: implement target_for_findings")


def is_fixed(installed: str | None, target: str, ecosystem: str) -> bool:
    """installed is not None and compare_versions(installed, target) >= 0."""
    raise NotImplementedError("T09: implement is_fixed")


def installed_version(repo_dir: Path, package: str, ecosystem: str) -> str | None:
    """Version of `package` pinned in the repo's lockfile at repo_dir, or None.

    npm:    package-lock.json -> packages['node_modules/<package>'].version,
            falling back to dependencies[<package>].version (lockfile v1).
    pip:    every file matching 'requirements*.txt' in repo_dir (sorted); first
            line 'name==version' (optional '[extras]', inline '#' comments
            ignored) whose PEP 503-normalised name matches.
    poetry: poetry.lock; uv: uv.lock -> first [[package]] whose normalised
            name matches -> version.
    go:     go.mod -> 'require <module> <version>' or a line '<module> <version>'
            inside a 'require (' block; version returned as written (e.g. 'v1.2.3').
    Any other ecosystem, missing file or no match -> None.
    """
    raise NotImplementedError("T09: implement installed_version")
