"""Shared data types for the SRE harness.

PROVIDED FILE. Do not edit. Every other module imports its types from here,
so changing this file breaks the contract tests.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Mapping


class FindingKind(StrEnum):
    """A Wiz row is a VULNERABILITY when it names a package, else an ISSUE."""

    VULNERABILITY = "vulnerability"
    ISSUE = "issue"


class FindingClass(StrEnum):
    """Exactly one class per finding. See docs/SPEC.md section 6."""

    APP_DEPENDENCY = "app_dependency"
    BASE_IMAGE_OS = "base_image_os"
    NO_FIX_AVAILABLE = "no_fix_available"
    UNAUTH_ENDPOINT = "unauth_endpoint"
    SA_KEY = "sa_key"
    IAC_CONFIG = "iac_config"
    UNMAPPED = "unmapped"
    UNCLASSIFIED = "unclassified"


class Decision(StrEnum):
    """Result of stale-image reconciliation (docs/SPEC.md section 7)."""

    FIX = "fix"
    REDEPLOY = "redeploy"
    CLEANUP = "cleanup"
    RECOMMEND = "recommend"


class Outcome(StrEnum):
    """Exactly one outcome per work item per run. Drives the Chat card tag."""

    PR_OPENED = "pr_opened"
    RECOMMENDATION = "recommendation"
    REDEPLOY_NEEDED = "redeploy_needed"
    CLEANUP_RECOMMENDED = "cleanup_recommended"
    ACCEPTED = "accepted"
    NO_FIX_YET = "no_fix_yet"
    FIX_FAILED = "fix_failed"
    ADD_MAPPING = "add_mapping"
    ADD_RULE = "add_rule"
    DEFERRED = "deferred"
    UNCHANGED = "unchanged"
    ERROR = "error"


#: Outcomes after which an unchanged work item gets no new card.
TERMINAL_OUTCOMES: frozenset[Outcome] = frozenset(
    {
        Outcome.PR_OPENED,
        Outcome.RECOMMENDATION,
        Outcome.REDEPLOY_NEEDED,
        Outcome.CLEANUP_RECOMMENDED,
        Outcome.ACCEPTED,
        Outcome.NO_FIX_YET,
        Outcome.FIX_FAILED,
        Outcome.ADD_MAPPING,
        Outcome.ADD_RULE,
    }
)


@dataclass(frozen=True)
class Finding:
    """One row of the Wiz report after parsing (docs/SPEC.md section 4)."""

    fingerprint: str
    kind: FindingKind
    title: str
    severity: str
    resource_name: str
    resource_type: str
    resource_id: str
    project: str
    package: str | None = None
    version: str | None = None
    fixed_version: str | None = None
    package_type: str | None = None
    image: str | None = None
    wiz_id: str | None = None
    remediation: str | None = None
    raw: Mapping[str, str] = field(default_factory=dict, compare=False, hash=False)


@dataclass(frozen=True)
class RuntimeRef:
    """Where a service runs. kind is 'cloud-run' or 'none'."""

    kind: str
    project: str = ""
    name: str = ""
    region: str = ""


@dataclass(frozen=True)
class Service:
    """One entry of config/services.yaml (docs/SPEC.md section 5)."""

    name: str
    repo: str
    branch: str
    build: str
    test: str
    runtime: RuntimeRef
    ecosystem: str = "generic"
    images: tuple[str, ...] = ()
    dockerfile: str = "Dockerfile"
    terraform_dir: str | None = None
    service_accounts: tuple[str, ...] = ()
    resources: tuple[str, ...] = ()
    public_endpoints: tuple[str, ...] = ()
    slos: tuple[str, ...] = ()
    owners: tuple[str, ...] = ()


@dataclass(frozen=True)
class Rule:
    """One entry of config/rules.yaml. First matching rule wins."""

    name: str
    finding_class: FindingClass
    when: Mapping[str, Any]


@dataclass(frozen=True)
class WorkItem:
    """A group of findings handled as one unit (one PR, one card)."""

    key: str
    finding_class: FindingClass
    service: str | None
    findings: tuple[Finding, ...]

    @property
    def thread_key(self) -> str:
        """Google Chat thread key: 'wiz-' + first 12 hex chars of sha256(key)."""
        return "wiz-" + hashlib.sha256(self.key.encode()).hexdigest()[:12]

    @property
    def signature(self) -> str:
        """Change detector: sha256 over sorted 'fingerprint|fixed_version' lines."""
        lines = sorted(f"{f.fingerprint}|{f.fixed_version or ''}" for f in self.findings)
        return hashlib.sha256("\n".join(lines).encode()).hexdigest()


@dataclass(frozen=True)
class ReconcileResult:
    decision: Decision
    reason: str
    running_images: tuple[str, ...] = ()
    stale_images: tuple[str, ...] = ()
    target_version: str | None = None
    head_version: str | None = None


@dataclass
class ActionResult:
    """What a playbook did for one work item. Rendered into one Chat card."""

    key: str
    outcome: Outcome
    summary: str
    details: dict[str, Any] = field(default_factory=dict)
    pr_url: str | None = None
    error: str | None = None


@dataclass(frozen=True)
class ChatMessage:
    thread_key: str
    text: str


@dataclass(frozen=True)
class CommandResult:
    args: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


@dataclass(frozen=True)
class EvidenceItem:
    """One numbered piece of SLO evidence. ids are 'E1', 'E2', ... in order."""

    id: str
    kind: str
    summary: str
    data: Mapping[str, Any] = field(default_factory=dict, compare=False, hash=False)


@dataclass(frozen=True)
class SloAlert:
    alert_id: str
    project: str
    policy_name: str
    policy_display_name: str
    state: str
    open_time: str
    close_time: str | None
    summary: str
    service: str | None
    slo: str | None
