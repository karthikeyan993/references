"""Self-healing SRE harness. See docs/SPEC.md."""

__version__ = "0.1.0"
