"""SLO alert polling, evidence collection and root-cause notes (task T18, docs/SPEC.md section 13)."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from .context import Context
from .models import EvidenceItem, Service, SloAlert


def parse_time(value: str) -> datetime | None:
    """datetime.fromisoformat after replacing a trailing 'Z' with '+00:00' and cutting
    fractional seconds to 6 digits. Unparseable or empty -> None."""
    raise NotImplementedError("T18: implement parse_time")


def log_filter(service: Service) -> str:
    """'resource.type="cloud_run_revision" AND resource.labels.service_name="{runtime.name}" AND severity>=ERROR'."""
    raise NotImplementedError("T18: implement log_filter")


def collect_evidence(ctx: Context, alert: SloAlert, service: Service | None) -> list[EvidenceItem]:
    """Numbered evidence, ids 'E1', 'E2', ... in the order added:

    1. kind 'alert': f"Alert '{policy_display_name}' opened {open_time}: {summary}",
       data {'policy': policy_name}.
    2. service None -> stop here.
    3. Logs (only runtime cloud-run): gcp.read_logs(project=runtime.project, log_filter(service),
       cfg.slo_logs_lookback_minutes, 500) -> group_log_signatures. One item per group,
       kind 'log_signature', summary f"{count}x {signature} (first {first_seen}, last {last_seen})",
       data = the group. No groups -> one 'log_signature' item 'No ERROR log entries in the lookback window'.
       GcpError -> one item kind 'unavailable', summary f'logs unavailable: {error}'.
    4. Revisions (only cloud-run): gcp.list_revisions; window = [open_time - cfg.slo_revision_lookback_hours,
       open_time]; recent = revisions whose created time is inside it (oldest first). One item per
       recent revision: kind 'revision', summary f"Revision {name} created {created} image {image}",
       data = the revision dict. None recent -> one 'revision' item
       f'No new revisions in the {N}h before the alert'. GcpError -> 'unavailable' f'revisions unavailable: {error}'.
    5. Commits: when there is at least one recent revision AND a revision created before the first
       recent one: old = commit_from_image(previous.image), new = commit_from_image(last recent.image).
       Both found -> clone = gitops.ensure_clone; lines = gitops.commits_between(clone, old, new);
       item kind 'commits', summary f'{len(lines)} commits between {old} and {new}',
       data {'commits': first 50 lines}. GitError -> 'unavailable' f'commits unavailable: {error}'.
    6. History: wiki.read_incident_history(cfg.wiki_dir, service.name, 5) -> one item per page,
       kind 'history', summary f"Past incident opened {opened}: actual cause: {actual_cause}", data = page dict.
    """
    raise NotImplementedError("T18: implement collect_evidence")


def evidence_dir(ctx: Context, alert: SloAlert) -> Path:
    """<workdir>/slo/<last segment of alert_id>"""
    raise NotImplementedError("T18: implement evidence_dir")


def handle_new_alert(ctx: Context, alert: SloAlert) -> Path:
    """Analyse one newly opened alert; return the wiki page path.

    1. service = ctx.services.get(alert.service) when alert.service, else None.
    2. evidence = collect_evidence(...); write it as JSON list of
       {'id', 'kind', 'summary', 'data'} to evidence_dir(...)/'evidence.json' (indent 2).
    3. workdir = head_tree(ctx, service) when service is not None, else evidence_dir(...).
       (A GitError or GcpError here falls back to evidence_dir.)
    4. rca = ctx.agent.run(AgentTask('rca', 'rca', {'evidence_path': <json path>,
       'service': service name or 'unknown', 'alert_title': policy_display_name},
       workdir, 'rca_result', (), key=alert.alert_id)).
       hypotheses, rejected = validate_rca(rca, {e.id for e in evidence}).
       AgentError -> rca None, hypotheses [], rejected 0, agent_error = str(exc).
    5. path = wiki.write_incident_page(cfg.wiki_dir, alert, rca, hypotheses, evidence).
    6. ctx.chat.send(chat.render_slo_root_cause(alert, rca, hypotheses, rejected, evidence, agent_error)).
    7. ctx.store.slo_alert_save(alert, 'open', str(path)).
    """
    raise NotImplementedError("T18: implement handle_new_alert")


def handle_closed_alert(ctx: Context, alert: SloAlert, wiki_path: str | None) -> None:
    """Post the resolved card and close the loop.

    minutes = whole minutes between open_time and close_time (0 when either is unparseable).
    ctx.chat.send(chat.render_slo_resolved(alert, minutes)); wiki.mark_resolved(Path(wiki_path),
    close_time) when wiki_path; ctx.store.slo_alert_save(alert, 'closed').
    """
    raise NotImplementedError("T18: implement handle_closed_alert")


def run_slo_poll(ctx: Context) -> int:
    """One poll over cfg.slo_projects. Returns the number of alerts handled (new + closed).

    For each project: raw alerts = gcp.list_alerts (GcpError -> send chat.render_error('slo-poll',
    str(exc), ctx.day) and continue with the next project). For each raw alert: policy =
    gcp.describe_policy(raw['policy']['name']) cached per policy name within this call
    (GcpError -> {}); alert = parse_alert(raw, policy).
    - state 'OPEN' and store.slo_alert_get(id) is None -> handle_new_alert.
    - state 'CLOSED' and the stored row has status 'open' -> handle_closed_alert(row['wiki_path']).
    - otherwise nothing.
    Any other exception while handling one alert -> send chat.render_error('slo-alert', ...) and continue.
    """
    raise NotImplementedError("T18: implement run_slo_poll")
