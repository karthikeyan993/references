"""Stale-image reconciliation (task T10, docs/SPEC.md section 7).

Pure functions: no I/O. The pipeline fetches running images and the version
at HEAD, then asks decide() what to do.
"""

from __future__ import annotations

from typing import Sequence

from .models import ReconcileResult, WorkItem


def images_match(finding_image: str, running_image: str) -> bool | None:
    """Does a finding's image refer to a running image?

    - Different repositories (split_image(...)[0]) -> False.
    - Both have digests -> digests equal.
    - Both have tags and neither has a digest -> tags equal.
    - Otherwise (e.g. finding has only a tag, running has only a digest) -> None (unknown).
    """
    raise NotImplementedError("T10: implement images_match")


def is_running(finding_image: str | None, running: Sequence[str] | None) -> bool:
    """Conservative 'is this image running?'.

    True when finding_image is None, running is None (unknown), or any
    images_match(...) is True or None. False only when every running image
    gives False (including an empty running list).
    """
    raise NotImplementedError("T10: implement is_running")


def decide(
    item: WorkItem,
    running: Sequence[str] | None,
    head_version: str | None,
    ecosystem: str,
) -> ReconcileResult:
    """Decide what to do with one work item.

    1. Classes other than app_dependency and base_image_os ->
       Decision.RECOMMEND, reason 'no reconcile for <class>'.
    2. Split findings with is_running(f.image, running). If NONE are running ->
       Decision.CLEANUP, reason 'no affected image is running',
       stale_images = sorted distinct images of the findings.
    3. base_image_os -> Decision.FIX, reason 'running image has vulnerable OS packages'.
    4. app_dependency: target = versions.target_for_findings(<the RUNNING findings>, ecosystem).
       - target None -> Decision.REDEPLOY, reason 'already fixed per finding versions'.
       - versions.is_fixed(head_version, target, ecosystem) -> Decision.REDEPLOY,
         reason 'fixed at HEAD, running image is older'.
       - else Decision.FIX, reason 'vulnerable at HEAD'.
    Always fill running_images (sorted distinct images of running findings,
    None images left out), stale_images (sorted distinct images of the
    not-running findings), target_version (step 4 only) and head_version.
    """
    raise NotImplementedError("T10: implement decide")
