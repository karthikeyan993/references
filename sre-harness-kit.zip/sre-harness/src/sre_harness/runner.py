"""Real implementations of the ports (task T04).

This is the ONLY module allowed to import subprocess or urllib.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from .models import CommandResult


class SubprocessRunner:
    """CommandRunner backed by subprocess.run, never with a shell."""

    def run(
        self,
        args: Sequence[str],
        *,
        cwd: str | None = None,
        timeout: int = 300,
        env: Mapping[str, str] | None = None,
    ) -> CommandResult:
        """Run args (a list, never a string) and capture text output.

        - shell is never used.
        - env: when given, merged over os.environ.
        - A missing executable returns returncode 127 with the error in stderr.
        - A timeout returns returncode 124 with 'timeout after Ns' in stderr.
        - Never raises for non-zero exit codes.
        """
        raise NotImplementedError("T04: implement SubprocessRunner.run")


class UrllibHttp:
    """HttpClient backed by urllib."""

    def post_json(self, url: str, payload: Mapping[str, Any], timeout: int = 30) -> int:
        """POST payload as JSON (Content-Type: application/json; charset=UTF-8).

        Returns the HTTP status code; HTTPError returns its code; any other
        network error returns 0. Never raises.
        """
        raise NotImplementedError("T04: implement UrllibHttp.post_json")
