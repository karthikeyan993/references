"""Group classified findings into work items (task T08, docs/SPEC.md section 6)."""

from __future__ import annotations

from typing import Sequence

from .models import Finding, FindingClass, WorkItem


def work_item_key(finding_class: FindingClass, service: str | None, finding: Finding) -> str:
    """The grouping key. One work item = one key.

    app_dependency    -> 'app_dependency:{service}:{package}'
    base_image_os     -> 'base_image_os:{service}'
    no_fix_available  -> 'no_fix_available:{service}:{package}:{title}'
    unauth_endpoint, sa_key, iac_config
                      -> '{class}:{service}:{resource_id}'
    unmapped          -> 'unmapped:{resource_id}'
    unclassified      -> 'unclassified:{fingerprint}'
    None values render as '' (e.g. 'no_fix_available:svc::CVE-1').
    """
    raise NotImplementedError("T08: implement work_item_key")


def group(classified: Sequence[tuple[Finding, FindingClass, str | None]]) -> list[WorkItem]:
    """Build work items from (finding, class, service) triples.

    Findings with the same work_item_key go into one WorkItem, keeping input
    order inside the item. Items are returned sorted by key.
    """
    raise NotImplementedError("T08: implement group")
