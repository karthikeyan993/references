"""Read-only access to GCP through the gcloud CLI (task T04, docs/SPEC.md section 8).

Every gcloud call in the harness goes through run_gcloud(), which refuses any
command not on ALLOWED_GCLOUD. This allowlist is the runtime guarantee that
the harness never changes cloud state.

Argument order for every command: 'gcloud', optional track ('alpha'),
command words, positional arguments, flags, '--format=json' (when JSON is
parsed), and LAST the impersonation flag when configured.
"""

from __future__ import annotations

from typing import Any, Sequence

from .config import HarnessConfig
from .models import RuntimeRef
from .ports import CommandRunner

#: Command word prefixes allowed after 'gcloud' and an optional 'alpha'/'beta' track.
ALLOWED_GCLOUD: tuple[tuple[str, ...], ...] = (
    ("storage", "ls"),
    ("storage", "cat"),
    ("run", "services", "describe"),
    ("run", "services", "get-iam-policy"),
    ("run", "revisions", "list"),
    ("run", "revisions", "describe"),
    ("monitoring", "alerts", "list"),
    ("monitoring", "policies", "describe"),
    ("logging", "read"),
    ("iam", "service-accounts", "keys", "list"),
    ("auth", "print-access-token"),
)


class ForbiddenCommand(Exception):
    """A gcloud command that is not on the read-only allowlist."""


class GcpError(Exception):
    """gcloud exited non-zero or returned unparseable JSON."""


def is_allowed(args: Sequence[str]) -> bool:
    """True when args (WITHOUT the leading 'gcloud') start with an allowed prefix.

    An optional first word 'alpha' or 'beta' is skipped before matching.
    Example: ['alpha', 'monitoring', 'alerts', 'list', '--project=p'] -> True;
    ['run', 'deploy', 'x'] -> False; [] -> False.
    """
    raise NotImplementedError("T04: implement is_allowed")


def run_gcloud(runner: CommandRunner, cfg: HarnessConfig, args: Sequence[str], timeout: int = 120) -> str:
    """Run ['gcloud', *args] (+ impersonation flag) and return stdout.

    - Raise ForbiddenCommand (without running anything) if not is_allowed(args).
    - Append f'--impersonate-service-account={cfg.gcp_impersonate}' as the LAST
      argument when cfg.gcp_impersonate is set.
    - Raise GcpError(stderr) when the command exits non-zero.
    """
    raise NotImplementedError("T04: implement run_gcloud")


def run_gcloud_json(runner: CommandRunner, cfg: HarnessConfig, args: Sequence[str], timeout: int = 120) -> Any:
    """run_gcloud(args + ['--format=json']) parsed as JSON. Empty stdout -> [].

    Raise GcpError when stdout is not valid JSON.
    """
    raise NotImplementedError("T04: implement run_gcloud_json")


def list_objects(runner: CommandRunner, cfg: HarnessConfig, uri_prefix: str) -> list[str]:
    """['storage', 'ls', uri_prefix] -> non-empty stripped stdout lines, sorted.

    A GcpError whose message contains 'matched no objects' or 'not found'
    (case-insensitive) returns [] instead of raising.
    """
    raise NotImplementedError("T04: implement list_objects")


def read_object(runner: CommandRunner, cfg: HarnessConfig, uri: str) -> str:
    """['storage', 'cat', uri] -> stdout text."""
    raise NotImplementedError("T04: implement read_object")


def serving_images(runner: CommandRunner, cfg: HarnessConfig, runtime: RuntimeRef) -> list[str] | None:
    """Images currently serving traffic, or None when runtime.kind is 'none'.

    cloud-run:
    1. ['run', 'services', 'describe', name, f'--project={project}', f'--region={region}', '--format=json']
    2. For every entry of status.traffic with percent > 0: take revisionName; if
       it is missing and latestRevision is true, use status.latestReadyRevisionName.
    3. For each distinct revision: ['run', 'revisions', 'describe', rev,
       f'--project={project}', f'--region={region}', '--format=json'] and take
       status.imageDigest, falling back to spec.containers[0].image.
    Return the sorted distinct non-empty image strings.
    """
    raise NotImplementedError("T04: implement serving_images")


def list_revisions(runner: CommandRunner, cfg: HarnessConfig, runtime: RuntimeRef) -> list[dict[str, str]]:
    """Cloud Run revisions as dicts {name, created, image}, oldest first.

    Command: ['run', 'revisions', 'list', f'--service={name}', f'--project={project}',
    f'--region={region}', '--format=json']. name = metadata.name,
    created = metadata.creationTimestamp, image as in serving_images step 3.
    runtime.kind 'none' returns [].
    """
    raise NotImplementedError("T04: implement list_revisions")


def run_iam_policy(runner: CommandRunner, cfg: HarnessConfig, runtime: RuntimeRef) -> dict[str, Any]:
    """['run', 'services', 'get-iam-policy', name, f'--project=..', f'--region=..', '--format=json']."""
    raise NotImplementedError("T04: implement run_iam_policy")


def has_public_invoker(policy: dict[str, Any]) -> bool:
    """True when a binding with role 'roles/run.invoker' has member 'allUsers' or 'allAuthenticatedUsers'."""
    raise NotImplementedError("T04: implement has_public_invoker")


def user_managed_keys(runner: CommandRunner, cfg: HarnessConfig, sa_email: str, project: str) -> list[dict[str, Any]]:
    """['iam', 'service-accounts', 'keys', 'list', f'--iam-account={sa}', '--managed-by=user',
    f'--project={project}', '--format=json'] -> list of key dicts."""
    raise NotImplementedError("T04: implement user_managed_keys")


def list_alerts(runner: CommandRunner, cfg: HarnessConfig, project: str) -> list[dict[str, Any]]:
    """['alpha', 'monitoring', 'alerts', 'list', f'--project={project}', '--format=json']."""
    raise NotImplementedError("T04: implement list_alerts")


def describe_policy(runner: CommandRunner, cfg: HarnessConfig, policy_name: str) -> dict[str, Any]:
    """['alpha', 'monitoring', 'policies', 'describe', policy_name, '--format=json']."""
    raise NotImplementedError("T04: implement describe_policy")


def read_logs(
    runner: CommandRunner,
    cfg: HarnessConfig,
    project: str,
    log_filter: str,
    freshness_minutes: int,
    limit: int = 500,
) -> list[dict[str, Any]]:
    """['logging', 'read', log_filter, f'--project={project}', f'--freshness={N}m',
    f'--limit={limit}', '--format=json'] -> list of log entry dicts."""
    raise NotImplementedError("T04: implement read_logs")
