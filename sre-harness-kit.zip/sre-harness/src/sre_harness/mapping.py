"""Map a finding to a service from services.yaml (task T06, docs/SPEC.md section 5)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from .models import Finding, Service


@dataclass(frozen=True)
class MappingResult:
    service: str | None
    reason: str


def split_image(image: str) -> tuple[str, str | None, str | None]:
    """Split an image reference into (repository, tag, digest).

    - digest: the part after '@' (e.g. 'sha256:abc'), else None.
    - tag: after the LAST ':' of the last '/'-segment of the part before '@',
      else None. A ':' in the registry host (e.g. 'localhost:5000/app') is not a tag.
    Examples:
      'r.io/p/app:1.2@sha256:ab' -> ('r.io/p/app', '1.2', 'sha256:ab')
      'localhost:5000/app'       -> ('localhost:5000/app', None, None)
      'app@sha256:ab'            -> ('app', None, 'sha256:ab')
    """
    raise NotImplementedError("T06: implement split_image")


def image_repo(image: str) -> str:
    """Repository part of an image reference (split_image(image)[0])."""
    raise NotImplementedError("T06: implement image_repo")


def map_finding(finding: Finding, services: Mapping[str, Service]) -> MappingResult:
    """Return the single service that owns a finding, checked in this order:

    1. finding.image set: image_repo(finding.image) equals an entry in service.images.
       reason 'image'.
    2. service.runtime.kind == 'cloud-run' and finding.resource_name == runtime.name
       and (finding.project == '' or finding.project == runtime.project). reason 'runtime'.
    3. finding.resource_name or finding.resource_id is in service.service_accounts.
       reason 'service_account'.
    4. finding.resource_name or finding.resource_id is in service.resources. reason 'resource'.
    The first step that produces matches decides. Exactly one matching service
    -> MappingResult(name, reason). Two or more -> MappingResult(None,
    'ambiguous: ' + comma-joined sorted names). No step matches ->
    MappingResult(None, 'no match').
    """
    raise NotImplementedError("T06: implement map_finding")
