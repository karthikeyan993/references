"""The daily Wiz run (task T15, docs/SPEC.md section 3).

Order of stages is fixed. A failure inside one work item never stops the run;
a failure of a whole stage posts a HARNESS ERROR card and ends the run.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Sequence

from .context import Context
from .models import Finding, FindingClass, Outcome, ReconcileResult, WorkItem

#: Outcomes that are recorded but get no individual Chat card.
NO_CARD_OUTCOMES: frozenset[Outcome] = frozenset({Outcome.DEFERRED, Outcome.UNCHANGED})


@dataclass
class WizRunSummary:
    run_id: int
    status: str
    report_uri: str | None = None
    findings: int = 0
    skipped_rows: int = 0
    new_findings: int = 0
    resolved_findings: int = 0
    outcomes: dict[str, int] = field(default_factory=dict)
    cards_sent: int = 0
    cards_grouped: int = 0


def classify_all(ctx: Context, findings: Sequence[Finding]) -> list[tuple[Finding, FindingClass, str | None]]:
    """(finding, class, service) for every finding, in input order.

    map_finding gives no service -> (f, UNMAPPED, None). Otherwise classify(f, ctx.rules)[0].
    """
    raise NotImplementedError("T15: implement classify_all")


class _Caches:
    def __init__(self) -> None:
        self.running: dict[str, list[str] | None] = {}
        self.heads: dict[str, Path | None] = {}


def reconcile_item(ctx: Context, item: WorkItem, caches: _Caches) -> ReconcileResult:
    """Fetch inputs and call reconcile.decide.

    Only app_dependency and base_image_os with a known service need inputs:
    - running images: gcp.serving_images(service.runtime), cached per service. GcpError ->
      None (treated as running) and send chat.render_error('reconcile', f'{service}: could not read
      running images: {exc}', ctx.day) once per service.
    - head version (app_dependency only): head tree from playbooks.head_tree, cached per service
      (GitError/GcpError -> None, no card); versions.installed_version(tree, package, service.ecosystem).
    - ecosystem for decide = versions.ecosystem_for(first finding's package_type, service.ecosystem).
    Every other item: reconcile.decide(item, None, None, 'generic').
    """
    raise NotImplementedError("T15: implement reconcile_item")


def run_wiz(ctx: Context, day: date) -> WizRunSummary:
    """The daily run. Stages:

    1. run_id = store.start_run('wiz', day iso, now iso); set ctx.run_id and ctx.day; if ctx.agent
       has a callable 'bind' attribute call ctx.agent.bind(run_id, day iso). ctx.chat.flush_outbox().
    2. uri = wiz.find_report. None -> send chat.render_error('ingest', f'Wiz report missing for {day}', day),
       finish_run(run_id, 'failed', now, 'report missing'), return status 'failed'.
    3. text = gcp.read_object(uri); findings, skipped = wiz.parse_report(text, cfg.wiz_columns).
       Any exception in 2-3 (GcpError, ReportError, ...) -> render_error('ingest', str(exc)), finish
       'failed' with the error, return status 'failed'.
    4. classified = classify_all; store.upsert_finding for each (count True as new);
       resolved = store.resolve_missing({fingerprints}, day).
    5. For each item of group(classified), in order:
       a. store.is_unchanged(item) -> result outcome UNCHANGED (summary 'unchanged since last run').
       b. else decision = reconcile_item(...); result = playbooks.run_playbook(...).
       c. Any exception in a/b -> ActionResult(key, ERROR, 'Unexpected error while handling this item',
          error=f'{type(exc).__name__}: {exc}').
       d. store.record_action(run_id, day, key, 'playbook', outcome=result.outcome.value,
          detail={'summary': result.summary}).
       e. Outcome not in (ERROR, DEFERRED, UNCHANGED) -> store.save_work_item(item, outcome, day, pr_url).
       f. Outcome in NO_CARD_OUTCOMES -> no card. Else if cards_sent < cfg.max_cards_per_run ->
          ctx.chat.send(chat.render_result(item, result)), cards_sent += 1; else cards_grouped += 1.
    6. counts = store.outcome_counts(run_id); if cards_grouped: counts['cards_grouped'] = cards_grouped.
       slo_lines = [f"open alert: {service} / {slo} since {open_time}" for store.slo_alerts_open()]
       (None -> 'unknown'). Send chat.render_summary(day, counts, new, len(resolved), skipped,
       store.open_prs_older_than(7, day), slo_lines).
    7. finish_run(run_id, 'ok', now); return the summary with status 'ok'.
    """
    raise NotImplementedError("T15: implement run_wiz")
