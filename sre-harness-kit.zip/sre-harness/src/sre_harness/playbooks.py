"""Playbooks: what happens to one work item (task T14, docs/SPEC.md section 7).

run_playbook() is the single entry point. Fix playbooks open PRs only after
deterministic checks pass; every other class ends in a recommendation card.
The harness never changes cloud state: commands in recommendations are text.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

from .context import Context
from .models import (
    ActionResult,
    CommandResult,
    ReconcileResult,
    Service,
    WorkItem,
)

#: Ecosystems with a scripted upgrade (see apply_upgrade).
UPGRADE_ECOSYSTEMS: frozenset[str] = frozenset({"npm", "pip", "poetry", "uv", "go"})

#: Files the fixer agent may edit after a scripted upgrade broke the build.
FIXER_ALLOWED_GLOBS: tuple[str, ...] = (
    "**/*.py",
    "**/*.js",
    "**/*.mjs",
    "**/*.cjs",
    "**/*.ts",
    "**/*.tsx",
    "**/*.go",
    "**/*.java",
    "**/*.kt",
    "**/package.json",
    "**/package-lock.json",
    "**/requirements*.txt",
    "**/pyproject.toml",
    "**/poetry.lock",
    "**/uv.lock",
    "**/go.mod",
    "**/go.sum",
)

#: Files a dependency PR must never touch.
FORBIDDEN_FIX_GLOBS: tuple[str, ...] = (".github/**", "**/*.tf", "**/Dockerfile*", "**/*.yaml", "**/*.yml")

CLEANUP_DOC = "https://docs.cloud.google.com/artifact-registry/docs/repositories/cleanup-policy-overview"


def tail(text: str, limit: int = 3000) -> str:
    """Last `limit` characters of text (the whole text when shorter)."""
    raise NotImplementedError("T14: implement tail")


def edit_requirements(worktree: Path, package: str, version: str) -> CommandResult:
    """Pin `package` to `version` in every requirements*.txt that pins it with '=='.

    Matching uses PEP 503 normalised names; extras and trailing comments are
    kept, only the version text changes. Returns a CommandResult with
    returncode 0 when at least one line changed, else returncode 1 and stderr
    'package not pinned in requirements*.txt'. No external command is run.
    """
    raise NotImplementedError("T14: implement edit_requirements")


def upgrade_command(ecosystem: str, package: str, version: str) -> list[list[str]]:
    """External commands that perform the upgrade (run in order, in the worktree).

    npm    -> [['npm', 'install', f'{package}@{version}', '--ignore-scripts']]
    poetry -> [['poetry', 'add', f'{package}>={version}']]
    uv     -> [['uv', 'lock', '--upgrade-package', f'{package}=={version}']]
    go     -> [['go', 'get', f'{package}@{v}'], ['go', 'mod', 'tidy']]
              where v = version if it starts with 'v' else 'v' + version
    pip    -> []   (handled by edit_requirements, no external command)
    other  -> []
    """
    raise NotImplementedError("T14: implement upgrade_command")


def apply_upgrade(ctx: Context, worktree: Path, ecosystem: str, package: str, version: str) -> CommandResult:
    """Run the upgrade. pip -> edit_requirements(...). Otherwise run each
    upgrade_command(...) with ctx.runner (cwd=worktree, timeout=900) and return
    the first failing result, or the last result when all pass. An ecosystem
    with no commands returns returncode 1, stderr 'no scripted upgrade for <eco>'.
    """
    raise NotImplementedError("T14: implement apply_upgrade")


def build_and_test(ctx: Context, worktree: Path, service: Service) -> tuple[bool, str]:
    """Run service.build then service.test (each skipped when empty) as
    ['sh', '-c', cmd] in worktree with timeout 1800. Stop at the first failure.

    Returns (True, '') when all pass, else (False, stdout + stderr of the failing command).
    """
    raise NotImplementedError("T14: implement build_and_test")


def forbidden_files(files: Sequence[str], service: Service) -> list[str]:
    """Files matching FORBIDDEN_FIX_GLOBS, or under service.terraform_dir when set. Sorted."""
    raise NotImplementedError("T14: implement forbidden_files")


def pr_body(item: WorkItem, summary: str, checks: Sequence[str]) -> str:
    """Markdown PR body. Exact shape:

    '## Summary\\n{summary}\\n\\n## Findings\\n' + one '- {title} ({severity}) on {image or resource_name}'
    line per finding + '\\n\\n## Checks\\n' + one '- {check}' line per check +
    '\\n\\nOpened by the SRE harness. Work item: `{item.key}`.\\n'
    """
    raise NotImplementedError("T14: implement pr_body")


def run_app_dependency(ctx: Context, item: WorkItem, service: Service, decision: ReconcileResult) -> ActionResult:
    """Upgrade one package in one service and open a PR. Steps:

    1. package = first finding's package; target = decision.target_version.
       service.ecosystem not in UPGRADE_ECOSYSTEMS -> RECOMMENDATION,
       summary f'Upgrade {package} to {target}; no scripted upgrade for ecosystem {eco}'.
    2. store.count_actions('pr', day) >= cfg.max_prs_per_day -> DEFERRED,
       summary 'Daily PR cap reached; will retry on the next run'.
    3. clone = gitops.ensure_clone; branch = gitops.branch_name(item.key).
       gitops.find_open_pr(...) returns a URL -> PR_OPENED, summary 'A PR for this fix is already open', pr_url=url.
    4. worktree = gitops.create_worktree(clone, service.branch, branch, <workdir>/worktrees/<12 hex of sha256(key)>).
       Everything below runs inside try/finally that calls gitops.remove_worktree.
    5. apply_upgrade fails -> FIX_FAILED 'Scripted upgrade failed', error = tail(stdout + stderr).
    6. build_and_test fails -> run the fixer agent once:
       AgentTask(agent='fixer', prompt_name='fix_build', variables={'service', 'package',
       'target_version', 'build_cmd', 'test_cmd', 'error_output': tail(output, 6000)},
       workdir=worktree, schema_name='fix_result', allowed_edit_globs=FIXER_ALLOWED_GLOBS, key=item.key).
       AgentError -> FIX_FAILED 'Build or tests failed after the upgrade', error=str(exc).
       Then build_and_test again; still failing -> FIX_FAILED 'Build or tests still fail after the agent fix',
       error = tail(output), details analysis = agent result 'analysis'.
    7. installed = versions.installed_version(worktree, package, service.ecosystem). When not None
       and not versions.is_fixed(installed, target, compare_eco) -> FIX_FAILED
       f'Lockfile still pins {package} {installed}', error 'version check failed'.
       compare_eco = versions.ecosystem_for(first finding's package_type, service.ecosystem).
    8. files, lines = gitops.staged_numstat(worktree). No files -> FIX_FAILED 'The upgrade changed no files'.
       forbidden_files(files) non-empty -> FIX_FAILED 'The change touches files a dependency PR may not touch'.
       lines > cfg.max_changed_lines -> FIX_FAILED f'Diff too large: {lines} lines'.
    9. commit_and_push(worktree, branch, f'fix(deps): upgrade {package} to {target}');
       url = open_pr(repo, worktree, service.branch, branch, f'[sre-bot] Upgrade {package} to {target}',
       pr_body(...)); store.record_action(run_id, day, item.key, 'pr', outcome='opened', detail={'url': url}).
       -> PR_OPENED, summary f'Upgraded {package} to {target}; build and tests passed', pr_url=url,
       details {'package', 'target_version', 'files_changed': files, 'lines_changed': lines}.
    gitops.GitError or gcp.GcpError anywhere -> FIX_FAILED 'Git or GitHub step failed', error=str(exc).
    """
    raise NotImplementedError("T14: implement run_app_dependency")


def final_base_image(dockerfile_text: str) -> str | None:
    """Image of the final build stage, following stage aliases.

    Parses lines 'FROM [--flag=value ...] <image> [AS <alias>]' (case-insensitive
    FROM/AS, leading whitespace allowed, comments ignored). Take the LAST FROM.
    While its image equals an earlier alias, replace it by that stage's image.
    No FROM -> None.
    """
    raise NotImplementedError("T14: implement final_base_image")


def package_query(ecosystem: str, package: str) -> str | None:
    """Shell snippet that prints the installed version inside the image.

    deb -> f"dpkg-query -W -f='${{Version}}' {package}"
    apk -> f"apk list --installed {package}"
    rpm -> f"rpm -q --qf '%{{VERSION}}-%{{RELEASE}}' {package}"
    other -> None
    """
    raise NotImplementedError("T14: implement package_query")


def parse_package_query(ecosystem: str, package: str, stdout: str) -> str | None:
    """Installed version from package_query output, or None when empty/unparseable.

    deb/rpm: stdout stripped. apk: first token of the first line, with the
    prefix f'{package}-' removed (e.g. 'openssl-3.1.4-r0 x86_64 ...' -> '3.1.4-r0').
    """
    raise NotImplementedError("T14: implement parse_package_query")


def run_base_image_os(ctx: Context, item: WorkItem, service: Service, decision: ReconcileResult) -> ActionResult:
    """Rebuild on a patched base image and verify package versions. Steps:

    targets: for each distinct package (sorted), versions.target_for_findings over its
    findings with eco = versions.ecosystem_for(package_type, 'deb'); packages without a
    target are left out. lines = [f'{pkg} -> {target}'].
    1. cfg.docker_enabled false -> RECOMMENDATION 'Rebuild the image on a patched base image;
       Docker checks are disabled', details {'packages': lines, 'dockerfile': service.dockerfile}.
    2. PR cap reached -> DEFERRED as in run_app_dependency.
    3. clone, branch, worktree exactly as run_app_dependency (try/finally removes worktree).
    4. Dockerfile missing -> FIX_FAILED f'Dockerfile not found: {service.dockerfile}'.
       final_base_image None -> FIX_FAILED 'No FROM line in Dockerfile'.
    5. base has a digest: ['docker', 'pull', f'{repo}:{tag or "latest"}'] then
       ['docker', 'image', 'inspect', '--format', '{{index .RepoDigests 0}}', f'{repo}:{tag or "latest"}'];
       new digest = text after '@'. If different, replace the old digest with the new one in
       the Dockerfile text (first occurrence) and set changed=True. Failures -> FIX_FAILED
       'Could not resolve the latest base image digest'.
    6. ['docker', 'build', '--pull', '-t', check_tag, '-f', service.dockerfile, '.'] in worktree,
       timeout 1800, check_tag = 'sre-harness-check:' + 12 hex of sha256(key). Fails -> FIX_FAILED
       'Image build failed', error tail(output).
    7. For each package: ['docker', 'run', '--rm', '--entrypoint', 'sh', check_tag, '-c',
       package_query(eco, pkg)] -> parse_package_query. Unknown or not versions.is_fixed ->
       still vulnerable, line f'{pkg} installed {installed or "unknown"} needs {target}'.
    8. Any still vulnerable -> RECOMMENDATION 'Rebuilding on the current base image does not fix every
       package', details {'still_vulnerable': lines, 'base_image': base}.
    9. changed -> staged_numstat; any file other than service.dockerfile -> FIX_FAILED
       'Unexpected files changed'; commit_and_push(..., f'fix(image): bump base image digest for {service.name}'),
       open_pr(... f'[sre-bot] Bump base image for {service.name}' ...), record 'pr' action ->
       PR_OPENED 'Bumped the base image digest; rebuilt image has fixed versions'.
    10. Not changed -> REDEPLOY_NEEDED 'A rebuild picks up the patched base image; no code change needed',
        details {'base_image': base, 'packages': lines}.
    GitError or GcpError -> FIX_FAILED 'Git or GitHub step failed'.
    """
    raise NotImplementedError("T14: implement run_base_image_os")


def head_tree(ctx: Context, service: Service) -> Path:
    """Read-only checkout of the service's default branch at <workdir>/heads/<service name>."""
    raise NotImplementedError("T14: implement head_tree")


def recommend(ctx: Context, item: WorkItem, service: Service | None) -> ActionResult:
    """Recommendation playbook for every class that never opens a PR.

    no_fix_available -> NO_FIX_YET f'No fixed version of {package} is published yet; re-checked daily',
        details {'package', 'installed': sorted distinct versions, 'cves': distinct titles}.
    unmapped -> ADD_MAPPING 'No service owns this resource; add it to config/services.yaml',
        details {'resource_name', 'resource_type', 'resource_id', 'project', 'image'} of the first finding
        (None values rendered as '').
    unclassified -> ADD_RULE 'No rule matched; add one to config/rules.yaml',
        details {'title', 'kind', 'resource_name', 'package_type', 'columns': sorted raw keys}.
    unauth_endpoint (needs service with runtime cloud-run, else generic, see below):
        policy = gcp.run_iam_policy; public = gcp.has_public_invoker(policy).
        - not public -> RECOMMENDATION 'Cloud Run IAM does not allow public access; check app-level auth for this endpoint'.
        - public and service.public_endpoints -> reviewer agent:
          AgentTask('reviewer', 'review_auth', {'service', 'declared_public': ', '.join(public_endpoints)},
          head_tree(ctx, service), 'review_auth', (), key). Result 'unprotected_routes' empty ->
          ACCEPTED f'Public access is declared for: {declared}; no other unprotected routes found';
          else RECOMMENDATION 'Routes without auth that are not declared public',
          details {'unprotected_routes': [...], 'notes': result notes}. AgentError ->
          RECOMMENDATION 'Public access is declared; automated route review failed', details {'agent_error'}.
        - public and no declared endpoints -> RECOMMENDATION
          'Service allows unauthenticated calls and declares no public endpoints', details {'command':
          f'gcloud run services remove-iam-policy-binding {name} --member=allUsers --role=roles/run.invoker
          --region={region} --project={project}' (one line), 'or': 'declare intended public paths in
          services.yaml public_endpoints'}.
    sa_key (needs service): service account = first finding's resource_name when it ends with
        '.gserviceaccount.com', else service.service_accounts[0]; none -> generic. keys =
        gcp.user_managed_keys(sa, finding.project or service.runtime.project); each rendered as
        f'{key id} ({age} days)' where key id = last '/'-segment of 'name' and age = days from
        'validAfterTime' to ctx.day. Reviewer agent AgentTask('reviewer', 'find_key_usage',
        {'service', 'service_account'}, head_tree, 'key_usage', (), key) -> details 'key_usage_files'
        (AgentError -> details 'agent_error'). Summary: runtime cloud-run ->
        'Delete the user-managed key; Cloud Run uses the attached service account and needs no key',
        else 'Rotate or delete the user-managed key'. details also {'service_account', 'user_managed_keys',
        'command': f'gcloud iam service-accounts keys delete KEY_ID --iam-account={sa}'}. Outcome RECOMMENDATION.
    iac_config: with service.terraform_dir: search head_tree/<terraform_dir>/**/*.tf for the resource_name
        substring -> matches 'relative/path.tf:LINE' (max 10). Matches -> reviewer agent
        AgentTask('reviewer', 'suggest_iac', {'service', 'finding_title', 'resource_name',
        'matches': '\\n'.join(matches)}, head_tree, 'iac_suggestion', (), key) -> details
        {'terraform_matches', 'suggested_diff', 'explanation'} (AgentError -> 'agent_error').
        Summary f"Config finding '{title}' on {resource_name}". Outcome RECOMMENDATION.
    generic (anything else, or missing prerequisites) -> RECOMMENDATION summary = first finding title,
        details {'resource_name', 'remediation': remediation or 'see Wiz'}.
    gcp.GcpError, gitops.GitError -> RECOMMENDATION with details 'lookup_error' = str(exc) and summary =
    first finding title.
    """
    raise NotImplementedError("T14: implement recommend")


def run_playbook(ctx: Context, item: WorkItem, decision: ReconcileResult) -> ActionResult:
    """Dispatch one work item.

    - app_dependency / base_image_os with a known service:
        Decision.CLEANUP -> CLEANUP_RECOMMENDED 'No running image is affected; delete old images with an
            Artifact Registry cleanup policy', details {'stale_images': list, 'docs': CLEANUP_DOC}.
        Decision.REDEPLOY -> REDEPLOY_NEEDED with summary = decision.reason, details
            {'target_version', 'head_version', 'running_images'} (None -> '').
        Decision.FIX -> run_app_dependency / run_base_image_os.
        Decision.RECOMMEND -> recommend().
    - app_dependency / base_image_os whose service is missing -> recommend() generic.
    - every other class -> recommend(ctx, item, service or None).
    """
    raise NotImplementedError("T14: implement run_playbook")
