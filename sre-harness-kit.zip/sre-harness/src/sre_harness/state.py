"""SQLite state store (task T03, docs/SPEC.md section 9).

The store is the only source of truth for what the harness has seen and done.
All dates are ISO strings: days 'YYYY-MM-DD', timestamps ISO-8601.
Every method commits before returning. The schema is created idempotently.
"""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Any

from .models import Finding, FindingClass, Outcome, SloAlert, WorkItem

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, day TEXT NOT NULL,
  started TEXT NOT NULL, finished TEXT, status TEXT NOT NULL DEFAULT 'running', error TEXT);
CREATE TABLE IF NOT EXISTS findings (
  fingerprint TEXT PRIMARY KEY, service TEXT, finding_class TEXT, title TEXT,
  resource_name TEXT, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL, status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS work_items (
  key TEXT PRIMARY KEY, finding_class TEXT NOT NULL, service TEXT, signature TEXT NOT NULL,
  outcome TEXT NOT NULL, pr_url TEXT, thread_key TEXT NOT NULL, updated_day TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER, day TEXT NOT NULL, key TEXT,
  kind TEXT NOT NULL, outcome TEXT, model TEXT, duration_s REAL, detail_json TEXT);
CREATE TABLE IF NOT EXISTS outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT, thread_key TEXT NOT NULL, text TEXT NOT NULL,
  created TEXT NOT NULL, sent TEXT);
CREATE TABLE IF NOT EXISTS slo_alerts (
  alert_id TEXT PRIMARY KEY, service TEXT, slo TEXT, open_time TEXT, close_time TEXT,
  status TEXT NOT NULL, wiki_path TEXT);
"""


class Store:
    """Thin wrapper over one SQLite connection."""

    def __init__(self, path: str | Path) -> None:
        """Open (creating parent directories) and apply SCHEMA. ':memory:' is allowed.

        The connection is kept as self.conn with row_factory = sqlite3.Row
        (tests read it directly).
        """
        raise NotImplementedError("T03: implement Store.__init__")

    def close(self) -> None:
        """Close the connection."""
        raise NotImplementedError("T03: implement Store.close")

    # runs -----------------------------------------------------------------
    def start_run(self, kind: str, day: str, started: str) -> int:
        """Insert a run with status 'running'; return its id."""
        raise NotImplementedError("T03: implement Store.start_run")

    def finish_run(self, run_id: int, status: str, finished: str, error: str | None = None) -> None:
        """Set status ('ok' or 'failed'), finished timestamp and optional error text."""
        raise NotImplementedError("T03: implement Store.finish_run")

    # findings ---------------------------------------------------------------
    def upsert_finding(self, finding: Finding, service: str | None, finding_class: FindingClass, day: str) -> bool:
        """Record that a finding was seen on `day`.

        Returns True when the fingerprint is new OR was previously 'resolved'
        (a reopened finding counts as new). Returns False when it was already
        'open'. Either way afterwards: status 'open', last_seen = day,
        service and finding_class updated, first_seen kept for existing rows.
        """
        raise NotImplementedError("T03: implement Store.upsert_finding")

    def resolve_missing(self, seen: set[str], day: str) -> list[str]:
        """Mark every 'open' finding whose fingerprint is not in `seen` as 'resolved'.

        Sets last_seen = day on those rows. Returns their fingerprints sorted.
        """
        raise NotImplementedError("T03: implement Store.resolve_missing")

    # work items -------------------------------------------------------------
    def get_work_item(self, key: str) -> dict[str, Any] | None:
        """Return the stored row as a dict (all columns) or None."""
        raise NotImplementedError("T03: implement Store.get_work_item")

    def save_work_item(self, item: WorkItem, outcome: Outcome, day: str, pr_url: str | None = None) -> None:
        """Insert or replace the row for item.key with its signature, thread_key, outcome.

        pr_url: when None, keep the previously stored pr_url (if any).
        """
        raise NotImplementedError("T03: implement Store.save_work_item")

    def is_unchanged(self, item: WorkItem) -> bool:
        """True when a stored row has the same signature and a TERMINAL_OUTCOMES outcome."""
        raise NotImplementedError("T03: implement Store.is_unchanged")

    def open_prs_older_than(self, days: int, today: date) -> list[tuple[str, str]]:
        """(key, pr_url) for work items with outcome 'pr_opened' and updated_day <= today - days.

        Sorted by key. Rows with an empty pr_url are skipped.
        """
        raise NotImplementedError("T03: implement Store.open_prs_older_than")

    # actions ---------------------------------------------------------------
    def record_action(
        self,
        run_id: int | None,
        day: str,
        key: str | None,
        kind: str,
        outcome: str | None = None,
        model: str | None = None,
        duration_s: float | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        """Append one action row. kind is one of 'playbook', 'agent_call', 'pr', 'card'.

        detail is stored as JSON text (sort_keys=True), or NULL when None.
        """
        raise NotImplementedError("T03: implement Store.record_action")

    def count_actions(self, kind: str, day: str) -> int:
        """Number of action rows of `kind` on `day`."""
        raise NotImplementedError("T03: implement Store.count_actions")

    def outcome_counts(self, run_id: int) -> dict[str, int]:
        """{outcome: count} over kind='playbook' actions of one run. Missing outcomes are absent."""
        raise NotImplementedError("T03: implement Store.outcome_counts")

    # outbox ----------------------------------------------------------------
    def outbox_add(self, thread_key: str, text: str, created: str) -> int:
        """Queue an unsent Chat message; return its id."""
        raise NotImplementedError("T03: implement Store.outbox_add")

    def outbox_pending(self) -> list[tuple[int, str, str]]:
        """Unsent messages as (id, thread_key, text), oldest id first."""
        raise NotImplementedError("T03: implement Store.outbox_pending")

    def outbox_mark_sent(self, message_id: int, sent: str) -> None:
        """Set the sent timestamp of one outbox row."""
        raise NotImplementedError("T03: implement Store.outbox_mark_sent")

    # slo alerts ------------------------------------------------------------
    def slo_alert_get(self, alert_id: str) -> dict[str, Any] | None:
        """The stored row (all columns) as a dict, or None."""
        raise NotImplementedError("T03: implement Store.slo_alert_get")

    def slo_alert_save(self, alert: SloAlert, status: str, wiki_path: str | None = None) -> None:
        """Insert or replace. status is 'open' or 'closed'. wiki_path None keeps the stored one."""
        raise NotImplementedError("T03: implement Store.slo_alert_save")

    def slo_alerts_open(self) -> list[dict[str, Any]]:
        """Rows with status 'open', sorted by alert_id."""
        raise NotImplementedError("T03: implement Store.slo_alerts_open")
