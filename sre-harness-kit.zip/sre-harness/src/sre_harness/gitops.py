"""Git and GitHub operations (task T13, docs/SPEC.md section 12).

Rules enforced here:
- Pushes only to branches named 'sre-bot/...'. Never '--force'.
- The agent never commits or pushes; this module does, after checks.
- PRs are opened with the GitHub CLI using the laptop's existing `gh` login.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

from .ports import CommandRunner

EXCLUDES: tuple[str, ...] = (":(exclude).sre", ":(exclude).opencode")


class GitError(Exception):
    """A git or gh command failed, or a safety rule was violated."""


def clone_url(repo: str) -> str:
    """'github.com/org/x' -> 'https://github.com/org/x.git'."""
    raise NotImplementedError("T13: implement clone_url")


def gh_repo(repo: str) -> str:
    """'github.com/org/x' -> 'org/x'."""
    raise NotImplementedError("T13: implement gh_repo")


def branch_name(key: str) -> str:
    """'sre-bot/' + slug + '-' + first 8 hex of sha256(key).

    slug: key lower-cased, every run of characters outside [a-z0-9] replaced by
    '-', stripped of '-', cut to 40 chars, stripped of '-' again.
    Example: 'app_dependency:checkout:lodash' -> 'sre-bot/app-dependency-checkout-lodash-<8 hex>'.
    """
    raise NotImplementedError("T13: implement branch_name")


def ensure_clone(runner: CommandRunner, repo: str, workdir: Path) -> Path:
    """Clone once, fetch afterwards. Returns workdir/'repos'/'<org>__<name>'.

    - If <dest>/.git exists: ['git', 'fetch', '--prune', 'origin'] in dest.
    - Else create workdir/'repos' and run ['git', 'clone', '--filter=blob:none',
      clone_url(repo), str(dest)] in workdir.
    Failures raise GitError.
    """
    raise NotImplementedError("T13: implement ensure_clone")


def remove_worktree(runner: CommandRunner, clone_dir: Path, dest: Path) -> None:
    """Best effort: ['git', 'worktree', 'remove', '--force', str(dest)] (failure ignored),
    then delete dest if it still exists, then ['git', 'worktree', 'prune'] (failure ignored)."""
    raise NotImplementedError("T13: implement remove_worktree")


def create_worktree(runner: CommandRunner, clone_dir: Path, base_branch: str, branch: str, dest: Path) -> Path:
    """Fresh work tree for a fix: remove_worktree(dest) first, then
    ['git', 'worktree', 'add', '-B', branch, str(dest), f'origin/{base_branch}'] in clone_dir.
    Raises GitError unless branch starts with 'sre-bot/'."""
    raise NotImplementedError("T13: implement create_worktree")


def checkout_head(runner: CommandRunner, clone_dir: Path, base_branch: str, dest: Path) -> Path:
    """Read-only snapshot of origin/<base_branch>: remove_worktree(dest), then
    ['git', 'worktree', 'add', '--detach', str(dest), f'origin/{base_branch}'] in clone_dir."""
    raise NotImplementedError("T13: implement checkout_head")


def staged_numstat(runner: CommandRunner, worktree: Path) -> tuple[list[str], int]:
    """Stage everything except .sre/ and .opencode/, then measure the diff.

    1. ['git', 'add', '-A', '--', '.', *EXCLUDES]
    2. ['git', 'diff', '--cached', '--numstat'] -> lines 'added<TAB>deleted<TAB>path'
       ('-' counts as 0 for binary files).
    Returns (sorted paths, total added + deleted).
    """
    raise NotImplementedError("T13: implement staged_numstat")


def commit_and_push(runner: CommandRunner, worktree: Path, branch: str, message: str) -> None:
    """Commit staged changes and push the branch.

    Raises GitError (before running anything) unless branch starts with 'sre-bot/'.
    Commands: ['git', 'add', '-A', '--', '.', *EXCLUDES], ['git', 'commit', '-m', message],
    ['git', 'push', '-u', 'origin', branch]. Never uses --force. Uses the
    laptop's configured git identity.
    """
    raise NotImplementedError("T13: implement commit_and_push")


def find_open_pr(runner: CommandRunner, repo: str, branch: str) -> str | None:
    """URL of an open PR whose head is `branch`, or None.

    ['gh', 'pr', 'list', '--repo', gh_repo(repo), '--head', branch, '--state', 'open',
    '--json', 'url'] -> JSON list; first item's 'url'. gh failure -> GitError.
    """
    raise NotImplementedError("T13: implement find_open_pr")


def open_pr(
    runner: CommandRunner,
    repo: str,
    worktree: Path,
    base: str,
    branch: str,
    title: str,
    body: str,
    labels: Sequence[str] = ("sre-bot",),
) -> str:
    """Open a PR and return its URL.

    Writes body to worktree/.sre/pr_body.md, then runs in worktree:
    ['gh', 'pr', 'create', '--repo', gh_repo(repo), '--base', base, '--head', branch,
     '--title', title, '--body-file', <that path>, then '--label', L for each label].
    The URL is the last non-empty stdout line and must start with 'https://';
    otherwise (or on non-zero exit) raise GitError.
    """
    raise NotImplementedError("T13: implement open_pr")


def commits_between(runner: CommandRunner, clone_dir: Path, old: str, new: str) -> list[str]:
    """['git', 'log', '--oneline', '--no-decorate', f'{old}..{new}'] lines; [] on failure."""
    raise NotImplementedError("T13: implement commits_between")
